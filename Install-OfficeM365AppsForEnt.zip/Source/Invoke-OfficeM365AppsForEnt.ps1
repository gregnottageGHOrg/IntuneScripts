#region Initialisation...
<#

.COPYRIGHT
Copyright (c) Microsoft Corporation. All rights reserved. Licensed under the MIT license.
See LICENSE in the project root for license information.

#>
####################################################
####################################################
#Instantiate Vars
####################################################
[CmdLetBinding()]
param(
)
$script:buildVer = "1.0"
$script:scriptName = 'Install-OfficeM365AppsForEnt'
$script:logName = ($myInvocation.MyCommand.Name).Substring(0, ($myInvocation.MyCommand.Name).Length - 4) + "_" + (Get-Date -UFormat "%d-%m-%Y")
$script:logPath = "$($env:ProgramData)\Microsoft\IntuneApps\$scriptName"
$script:logFile = "$logPath\$LogName.log"
$script:eventLogName = "Application"
$script:eventLogSource = "EventSystem"
$script:transcriptLog = "$logPath\$LogName" + "_Transcript.log"
If ($VerbosePreference -eq 'Continue') { Start-Transcript -Path $transcriptLog -Append }
####################################################
####################################################
#Build Functions
####################################################

Function Start-Log {
	param (
		[string]$FilePath,

		[Parameter(HelpMessage = 'Deletes existing file if used with the -DeleteExistingFile switch')]
		[switch]$DeleteExistingFile
	)

	#Create Event Log source if it's not already found...
	if ([System.Diagnostics.EventLog]::Exists($script:EventLogName) -eq $false) {
		New-EventLog -LogName $EventLogName -Source $EventLogSource
	}
	if ([System.Diagnostics.EventLog]::SourceExists($script:EventLogSource ) -eq $false) {
		[System.Diagnostics.EventLog]::CreateEventSource($script:EventLogSource , $EventLogName)
	}
	#If (!([system.diagnostics.eventlog]::SourceExists($EventLogSource))) { New-EventLog -LogName $EventLogName -Source $EventLogSource }

	Try {
		If (!(Test-Path $FilePath)) {
			## Create the log file
			New-Item $FilePath -Type File -Force | Out-Null
		}

		If ($DeleteExistingFile) {
			Remove-Item $FilePath -Force
		}

		## Set the global variable to be used as the FilePath for all subsequent Write-Log
		## calls in this session
		$script:ScriptLogFilePath = $FilePath
	}
	Catch {
		Write-Error $_.Exception.Message
	}
}

####################################################

Function Write-Log {
	#Write-Log -Message 'warning' -LogLevel 2
	#Write-Log -Message 'Error' -LogLevel 3
	param (
		[Parameter(Mandatory = $true)]
		[string]$Message,

		[Parameter()]
		[ValidateSet(1, 2, 3)]
		[int]$LogLevel = 1,

		[Parameter(HelpMessage = 'Outputs message to Event Log,when used with -WriteEventLog')]
		[switch]$WriteEventLog
	)
	Write-Host
	Write-Host $Message
	Write-Host
	$TimeGenerated = "$(Get-Date -Format HH:mm:ss).$((Get-Date).Millisecond)+000"
	$Line = '<![LOG[{0}]LOG]!><time="{1}" date="{2}" component="{3}" context="" type="{4}" thread="" file="">'
	$LineFormat = $Message, $TimeGenerated, (Get-Date -Format MM-dd-yyyy), "$($MyInvocation.ScriptName | Split-Path -Leaf):$($MyInvocation.ScriptLineNumber)", $LogLevel
	$Line = $Line -f $LineFormat
	Add-Content -Value $Line -Path $ScriptLogFilePath
	If ($WriteEventLog) { Write-EventLog -LogName $EventLogName -Source $EventLogSource -Message $Message  -Id 100 -Category 0 -EntryType Information }
}

####################################################

function Invoke-Application {
	<#
.SYNOPSIS
	This script performs the installation or uninstallation of an application(s).
	# LICENSE #
	PowerShell App Deployment Toolkit - Provides a set of functions to perform common application deployment tasks on Windows.
	Copyright (C) 2017 - Sean Lillis, Dan Cunningham, Muhammad Mashwani, Aman Motazedian.
	This program is free software: you can redistribute it and/or modify it under the terms of the GNU Lesser General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version. This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
	You should have received a copy of the GNU Lesser General Public License along with this program. If not, see <http://www.gnu.org/licenses/>.
.DESCRIPTION
	The script is provided as a template to perform an install or uninstall of an application(s).
	The script either performs an "Install" deployment type or an "Uninstall" deployment type.
	The install deployment type is broken down into 3 main sections/phases: Pre-Install, Install, and Post-Install.
	The script dot-sources the AppDeployToolkitMain.ps1 script which contains the logic and functions required to install or uninstall an application.
.PARAMETER DeploymentType
	The type of deployment to perform. Default is: Install.
.PARAMETER DeployMode
	Specifies whether the installation should be run in Interactive, Silent, or NonInteractive mode. Default is: Interactive. Options: Interactive = Shows dialogs, Silent = No dialogs, NonInteractive = Very silent, i.e. no blocking apps. NonInteractive mode is automatically set if it is detected that the process is not user interactive.
.PARAMETER AllowRebootPassThru
	Allows the 3010 return code (requires restart) to be passed back to the parent process (e.g. SCCM) if detected from an installation. If 3010 is passed back to SCCM, a reboot prompt will be triggered.
.PARAMETER TerminalServerMode
	Changes to "user install mode" and back to "user execute mode" for installing/uninstalling applications for Remote Destkop Session Hosts/Citrix servers.
.PARAMETER DisableLogging
	Disables logging to file for the script. Default is: $false.
.EXAMPLE
    powershell.exe -Command "& { & '.\Deploy-Application.ps1' -DeployMode 'Silent'; Exit $LastExitCode }"
.EXAMPLE
    powershell.exe -Command "& { & '.\Deploy-Application.ps1' -AllowRebootPassThru; Exit $LastExitCode }"
.EXAMPLE
    powershell.exe -Command "& { & '.\Deploy-Application.ps1' -DeploymentType 'Uninstall'; Exit $LastExitCode }"
.EXAMPLE
    Deploy-Application.exe -DeploymentType "Install" -DeployMode "Silent"
.NOTES
	Toolkit Exit Code Ranges:
	60000 - 68999: Reserved for built-in exit codes in Deploy-Application.ps1, Deploy-Application.exe, and AppDeployToolkitMain.ps1
	69000 - 69999: Recommended for user customized exit codes in Deploy-Application.ps1
	70000 - 79999: Recommended for user customized exit codes in AppDeployToolkitExtensions.ps1
.LINK
	http://psappdeploytoolkit.com
#>
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $false)]
		[ValidateSet('Install', 'Uninstall', 'Repair')]
		[string]$DeploymentType = 'Install',
		[Parameter(Mandatory = $false)]
		[ValidateSet('Interactive', 'Silent', 'NonInteractive')]
		[string]$DeployMode = 'Interactive',
		[Parameter(Mandatory = $false)]
		[switch]$AllowRebootPassThru = $false,
		[Parameter(Mandatory = $false)]
		[switch]$TerminalServerMode = $false,
		[Parameter(Mandatory = $false)]
		[switch]$DisableLogging = $false
	)

	Try {
		## Set the script execution policy for this process
		Try { Set-ExecutionPolicy -ExecutionPolicy 'ByPass' -Scope 'Process' -Force -ErrorAction 'Stop' } Catch {}

		##*===============================================
		##* VARIABLE DECLARATION
		##*===============================================
		## Variables: Application
		[string]$appVendor = 'Microsoft'
		[string]$appName = 'Apps for Enterprise'
		[string]$appVersion = '(Office365)'
		[string]$appArch = 'x64'
		[string]$appLang = 'EN'
		[string]$appRevision = '01'
		[string]$appScriptVersion = '1.0.0'
		[string]$appScriptDate = '08/09/2022'
		[string]$appScriptAuthor = 'Greg Nottage'
		##*===============================================
		## Variables: Install Titles (Only set here to override defaults set by the toolkit)
		[string]$installName = ''
		[string]$installTitle = ''

		##* Do not modify section below
		#region DoNotModify

		## Variables: Exit Code
		[int32]$mainExitCode = 0

		## Variables: Script
		[string]$deployAppScriptFriendlyName = 'Deploy Application'
		[version]$deployAppScriptVersion = [version]'3.8.4'
		[string]$deployAppScriptDate = '26/01/2021'
		[hashtable]$deployAppScriptParameters = $psBoundParameters

		## Variables: Environment
		#If (Test-Path -LiteralPath 'variable:HostInvocation') { $InvocationInfo = $HostInvocation } Else { $InvocationInfo = $MyInvocation }
		#[string]$scriptDirectory = Split-Path -Path $InvocationInfo.MyCommand.Definition -Parent
		[string]$scriptDirectory = $PSScriptRoot

		## Dot source the required App Deploy Toolkit Functions
		Try {
			[string]$moduleAppDeployToolkitMain = "$scriptDirectory\AppDeployToolkit\AppDeployToolkitMain.ps1"
			Write-Log -Message "moduleAppDeployToolkitMain: $moduleAppDeployToolkitMain"
			#If (-not (Test-Path -LiteralPath $moduleAppDeployToolkitMain -PathType 'Leaf')) { Throw "Module does not exist at the specified location [$moduleAppDeployToolkitMain]." }
			#. $moduleAppDeployToolkitMain
			If ($DisableLogging) { . $moduleAppDeployToolkitMain -DisableLogging } Else { . $moduleAppDeployToolkitMain }
		}
		Catch {
			If ($mainExitCode -eq 0) { [int32]$mainExitCode = 60008 }
			Write-Error -Message "Module [$moduleAppDeployToolkitMain] failed to load: `n$($_.Exception.Message)`n `n$($_.InvocationInfo.PositionMessage)" -ErrorAction 'Continue'
			## Exit the script, returning the exit code to SCCM
			#If (Test-Path -LiteralPath 'variable:HostInvocation') { $script:ExitCode = $mainExitCode; Exit } Else { Exit $mainExitCode }
			Write-Log "Error occurred, create error flag file: $PSScriptRoot\Error.flg"
			Set-Content -Path "$PSScriptRoot\Error.flg" -Value "Module [$moduleAppDeployToolkitMain] failed to load: `n$($_.Exception.Message)`n `n$($_.InvocationInfo.PositionMessage)"
			Throw "Error occurred: importing PSAppDeployToolkit module sources"
		}
		#endregion
		##* Do not modify section above
		##*===============================================
		##* END VARIABLE DECLARATION
		##*===============================================

		#-ine means case insensitive not equals - so the following is the main install routine
		If ($deploymentType -ine 'Uninstall' -and $deploymentType -ine 'Repair') {
			##*===============================================
			##* PRE-INSTALLATION
			##*===============================================
			[string]$installPhase = 'Pre-Installation'

			## Show Welcome Message, close Internet Explorer if required, allow up to 3 deferrals, verify there is enough disk space to complete the install, and persist the prompt
			Show-InstallationWelcome -CloseApps 'winword=Microsoft Word,outlook=Microsoft Outlook,excel=Microsoft Excel,powerpnt=Microsoft Powerpoint,onenote=Microsoft OneNote,visio=Microsoft Visio,project=Microsoft Project,teams=Microsoft Teams' -CheckDiskSpace -CloseAppsCountdown 600 -PersistPrompt

			## Show Progress Message (with the default message)
			Show-InstallationProgress

			## Pre-Installation tasks
			#Write-Log -Message "Running pre-install tasks, please wait..."

			##*===============================================
			##* INSTALLATION
			##*===============================================
			[string]$installPhase = 'Installation'

			## Handle Zero-Config MSI Installations
			If ($useDefaultMsi) {
				[hashtable]$ExecuteDefaultMSISplat = @{ Action = 'Install'; Path = $defaultMsiFile }; If ($defaultMstFile) { $ExecuteDefaultMSISplat.Add('Transform', $defaultMstFile) }
				Execute-MSI @ExecuteDefaultMSISplat; If ($defaultMspFiles) { $defaultMspFiles | ForEach-Object { Execute-MSI -Action 'Patch' -Path $_ } }
			}

			## <Perform Installation tasks here>
			Execute-Process -Path "$dirFiles\setup.exe" -Parameters "/CONFIGURE $officeInstallXML"

			##*===============================================
			##* POST-INSTALLATION
			##*===============================================
			[string]$installPhase = 'Post-Installation'

			## <Perform Post-Installation tasks here>
			If (-not $useDefaultMsi) { Show-InstallationPrompt -Message 'Thanks for your patience, installation is now complete. You can now use your applications.' -ButtonRightText 'OK' -Icon Information -NoWait }

		}
		ElseIf ($deploymentType -ieq 'Uninstall') {
			##*===============================================
			##* PRE-UNINSTALLATION
			##*===============================================
			[string]$installPhase = 'Pre-Uninstallation'

			## Show Welcome Message, close Internet Explorer with a 60 second countdown before automatically closing
			Show-InstallationWelcome -CloseApps 'iexplore' -CloseAppsCountdown 60

			## Show Progress Message (with the default message)
			Show-InstallationProgress

			## <Perform Pre-Uninstallation tasks here>


			##*===============================================
			##* UNINSTALLATION
			##*===============================================
			[string]$installPhase = 'Uninstallation'

			## Handle Zero-Config MSI Uninstallations
			If ($useDefaultMsi) {
				[hashtable]$ExecuteDefaultMSISplat = @{ Action = 'Uninstall'; Path = $defaultMsiFile }; If ($defaultMstFile) { $ExecuteDefaultMSISplat.Add('Transform', $defaultMstFile) }
				Execute-MSI @ExecuteDefaultMSISplat
			}

			# <Perform Uninstallation tasks here>


			##*===============================================
			##* POST-UNINSTALLATION
			##*===============================================
			[string]$installPhase = 'Post-Uninstallation'

			## <Perform Post-Uninstallation tasks here>


		}
		ElseIf ($deploymentType -ieq 'Repair') {
			##*===============================================
			##* PRE-REPAIR
			##*===============================================
			[string]$installPhase = 'Pre-Repair'

			## Show Progress Message (with the default message)
			Show-InstallationProgress

			## <Perform Pre-Repair tasks here>

			##*===============================================
			##* REPAIR
			##*===============================================
			[string]$installPhase = 'Repair'

			## Handle Zero-Config MSI Repairs
			If ($useDefaultMsi) {
				[hashtable]$ExecuteDefaultMSISplat = @{ Action = 'Repair'; Path = $defaultMsiFile; }; If ($defaultMstFile) { $ExecuteDefaultMSISplat.Add('Transform', $defaultMstFile) }
				Execute-MSI @ExecuteDefaultMSISplat
			}
			# <Perform Repair tasks here>

			##*===============================================
			##* POST-REPAIR
			##*===============================================
			[string]$installPhase = 'Post-Repair'

			## <Perform Post-Repair tasks here>


		}
		##*===============================================
		##* END SCRIPT BODY
		##*===============================================

		## Call the Exit-Script function to perform final cleanup operations
		#Exit-Script -ExitCode $mainExitCode
	}
	Catch {
		[int32]$mainExitCode = 60001
		[string]$mainErrorMessage = "$(Resolve-Error)"
		#Write-Log -Message $mainErrorMessage -Severity 3 -Source $deployAppScriptFriendlyName
		Write-Log -Message $mainErrorMessage
		Show-DialogBox -Text $mainErrorMessage -Icon 'Stop'
		Write-Log "Error occurred, create error flag file: $PSScriptRoot\Error.flg"
		Set-Content -Path "$PSScriptRoot\Error.flg" -Value $mainErrorMessage
		throw "Error occurred: $mainErrorMessage"
		#Exit-Script -ExitCode $mainExitCode
	}

}

####################################################

Function Invoke-FileDownload {
	#[CmdLetBinding(SupportsShouldProcess = $true)]
	param (
		[Parameter(Mandatory = $true, Position = 1, ValueFromPipelineByPropertyName = $true,
			ValueFromPipeline = $True,
			HelpMessage = 'Please provide web-path for file to download'
		)]
		[ValidateNotNullOrEmpty()]
		[string] $Download,

		[Parameter(Mandatory = $true, Position = 2, ValueFromPipelineByPropertyName = $true,
			ValueFromPipeline = $True,
			HelpMessage = 'Please provide output file path'
		)]
		[ValidateNotNullOrEmpty()]
		[string] $OutFile,

		[Parameter(Mandatory = $true, Position = 3, ValueFromPipelineByPropertyName = $true,
			ValueFromPipeline = $True,
			HelpMessage = 'Please provide eTagFile output path'
		)]
		[ValidateNotNullOrEmpty()]
		[string] $ETagFile
	)

	Begin {
		Write-Host "$($MyInvocation.InvocationName) function... `n" -ForegroundColor Green
		Write-Host "Processing download: $Download" -ForegroundColor Magenta
		Write-Host "Using output file: $OutFile" -ForegroundColor Magenta
		Write-Host "Using eTag file: $ETagFile `n" -ForegroundColor Magenta
	}

	Process {
		$webContent = Invoke-WebRequest -method "Head" $Download -UseBasicParsing
		# Get the current eTag of the file on the web:
		$eTag = ($webContent | Select-Object Headers -ExpandProperty Headers)["ETag"]
		# Get the current size of the file on the web:
		$contentLength = ($webContent | Select-Object Headers -ExpandProperty Headers)["Content-Length"]

		If (-Not(Test-Path -Path $OutFile)) {
			Write-Host "Local file not found, so downloading file: $OutFile `n" -ForegroundColor Yellow
			Try {
				Invoke-WebRequest $Download -UseBasicParsing -OutFile $OutFile -ErrorAction Stop
			}
			Catch {
				Write-Host "Error processing download: $($Download)`n" -ForegroundColor Yellow
				$errormsgs = $error | out-string
				Write-Host "Errors:`n $errormsgs`n" -ForegroundColor Yellow
				Throw "Error processing download: $($Download)"
			}

			Start-Sleep -Seconds 2
			Unblock-File -Path $OutFile
			If ($eTag) { $eTag | Out-File -FilePath $ETagFile -Force }
		}
		ElseIf ($(Get-Item -Path $OutFile).Length -ne $contentLength) {
			Write-Host "Local file size different, so downloading file: $OutFile `n" -ForegroundColor Yellow
			Try {
				Invoke-WebRequest $Download -UseBasicParsing -OutFile $OutFile -ErrorAction Stop
			}
			Catch {
				Write-Host "Error processing download: $($Download)`n" -ForegroundColor Yellow
				$errormsgs = $error | out-string
				Write-Host "Errors:`n $errormsgs`n" -ForegroundColor Yellow
				Throw "Error processing download: $($Download)"
			}

			Start-Sleep -Seconds 2
			Unblock-File -Path $OutFile
			If ($eTag) { $eTag | Out-File -FilePath $ETagFile -Force }
		}
		ElseIf (-Not(Test-Path -Path $ETagFile)) {
			Write-Host "eTag file not found, so downloading file: $OutFile `n" -ForegroundColor Yellow
			Try {
				Invoke-WebRequest $Download -UseBasicParsing -OutFile $OutFile -ErrorAction Stop
			}
			Catch {
				Write-Host "Error processing download: $($Download)`n" -ForegroundColor Yellow
				$errormsgs = $error | out-string
				Write-Host "Errors:`n $errormsgs`n" -ForegroundColor Yellow
				Throw "Error processing download: $($Download)"
			}

			Start-Sleep -Seconds 2
			Unblock-File -Path $OutFile

			Try {
				$eTag = (Invoke-WebRequest -method "Head" $Download -ErrorAction Stop | Select-Object Headers -ExpandProperty Headers)["ETag"]
			}
			Catch {
				Write-Host "Error processing eTag`n" -ForegroundColor Yellow
				$errormsgs = $error | out-string
				Write-Host "Errors:`n $errormsgs`n" -ForegroundColor Yellow
				Throw "Error processing eTag"
			}

			If ($eTag) { $eTag | Out-File -FilePath $ETagFile -Force }
		}
		Else {
			Write-Host "eTag of file on the web is: $eTag `n" -ForegroundColor Magenta

			$existingETag = Get-Content -Path $ETagFile
			Write-Host "Existing eTag from local file is: $existingETag `n" -ForegroundColor Magenta

			# The If-None-Match header is what does the magic - downloads updated file if web eTag value doesn't match local eTagFile value
			Try {
				Invoke-WebRequest -method "get" $Download -Headers @{"If-None-Match" = $existingETag } -outfile $OutFile
			}
			Catch [System.Net.WebException] {
				Write-Host "File on web matches local file `n" -ForegroundColor Green
			}
			Catch {
				Exit 1
			}
		}
	}
}

####################################################

If ($PSBoundParameters.Debug) {
	Write-Host "Functions loaded, terminating due to debug mode."
	function Write-Log {}
	Return
}

Start-Log -FilePath $logFile -DeleteExistingFile
Write-Host
Write-Host "Script log file path is [$logFile]" -ForegroundColor Cyan
Write-Host
Write-Log -Message "Starting $ScriptName version $BuildVer" -WriteEventLog
Write-Log -Message "Running from location: $PSScriptRoot" -WriteEventLog
Write-Log -Message "Script log file path is [$logFile]" -WriteEventLog
Write-Log -Message "Running in 64-bit mode: $([System.Environment]::Is64BitProcess)"
Write-Log -Message "Transcript log file path: $transcriptLog"

#endregion Initialisation...
##########################################################################################################
##########################################################################################################

#Main script
Write-Log -Message "Starting Main script..."
#$officeInstallXML = 'configuration-Office365-x64.xml'
$officeInstallXML = 'EUC-Global-Microsoft-365-Apps-for-Enterprise-(Office-Monthly-Enterprise-Channel)-64-bit.xml'

#region - Check for setup.exe
$setupEXE = "$PSScriptRoot\files\Setup.exe"
If (-Not(Test-Path -Path $setupEXE)) {
	Write-Host "File not found: $setupEXE, downloading... `n" -ForegroundColor Yellow
	#$downloadURL = "https://www.microsoft.com/en-us/download/confirmation.aspx?id=49117"
	$downloadURL = "https://download.microsoft.com/download/2/7/A/27AF1BE6-DD20-4CB4-B154-EBAB8A7D4A7E/officedeploymenttool_15928-20216.exe"

	$eTagFile = "$PSScriptRoot\etag.tag"
	Invoke-FileDownload -Download $downloadURL -OutFile $setupEXE -ETagFile $eTagFile
}
If (-Not(Test-Path -Path $setupEXE)) {
	Write-Log -Message "Error occurred - downloading file: $setupEXE"
	Throw "Error occurred - downloading file: $setupEXE"
}
#.\Setup.exe /extract:".\files" /log:".\ODT.log" /quiet /norestart
#endregion - Check for setup.exe

Write-Log -Message "Running Office setup process using XML file: $officeInstallXML, please wait..."
Try {
	## Display a message at the end of the install - but not when deploying during OOBE/ESP (Autopilot)!!!
	$username = "defaultuser"
	$currentuser = (Get-Process -IncludeUserName -Name explorer | Select-Object -ExpandProperty UserName).Split('\')[1]

	if ($currentuser -like "$username*") {
		Write-Host "Default user logged in: $currentuser"

		# Running under OOBE/ESP (Autopilot), so make everything super-silent!
		#Use PowerShell App Deployment Toolkit components to handle Office install
		Invoke-Application -DeploymentType 'Install' -DeployMode 'NonInteractive'
	}
	else {
		Write-Host "Default user not logged in"

		#Use PowerShell App Deployment Toolkit components to handle Office install
		Invoke-Application -DeploymentType 'Install' -DeployMode 'Interactive'
	}
}
Catch {
	Write-Log -Message "Error occurred: $($_.Exception.message)"
	Write-Warning "$($env:computername.ToUpper()) : $($_.Exception.message)"
	Write-Log "Error occurred running Invoke-Application function, create error flag file: $PSScriptRoot\Error.flg"
	Set-Content -Path "$PSScriptRoot\Error.flg" -Value "Error occurred running Invoke-Application function."
	Throw "Error occurred: running Invoke-Application function"
}

#Backup Office Log files
$logfileDate = get-date -Format "yyyyMMdd"
Write-Log -Message "Backup Office log files"
Try {
	Copy-Item -Path "$env:SystemRoot\Temp\$env:computername-$logfileDate-*.log" -Destination $logPath -ErrorAction Stop
}
Catch {
	Write-Log -Message "Error occurred: $($_.Exception.message)"
	Write-Warning "$($env:computername.ToUpper()) : $($_.Exception.message)"
	Write-Log "Error occurred copying Office log files, create error flag file: $PSScriptRoot\Error.flg"
	Set-Content -Path "$PSScriptRoot\Error.flg" -Value "Error occurred copying Office log files."
	Throw "Error occurred: copying Office log files"
}

Write-Log -Message "Script end."
Stop-Transcript