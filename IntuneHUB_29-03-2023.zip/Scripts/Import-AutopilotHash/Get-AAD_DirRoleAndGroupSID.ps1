[CmdLetBinding(SupportsShouldProcess = $true)]
[cmdletbinding()]
param (
    [Parameter(Mandatory = $true, Position = 1, ValueFromPipelineByPropertyName = $true,
        ValueFromPipeline = $True,
        HelpMessage = 'Please specify Azure App Registration (Service Principle) Application (client) ID'
    )]
    [ValidateNotNullOrEmpty()]
    [string] $AppID,
        
    [Parameter(Mandatory = $true, Position = 2, ValueFromPipelineByPropertyName = $true,
        ValueFromPipeline = $True,
        HelpMessage = 'Please specify Azure Tenant ID'
    )]
    [ValidateNotNullOrEmpty()]
    [string] $TenantID,

    [Parameter(Mandatory = $true, Position = 3, ValueFromPipelineByPropertyName = $true,
        HelpMessage = 'Please specify AAD group name(s) to find SID for'
    )]
    [ValidateNotNullOrEmpty()]
    [string[]] $GroupName = @()
)

Function Test-AuthToken() {


    [cmdletbinding()]
    
    param
    (
        [Parameter(Mandatory = $true,
            HelpMessage = 'Please specify your user principal name for Azure Authentication')]
        $User
    )
    
    # Checking if authToken exists before running authentication
    if ($global:authToken) {
    
        # Setting DateTime to Universal time to work in all timezones
        $DateTime = (Get-Date).ToUniversalTime()
    
        # If the authToken exists checking when it expires
        $TokenExpires = ($authToken.ExpiresOn.datetime - $DateTime).Minutes
    
        if ($TokenExpires -le 0) {
    
            write-host "Authentication Token expired" $TokenExpires "minutes ago" -ForegroundColor Yellow
            write-host
    
            # Defining Azure AD tenant name, this is the name of your Azure Active Directory (do not use the verified domain name)
    
            if ($User -eq $null -or $User -eq "") {
    
                $Global:User = Read-Host -Prompt "Please specify your user principal name for Azure Authentication"
                Write-Host
    
            }
    
            $global:authToken = Get-AuthToken -User $User
    
        }
    }
    
    # Authentication doesn't exist, calling Get-AuthToken function
    
    else {
    
        if ($User -eq $null -or $User -eq "") {
    
            $Global:User = Read-Host -Prompt "Please specify your user principal name for Azure Authentication"
            Write-Host
    
        }
    
        # Getting the authorization token
        $global:authToken = Get-AuthToken -User $User
    
    }
    Connect-AzureAD -AccountId $User
}
    
####################################################

function Get-AuthToken {

    <#
    .SYNOPSIS
    This function is used to authenticate with the Graph API REST interface
    .DESCRIPTION
    The function authenticate with the Graph API Interface with the tenant name
    .EXAMPLE
    Get-AuthToken
    Authenticates you with the Graph API interface
    .NOTES
    NAME: Get-AuthToken
    #>
    
    [cmdletbinding()]
    
    param
    (
        [Parameter(Mandatory = $true)]
        $User
    )
    
    $userUpn = New-Object "System.Net.Mail.MailAddress" -ArgumentList $User
    
    $tenant = $userUpn.Host
    
    Write-Host "Checking for AzureAD module..."
    
    $AadModule = Get-Module -Name "AzureADPreview" -ListAvailable
    
    
    if ($AadModule -eq $null) {
        write-host
        write-host "AzureAD Powershell module not installed..." -f Red
        write-host "Install by running 'Install-Module AzureAD' or 'Install-Module AzureADPreview' from an elevated PowerShell prompt" -f Yellow
        write-host "Script can't continue..." -f Red
        write-host
        exit
    }
    
    <#
    if ($AadModule -eq $null) {
        write-host
        write-host "AzureAD Powershell module not installed..." -f Red
        write-host "Attempting module install now (requires Admin rights!)" -f Red
        Install-Module -Name AzureAD -AllowClobber -Scope CurrentUser -Force
        write-host
    }
    #>
    # Getting path to ActiveDirectory Assemblies
    # If the module count is greater than 1 find the latest version
    
    if ($AadModule.count -gt 1) {
    
        $Latest_Version = ($AadModule | select version | Sort-Object)[-1]
    
        $aadModule = $AadModule | ? { $_.version -eq $Latest_Version.version }
    
        # Checking if there are multiple versions of the same module found
    
        if ($AadModule.count -gt 1) {
    
            $aadModule = $AadModule | select -Unique
    
        }
    
        $adal = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.dll"
        $adalforms = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.Platform.dll"
    
    }
    
    else {
    
        $adal = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.dll"
        $adalforms = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.Platform.dll"
    
    }
    
    [System.Reflection.Assembly]::LoadFrom($adal) | Out-Null
    
    [System.Reflection.Assembly]::LoadFrom($adalforms) | Out-Null
    
    $clientId = "d1ddf0e4-d672-4dae-b554-9d5bdfd93547"
    
    $redirectUri = "urn:ietf:wg:oauth:2.0:oob"
    
    $resourceAppIdURI = "https://graph.microsoft.com"
    
    $authority = "https://login.microsoftonline.com/$Tenant"
    
    try {
    
        $authContext = New-Object "Microsoft.IdentityModel.Clients.ActiveDirectory.AuthenticationContext" -ArgumentList $authority
    
        # https://msdn.microsoft.com/en-us/library/azure/microsoft.identitymodel.clients.activedirectory.promptbehavior.aspx
        # Change the prompt behaviour to force credentials each time: Auto, Always, Never, RefreshSession
    
        $platformParameters = New-Object "Microsoft.IdentityModel.Clients.ActiveDirectory.PlatformParameters" -ArgumentList "Auto"
    
        $userId = New-Object "Microsoft.IdentityModel.Clients.ActiveDirectory.UserIdentifier" -ArgumentList ($User, "OptionalDisplayableId")
    
        $authResult = $authContext.AcquireTokenAsync($resourceAppIdURI, $clientId, $redirectUri, $platformParameters, $userId).Result
    
        # If the accesstoken is valid then create the authentication header
    
        if ($authResult.AccessToken) {
    
            # Creating header for Authorization token
    
            $authHeader = @{
                'Content-Type'  = 'application/json'
                'Authorization' = "Bearer " + $authResult.AccessToken
                'ExpiresOn'     = $authResult.ExpiresOn
            }
    
            return $authHeader
    
        }
    
        else {
    
            Write-Host
            Write-Host "Authorization Access Token is null, please re-run authentication..." -ForegroundColor Red
            Write-Host
            break
    
        }
    
    }
    
    catch {
    
        write-host $_.Exception.Message -f Red
        write-host $_.Exception.ItemName -f Red
        write-host
        break
    
    }
    
}
     
####################################################

Function Invoke-FileDownload {
    #[CmdLetBinding(SupportsShouldProcess = $true)]
    param (
        [Parameter(Mandatory = $true, Position = 1, ValueFromPipelineByPropertyName = $true,
            ValueFromPipeline = $True,
            HelpMessage = 'Please provide web-path for file to download'
        )]
        [ValidateNotNullOrEmpty()]
        [string] $Download,

        [Parameter(Mandatory = $true, Position = 2, ValueFromPipelineByPropertyName = $true,
            ValueFromPipeline = $True,
            HelpMessage = 'Please provide output file path'
        )]
        [ValidateNotNullOrEmpty()]
        [string] $OutFile,

        [Parameter(Mandatory = $true, Position = 3, ValueFromPipelineByPropertyName = $true,
            ValueFromPipeline = $True,
            HelpMessage = 'Please provide eTagFile output path'
        )]
        [ValidateNotNullOrEmpty()]
        [string] $ETagFile
    )

    Begin {
        Write-Host "$($MyInvocation.InvocationName) function... `n" -ForegroundColor Green
        Write-Host "Processing download: $Download" -ForegroundColor Magenta
        Write-Host "Using output file: $OutFile" -ForegroundColor Magenta
        Write-Host "Using eTag file: $ETagFile `n" -ForegroundColor Magenta
    }

    Process {
        $webContent = Invoke-WebRequest -method "Head" $Download -UseBasicParsing
        # Get the current eTag of the file on the web:
        $eTag = ($webContent | Select-Object Headers -ExpandProperty Headers)["ETag"]
        # Get the current size of the file on the web:
        $contentLength = ($webContent | Select-Object Headers -ExpandProperty Headers)["Content-Length"]

        If (-Not(Test-Path -Path $OutFile)) {
            Write-Host "Local file not found, so downloading file: $OutFile `n" -ForegroundColor Yellow
            Invoke-WebRequest $Download -UseBasicParsing -OutFile $OutFile
            Start-Sleep -Seconds 2

            Unblock-File -Path $OutFile

            $eTag | Out-File -FilePath $ETagFile -Force
        }
        ElseIf ($(Get-Item -Path $OutFile).Length -ne $contentLength) {
            Write-Host "Local file size different, so downloading file: $OutFile `n" -ForegroundColor Yellow
            Invoke-WebRequest $Download -UseBasicParsing -OutFile $OutFile
            Start-Sleep -Seconds 2

            Unblock-File -Path $OutFile

            $eTag | Out-File -FilePath $ETagFile -Force
        }
        ElseIf (-Not(Test-Path -Path $ETagFile)) {
            Write-Host "eTag file not found, so downloading file: $OutFile `n" -ForegroundColor Yellow
            Invoke-WebRequest $Download -UseBasicParsing -OutFile $OutFile
            $eTag = (Invoke-WebRequest -method "Head" $Download | Select-Object Headers -ExpandProperty Headers)["ETag"]
            $eTag | Out-File -FilePath $ETagFile -Force
        }
        Else {
            Write-Host "eTag of file on the web is: $eTag `n" -ForegroundColor Magenta
        
            $existingETag = Get-Content -Path $ETagFile
            Write-Host "Existing eTag from local file is: $existingETag `n" -ForegroundColor Magenta

            # The If-None-Match header is what does the magic - downloads updated file if web eTag value doesn't match local eTagFile value
            Try {
                Invoke-WebRequest -method "get" $Download -Headers @{"If-None-Match" = $existingETag } -outfile $OutFile
            }
            Catch [System.Net.WebException] {
                Write-Host "File on web matches local file `n" -ForegroundColor Green
            }
            Catch {
                Exit 1
            }
        }
    }
}

####################################################

Function Invoke-GraphAuth {
    <#
    .SYNOPSIS
    Connects to Graph
    .PARAMETER AppID
    Azure App Registration (Service Principle) Application (client) ID
    .PARAMETER TenantID
    Azure Tenant ID
    .EXAMPLE
    Invoke-GraphAuth -AppID "" -TenantID ""

    Connects to interactively Graph using the specified AppID and TenantID GUIDs.
    #>
    [cmdletbinding()]
    param (
        [Parameter(Position = 1, ValueFromPipelineByPropertyName = $true,
            ValueFromPipeline = $True,
            HelpMessage = 'Please specify Azure App Registration (Service Principle) Application (client) ID'
        )]
        [ValidateNotNullOrEmpty()]
        [string] $AppID,
        
        [Parameter(Position = 2, ValueFromPipelineByPropertyName = $true,
            ValueFromPipeline = $True,
            HelpMessage = 'Please specify Azure Tenant ID'
        )]
        [ValidateNotNullOrEmpty()]
        [string] $TenantID
    )

    Begin {
        Write-Host "Starting $($MyInvocation.InvocationName) function... `n" -ForegroundColor Green
    }
    Process {
        Write-Host "Login interactively, using Service Principle `n" -ForegroundColor Magenta
        #Write-Host "LoginURL: $loginURL"
        #Region Auth
        Set-Location -Path $PSScriptRoot
        $msalDLL = "$PSScriptRoot\Microsoft.Identity.Client.dll"
        If (-Not(Test-Path -Path $msalDLL)) {
            Write-Host "File not found: $msalDLL, downloading... `n" -ForegroundColor Yellow
            $downloadURL = "https://raw.githubusercontent.com/shawntabrizi/Microsoft-Authentication-with-PowerShell-and-MSAL/master/MSAL/Microsoft.Identity.Client.dll"
            
            $eTagFile = "$PSScriptRoot\etag.tag"
            Invoke-FileDownload -Download $downloadURL -OutFile $msalDLL -ETagFile $eTagFile
        }   

        # Load MSAL
        Add-Type -Path $msalDLL

        # Application and Tenant Configuration
        #$login = "https://login.microsoftonline.com/"
        #$login = $loginURL
        #$redirectUri = New-Object system.uri("https://login.microsoftonline.com/common/oauth2/nativeclient")

        # Define the resources and scopes you want to call
        $scopes = New-Object System.Collections.ObjectModel.Collection["string"]
        $scopes.Add("https://graph.microsoft.com/.default")

        # Get an Access Token with MSAL
        #$app = New-Object Microsoft.Identity.Client.PublicClientApplication($AppID, ($login + $TenantID))
        $app = New-Object Microsoft.Identity.Client.PublicClientApplication($AppID, ($authURL))
        $authenticationResult = $app.AcquireTokenAsync($scopes).GetAwaiter().GetResult()

        Connect-MgGraph -AccessToken $authenticationResult.AccessToken
        Select-MgProfile -Name "Beta"
        #endRegion Auth
    }
    End {
        Write-Host "Ending: $($MyInvocation.Mycommand) `n" -ForegroundColor Green
    }
}

####################################################

Function Get-AADGroupDetails() {

    <#
.SYNOPSIS
This function is used to get AAD group details from the Graph API REST interface.
.DESCRIPTION
The function connects to the Graph API Interface and gets the AAD group details.
.EXAMPLE
Get-AADGroupDetails
Returns AAD group details from Graph API.
.NOTES
NAME: Get-AADGroupDetails
#>

    [cmdletbinding()]
    <#
    param(
        [Parameter(Mandatory = $true, Position = 1,
            HelpMessage = 'Please specify an Azure Active Directory (AAD) group objectID'
        )]
        [ValidateNotNullOrEmpty()]
        [string] $aadGroupObjectID
    )
    #>

    $graphApiVersion = "v1.0"
    $graphResource = "groups"
    
    try {
    
        $uri = "https://graph.microsoft.com/$graphApiVersion/$($graphResource)"
        Write-Host "Searching URI: $uri"
        #(Invoke-RestMethod -Uri $uri -Headers $authToken -Method Get).Value
        Invoke-RestMethod -Uri $uri -Headers $authToken -Method Get
    
    }
    
    catch {

        $ex = $_.Exception
        $errorResponse = $ex.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($errorResponse)
        $reader.BaseStream.Position = 0
        $reader.DiscardBufferedData()
        $responseBody = $reader.ReadToEnd();
        Write-Host "Response content:`n$responseBody" -f Red
        Write-Error "Request to $Uri failed with HTTP Status $($ex.Response.StatusCode) $($ex.Response.StatusDescription)"
        write-host
        break

    }

}

####################################################

function Convert-AzureAdObjectIdToSid {
    <#
    .SYNOPSIS
    Convert an Azure AD Object ID to SID
     
    .DESCRIPTION
    Converts an Azure AD Object ID to a SID.
    Author: Oliver Kieselbach (oliverkieselbach.com)
    The script is provided "AS IS" with no warranties.
     
    .PARAMETER ObjectID
    The Object ID to convert
    #>
    
    param([String] $ObjectId)
    
    $bytes = [Guid]::Parse($ObjectId).ToByteArray()
    $array = New-Object 'UInt32[]' 4
    
    [Buffer]::BlockCopy($bytes, 0, $array, 0, 16)
    $sid = "S-1-12-1-$array".Replace(' ', '-')
    
    return $sid
}

####################################################

$loginURL = 'https://login.microsoftonline.com'
$authURL = "$loginURL/$TenantID"
Write-Host "Using AppID: $AppID" -ForegroundColor Green
Write-Host "Using TenantID: $TenantID" -ForegroundColor Green
Write-Host "Using authURL: $authURL" -ForegroundColor Green

Write-Host "Authenticate to Graph... `n" -ForegroundColor Yellow
Invoke-GraphAuth -AppID $AppID -TenantID $TenantID
Update-MSGraphEnvironment -AppId $AppID -AuthUrl $authURL -SchemaVersion 'beta' -Quiet
Connect-MSGraph | Out-Null

$roles = Get-MgDirectoryRole

foreach ($role in $roles) {
    #If ($role.DisplayName -eq 'Company Administrator') {
    If ($role.DisplayName -eq 'Global Administrator') {
        $sid = Convert-AzureAdObjectIdToSid -ObjectId $role.Id
        Write-Host "Global Admin role SID: $sid `n"
        Add-Content -Path "$PSScriptRoot\SIDs.txt" -Value "Global Admin role SID: $sid `n"
    }
    #If ($role.DisplayName -eq 'Device Administrators') {
    If ($role.DisplayName -eq 'Azure AD Joined Device Local Administrator') {
        $sid = Convert-AzureAdObjectIdToSid -ObjectId $role.Id
        Write-Host "Device Administrators role SID: $sid `n"
        Add-Content -Path "$PSScriptRoot\SIDs.txt" -Value "Device Administrators role SID: $sid `n"
    }
}

ForEach ($group in $GroupName) {
    $groupSID = Get-MgGroup -All | Where-Object -Property displayname -eq "$Group"
    Write-Host "SID for $group group: $($groupSID.SecurityIdentifier) `n"
    Add-Content -Path "$PSScriptRoot\SIDs.txt" -Value "SID for $group group: $($groupSID.SecurityIdentifier) `n"
}