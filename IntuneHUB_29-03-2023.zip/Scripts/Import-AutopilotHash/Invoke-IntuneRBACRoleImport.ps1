﻿<#

.COPYRIGHT
Copyright (c) Microsoft Corporation. All rights reserved. Licensed under the MIT license.
See LICENSE in the project root for license information.

#>
[cmdletbinding()]
param (
    [Parameter(Mandatory, Position = 1, ValueFromPipelineByPropertyName = $true,
        ValueFromPipeline = $True,
        HelpMessage = 'Please specify Azure App Registration (Service Principle) Application (client) ID'
    )]
    [ValidateNotNullOrEmpty()]
    [string] $AppID,
    
    [Parameter(Position = 2, ValueFromPipelineByPropertyName = $true,
        ValueFromPipeline = $True,
        HelpMessage = 'Please specify Azure Tenant ID'
    )]
    [ValidateNotNullOrEmpty()]
    [string] $TenantID,

    [Parameter(Position = 3, ValueFromPipelineByPropertyName = $true,
        ValueFromPipeline = $True,
        HelpMessage = 'Please specify Azure App Registration (Service Principle) Client Secret'
    )]
    [ValidateNotNullOrEmpty()]
    [string] $Secret,

    [Parameter(Position = 4, ValueFromPipelineByPropertyName = $true,
        ValueFromPipeline = $True,
        HelpMessage = 'Please specify output path'
    )]
    [string] $ImportPath
)
####################################################

function Invoke-Authentication {
    #Region Auth
    $body = @{
        Grant_Type    = "client_credentials"
        Scope         = "https://graph.microsoft.com/.default"
        Client_Id     = $AppID
        Client_Secret = $Secret
    }

    $connection = Invoke-RestMethod `
        -Uri https://login.microsoftonline.com/$TenantID/oauth2/v2.0/token `
        -Method POST `
        -Body $body

    $token = $connection.access_token

    Connect-MgGraph -AccessToken $token
    Select-MgProfile -Name "Beta"
    #endRegion Auth
}

####################################################

Function Invoke-FileDownload {
    #[CmdLetBinding(SupportsShouldProcess = $true)]
    param (
        [Parameter(Mandatory = $true, Position = 1, ValueFromPipelineByPropertyName = $true,
            ValueFromPipeline = $True,
            HelpMessage = 'Please provide web-path for file to download'
        )]
        [ValidateNotNullOrEmpty()]
        [string] $Download,

        [Parameter(Mandatory = $true, Position = 2, ValueFromPipelineByPropertyName = $true,
            ValueFromPipeline = $True,
            HelpMessage = 'Please provide output file path'
        )]
        [ValidateNotNullOrEmpty()]
        [string] $OutFile,

        [Parameter(Mandatory = $true, Position = 3, ValueFromPipelineByPropertyName = $true,
            ValueFromPipeline = $True,
            HelpMessage = 'Please provide eTagFile output path'
        )]
        [ValidateNotNullOrEmpty()]
        [string] $ETagFile
    )

    Begin {
        Write-Host "$($MyInvocation.InvocationName) function... `n" -ForegroundColor Green
        Write-Host "Processing download: $Download" -ForegroundColor Magenta
        Write-Host "Using output file: $OutFile" -ForegroundColor Magenta
        Write-Host "Using eTag file: $ETagFile `n" -ForegroundColor Magenta
    }

    Process {
        $webContent = Invoke-WebRequest -method "Head" $Download -UseBasicParsing
        # Get the current eTag of the file on the web:
        $eTag = ($webContent | Select-Object Headers -ExpandProperty Headers)["ETag"]
        # Get the current size of the file on the web:
        $contentLength = ($webContent | Select-Object Headers -ExpandProperty Headers)["Content-Length"]

        If (-Not(Test-Path -Path $OutFile)) {
            Write-Host "Local file not found, so downloading file: $OutFile `n" -ForegroundColor Yellow
            Invoke-WebRequest $Download -UseBasicParsing -OutFile $OutFile
            Start-Sleep -Seconds 2

            Unblock-File -Path $OutFile

            $eTag | Out-File -FilePath $ETagFile -Force
        }
        ElseIf ($(Get-Item -Path $OutFile).Length -ne $contentLength) {
            Write-Host "Local file size different, so downloading file: $OutFile `n" -ForegroundColor Yellow
            Invoke-WebRequest $Download -UseBasicParsing -OutFile $OutFile
            Start-Sleep -Seconds 2

            Unblock-File -Path $OutFile

            $eTag | Out-File -FilePath $ETagFile -Force
        }
        ElseIf (-Not(Test-Path -Path $ETagFile)) {
            Write-Host "eTag file not found, so downloading file: $OutFile `n" -ForegroundColor Yellow
            Invoke-WebRequest $Download -UseBasicParsing -OutFile $OutFile
            $eTag = (Invoke-WebRequest -method "Head" $Download | Select-Object Headers -ExpandProperty Headers)["ETag"]
            $eTag | Out-File -FilePath $ETagFile -Force
        }
        Else {
            Write-Host "eTag of file on the web is: $eTag `n" -ForegroundColor Magenta
        
            $existingETag = Get-Content -Path $ETagFile
            Write-Host "Existing eTag from local file is: $existingETag `n" -ForegroundColor Magenta

            # The If-None-Match header is what does the magic - downloads updated file if web eTag value doesn't match local eTagFile value
            Try {
                Invoke-WebRequest -method "get" $Download -Headers @{"If-None-Match" = $existingETag } -outfile $OutFile
            }
            Catch [System.Net.WebException] {
                Write-Host "File on web matches local file `n" -ForegroundColor Green
            }
            Catch {
                Exit 1
            }
        }
    }
}

####################################################

Function Invoke-GraphAuth {
    <#
    .SYNOPSIS
    Connects to Graph
    .PARAMETER AppID
    Azure App Registration (Service Principle) Application (client) ID
    .PARAMETER TenantID
    Azure Tenant ID
    .EXAMPLE
    Invoke-GraphAuth -AppID "" -TenantID ""

    Connects to interactively Graph using the specified AppID and TenantID GUIDs.
    #>
    [cmdletbinding()]
    param (
        [Parameter(Position = 1, ValueFromPipelineByPropertyName = $true,
            ValueFromPipeline = $True,
            HelpMessage = 'Please specify Azure App Registration (Service Principle) Application (client) ID'
        )]
        [ValidateNotNullOrEmpty()]
        [string] $AppID,
        
        [Parameter(Position = 2, ValueFromPipelineByPropertyName = $true,
            ValueFromPipeline = $True,
            HelpMessage = 'Please specify Azure Tenant ID'
        )]
        [ValidateNotNullOrEmpty()]
        [string] $TenantID
    )

    Begin {
        Write-Host "Starting $($MyInvocation.InvocationName) function... `n" -ForegroundColor Green
    }
    Process {
        Write-Host "Login interactively, using Service Principle `n" -ForegroundColor Magenta
        #$loginURL = 'https://login.microsoftonline.com'
        #$authURL = "$loginURL/$TenantID"
        #Write-Host "LoginURL: $loginURL"
        #Region Auth
        #Set-Location -Path $PSScriptRoot
        $msalDLL = "$PSScriptRoot\Microsoft.Identity.Client.dll"
        If (-Not(Test-Path -Path $msalDLL)) {
            Write-Host "File not found: $msalDLL, downloading... `n" -ForegroundColor Yellow
            $downloadURL = "https://raw.githubusercontent.com/shawntabrizi/Microsoft-Authentication-with-PowerShell-and-MSAL/master/MSAL/Microsoft.Identity.Client.dll"
            
            $eTagFile = "$PSScriptRoot\etag.tag"
            Invoke-FileDownload -Download $downloadURL -OutFile $msalDLL -ETagFile $eTagFile
        }   

        # Load MSAL
        Add-Type -Path $msalDLL

        # Application and Tenant Configuration
        #$login = "https://login.microsoftonline.com/"
        #$login = $loginURL
        #$redirectUri = New-Object system.uri("https://login.microsoftonline.com/common/oauth2/nativeclient")

        # Define the resources and scopes you want to call
        $scopes = New-Object System.Collections.ObjectModel.Collection["string"]
        $scopes.Add("https://graph.microsoft.com/.default")

        # Get an Access Token with MSAL
        #$app = New-Object Microsoft.Identity.Client.PublicClientApplication($AppID, ($login + $TenantID))
        $app = New-Object Microsoft.Identity.Client.PublicClientApplication($AppID, ($authURL))
        $authenticationResult = $app.AcquireTokenAsync($scopes).GetAwaiter().GetResult()

        Connect-MgGraph -AccessToken $authenticationResult.AccessToken
        Select-MgProfile -Name "Beta"
        #endRegion Auth
    }
    End {
        Write-Host "`nEnding: $($MyInvocation.Mycommand) `n" -ForegroundColor Green
    }
}

####################################################

Function Set-PSGalleryPreReqs {
    Begin {
        Write-Host "Starting $($MyInvocation.InvocationName) function... `n" -ForegroundColor Green
    }
    Process {
        Write-Host "Preparing PSGallery pre-reqs... `n" -ForegroundColor Magenta

        #Check for NuGet Package Provider installed on machine
        if ((Get-PackageProvider -ListAvailable).name -eq "NuGet") {
            #check if Nuget is installed on the machine
            $nuget = Get-PackageProvider -Name Nuget

            if ($nuget.version -eq ((find-PackageProvider -name nuget).version)) {
                #check for latest version    
                Write-Host "NuGet is up to date `n" -ForegroundColor Green
            }
            else {
                try {
                    Install-PackageProvider -name nuget -Force -confirm:$False -ErrorAction Stop
                    Write-Host "NuGet Package Provider is installed `n" -ForegroundColor Green    
                }
                catch {
                    Throw
                }    
            }
        }
        else {
            try {
                Write-Host "Running command 'Install-PackageProvider -name nuget -Force -confirm:`$false' `n" -ForegroundColor Yellow
                Install-PackageProvider -name nuget -Force -confirm:$false -ErrorAction Stop
                Write-Host "`nNuGet Package Provider is installed `n" -ForegroundColor Green
            }
            catch {
                Throw        
            }
        }

        #Register the PSGallery repository and set the installation policy to trusted
        Write-Host "Checking Get-PSRepository for PSGallery... `n" -ForegroundColor Magenta

        $psRepo = Get-PSRepository
        foreach ($repo in $psrepo) { 
            Write-Host "`nRepo name: $($repo.name) with installation policy: $($repo.InstallationPolicy)`n"
            If (($($repo.name) -eq "PSGallery") -and ($($repo.InstallationPolicy) -ne "Trusted")) {
                Write-Host "PSGallery currently untrusted, setting it to trusted. `n" -ForegroundColor Yellow
                #<#
                Try {
                    Write-Host "Set PSGallery to trusted `n" -ForegroundColor Yellow
                    Set-PSRepository -name "PSGallery" -InstallationPolicy Trusted
                }
                Catch {
                    Throw
                }
                $found = $True
                Write-Host "PSGallery Repository installation policy set to trusted `n" -ForegroundColor Green
                #>
            }
            ElseIf (($($repo.name) -eq "PSGallery") -and ($($repo.InstallationPolicy) -eq "Trusted")) {
                $found = $True
                Write-Host "PSGallery Repository installation policy already set to trusted `n" -ForegroundColor Green
            }
        }

        If (-Not($found)) {
            Write-Host "PSGallery repo not found `n" -ForegroundColor Yellow 
            Try {
                Write-Host "Register PSGallery as trusted `n" -ForegroundColor Yellow
                Register-PSRepository -Default -InstallationPolicy Trusted
            }
            Catch {
                Throw
            }
            Write-Host "Default PS Repository registered and installation policy set to trusted `n" -ForegroundColor Green
        }
        
        <#
        If ((Get-PSRepository).name -eq "PSGallery") {
            Try {
                Write-Host "Set PSGallery to trusted `n" -ForegroundColor Yellow
                Set-PSRepository -name "PSGallery" -InstallationPolicy Trusted
            }
            Catch {
                Throw
            }
            Write-Host "PSGallery Repository installation policy set to trusted `n" -ForegroundColor Green
        }
        else {
            Try {
                Write-Host "Register PSGallery as trusted `n" -ForegroundColor Yellow
                Register-PSRepository -Default -InstallationPolicy Trusted
            }
            Catch {
                Throw
            }
            Write-Host "default PS Repository registered and installation policy set to trusted `n" -ForegroundColor Green
        }
        #>

        #Update PackageManagement module
        Try {
            Write-Host "Check for PackageManagement module `n" -ForegroundColor Yellow
            #Install-Module -Name PackageManagement -Force -MinimumVersion 1.4.6 -Repository PSGallery -ErrorAction SilentlyContinue
            Update-EveryModule -ExcludedModules $listOfModules
            Import-PSModule -ModuleToLoad "PackageManagement"
            Write-Host "PackageManagement module is installed `n" -ForegroundColor Green
        }
        Catch {
            Throw
        }        
    }
    End {
        Write-Host "Ending: $($MyInvocation.Mycommand) `n" -ForegroundColor Green
    }
}

####################################################

Function Import-PSModule {
    <#
            .SYNOPSIS
        Cmdlet for loading modules single or multiple modules



            .DESCRIPTION
                    This function will import modules, load and or install modules from a PowerShell Repository



            .PARAMETER ModuleToLoad
                    Modules to load



    .EXAMPLE
        PS C:\> Import-PSModules -ModuleToLoad Foo



                    Imports the Foo module



    .NOTES
        NOTE: You can not pull up the help information until the object has been imported
    #>

    [cmdletbinding()]
    param(
        [object]$moduleToLoad
    )

    Begin {
        Write-Host "Starting $($MyInvocation.InvocationName) function... `n" -ForegroundColor Green
    }
    Process {
        Write-Host "Check to see if module: $ModuleToLoad is already imported `n" -ForegroundColor Yellow
        if (Get-Module -Name $moduleToLoad) {
            $mod = Get-Module -Name $moduleToLoad | Select-Object Name, Version
            Write-Host "Module already installed: $mod `n" -ForegroundColor Green
        }
        else {
            Write-Host "If module is not imported, but available on disk then import it `n" -ForegroundColor Yellow
            Write-Host "This will check all of the available modules in the module paths `n" -ForegroundColor Yellow
            if (Get-Module -ListAvailable -Name $moduleToLoad) {
                $mod = Get-Module -ListAvailable -Name $moduleToLoad | Select-Object Name, Version
                Write-Host "Module details: $mod `n" -ForegroundColor Green
            }
            else {
                try {
                    Write-Host "If module is not imported, not available on disk, but is in online gallery then install and import `n" -ForegroundColor Yellow
                    if (Find-Module -Name $moduleToLoad) {
                        Write-Host "If the module is found, try to install it `n" -ForegroundColor Yellow
                        Write-Host "Using command: Install-Module -Name $moduleToLoad -AcceptLicense -AllowClobber -Force `n" -ForegroundColor Yellow
                        
                        If (Test-Administrator) {
                            Install-Module -Name $moduleToLoad -AcceptLicense -AllowClobber -Force
                        }
                        Else {
                            Install-Module -Name $moduleToLoad -Scope CurrentUser -AcceptLicense -AllowClobber -Force
                        }

                        $mod = Get-Module -ListAvailable -Name $moduleToLoad | Select-Object Name, Version
                        Write-Host "Licensed module now installed: $mod `n" -ForegroundColor Green
                    }
                    else {
                        Write-Host "Module is not imported, not available and not in online gallery, aborting"
                        Throw
                    }
                }
                Catch [System.Management.Automation.ParameterBindingException] {
                    Write-Host "Module did not install with -AcceptLicense parameter, trying without.`n" -ForegroundColor Yellow
                    Write-Host "Using command: Install-Module -Name $moduleToLoad -AllowClobber -Force `n" -ForegroundColor Yellow
                    If (Test-Administrator) {
                        Install-Module -Name $moduleToLoad -AllowClobber -Force
                    }
                    Else {
                        Install-Module -Name $moduleToLoad -Scope CurrentUser -AllowClobber -Force
                    }

                    $mod = Get-Module -ListAvailable -Name $moduleToLoad | Select-Object Name, Version
                    Write-Host "Module now installed: $mod `n" -ForegroundColor Green
                }
                catch {
                    Throw
                }
            }
        }
    }
    End {
        Write-Host "Ending: $($MyInvocation.Mycommand) `n" -ForegroundColor Green
    }
}

####################################################

function Update-EveryModule {
    <#
    .SYNOPSIS
    Updates all modules from the PowerShell gallery.
    .DESCRIPTION
    Updates all local modules that originated from the PowerShell gallery.
    Removes all old versions of the modules.
    .PARAMETER ExcludedModules
    Array of modules to exclude from updating.
    .PARAMETER SkipMajorVersion
    Skip major version updates to account for breaking changes.
    .PARAMETER KeepOldModuleVersions
    Array of modules to keep the old versions of.
    .PARAMETER ExcludedModulesforRemoval
    Array of modules to exclude from removing old versions of.
    The Az module is (not) excluded by default.
    .EXAMPLE
    Update-EveryModule -excludedModulesforRemoval 'Az'
    .NOTES
    Created by Barbara Forbes
    @ba4bes
    .LINK
    https://4bes.nl
    #>
    [cmdletbinding(SupportsShouldProcess = $true)]
    param (
        [parameter()]
        [array]$ExcludedModules = @(),
        [parameter()]
        [switch]$SkipMajorVersion,
        [parameter()]
        [switch]$KeepOldModuleVersions,
        [parameter()]
        [array]$ExcludedModulesforRemoval = @()
        #[array]$ExcludedModulesforRemoval = @("Az")
    )
    # Get all installed modules that have a newer version available
    Write-Verbose "Checking all installed modules for available updates."
    $CurrentModules = Get-InstalledModule | Where-Object { $ExcludedModules -notcontains $_.Name -and $_.repository -eq "PSGallery" }

    # Walk through the Installed modules and check if there is a newer version
    $CurrentModules | ForEach-Object {
        Write-Verbose "Checking $($_.Name)"
        Try {
            $GalleryModule = Find-Module -Name $_.Name -Repository PSGallery -ErrorAction Stop
        }
        Catch {
            Write-Error "Module $($_.Name) not found in gallery $_"
            $GalleryModule = $null
        }
        if ($GalleryModule.Version -gt $_.Version) {
            if ($SkipMajorVersion -and $GalleryModule.Version.Split('.')[0] -gt $_.Version.Split('.')[0]) {
                Write-Warning "Skipping major version update for module $($_.Name). Galleryversion: $($GalleryModule.Version), local version $($_.Version)"
            }
            else {
                Write-Verbose "$($_.Name) will be updated. Galleryversion: $($GalleryModule.Version), local version $($_.Version)"
                try {
                    if ($PSCmdlet.ShouldProcess(
                        ("Module {0} will be updated to version {1}" -f $_.Name, $GalleryModule.Version),
                            $_.Name,
                            "Update-Module"
                        )
                    ) {
                        Update-Module $_.Name -ErrorAction Stop -Force
                        Write-Verbose "$($_.Name)  has been updated"
                    }
                }
                Catch {
                    Write-Error "$($_.Name) failed: $_ "
                    continue

                }
                if ($KeepOldModuleVersions -ne $true) {
                    Write-Verbose "Removing old module $($_.Name)"
                    if ($ExcludedModulesforRemoval -contains $_.Name) {
                        Write-Verbose "$($allversions.count) versions of this module found [ $($module.name) ]"
                        Write-Verbose "Please check this manually as removing the module can cause instabillity."
                    }
                    else {
                        try {
                            if ($PSCmdlet.ShouldProcess(
                                ("Old versions will be uninstalled for module {0}" -f $_.Name),
                                    $_.Name,
                                    "Uninstall-Module"
                                )
                            ) {
                                Get-InstalledModule -Name $_.Name -AllVersions | Where-Object { $_.version -ne $GalleryModule.Version } | Uninstall-Module -Force -ErrorAction Stop
                                Write-Verbose "Old versions of $($_.Name) have been removed"
                            }
                        }
                        catch {
                            Write-Error "Uninstalling old module $($_.Name) failed: $_"
                        }
                    }
                }
            }
        }
        elseif ($null -ne $GalleryModule) {
            Write-Verbose "$($_.Name) is up to date"
        }
    }
}

####################################################

Function Invoke-ModuleInstall {
    Begin {
        Write-Host "Starting $($MyInvocation.InvocationName) function... `n" -ForegroundColor Green
    }
    Process {
        Write-Host "Performing module install steps `n" -ForegroundColor Magenta
    
        foreach ($module in $listOfModules) {
            Write-Host "Importing module: $module `n" -ForegroundColor Yellow 
            Import-PSModule -moduleToLoad $module   
        }       
    }
    End {
        Write-Host "Ending: $($MyInvocation.Mycommand) `n" -ForegroundColor Green
    }    
}

####################################################

Function Uninstall-PSModule {
    <#
            .SYNOPSIS
        Cmdlet for unloading modules single or multiple modules

            .DESCRIPTION
                    This function will uninstall modules

            .PARAMETER ModuleToUninstall
                    Modules to load

    .EXAMPLE
        PS C:\> Import-PSModules -ModuleToUninstall Foo

                    Removes the Foo module

    .NOTES
        NOTE: You can not pull up the help information until the object has been imported
    #>

    [cmdletbinding()]
    param(
        [object]$moduleToUninstall
    )

    Begin {
        Write-Host "Starting $($MyInvocation.InvocationName) function... `n" -ForegroundColor Green
    }
    Process {
        Write-Host "Check to see if module: $ModuleToUninstall is installed."
        if (Get-Module -ListAvailable -Name $ModuleToUninstall) {
            Write-Host "Module found, removing"
            Try {
                Get-Module $ModuleToUninstall | Uninstall-Module -AllVersions -Force
            }
            Catch {
                Write-Host "Unable to remove module: $ModuleToUninstall `n" -ForegroundColor Yellow
            }
        }
    }
    End {
        Write-Host "Ending: $($MyInvocation.Mycommand) `n" -ForegroundColor Green
    }
}

####################################################

Function Test-Administrator {  
    $user = [Security.Principal.WindowsIdentity]::GetCurrent();
    (New-Object Security.Principal.WindowsPrincipal $user).IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)  
}

####################################################

Function Test-JSON() {

    <#
    .SYNOPSIS
    This function is used to test if the JSON passed to a REST Post request is valid
    .DESCRIPTION
    The function tests if the JSON passed to the REST Post is valid
    .EXAMPLE
    Test-JSON -JSON $JSON
    Test if the JSON is valid before calling the Graph REST interface
    .NOTES
    NAME: Test-JSON
    #>
    
    param (
    
        $JSON
    
    )
    
    try {
    
        $TestJSON = ConvertFrom-Json $JSON -ErrorAction Stop
        $validJson = $true
    
    }
    
    catch {
    
        $validJson = $false
        $_.Exception
    
    }
    
    if (!$validJson) {
        
        Write-Host "Provided JSON isn't in valid JSON format" -f Red
        break
    
    }
    
}
    
####################################################

Function New-RBACRole() {

    <#
    .SYNOPSIS
    This function is used to add an RBAC Role Definitions from the Graph API REST interface
    .DESCRIPTION
    The function connects to the Graph API Interface and adds an RBAC Role Definitions
    .EXAMPLE
    New-RBACRole -JSON $JSON
    .NOTES
    NAME: New-RBACRole
    #>
    
    [cmdletbinding()]
    
    param
    (
        $JSON
    )
    
    $graphApiVersion = "v1.0"
    $Resource = "deviceManagement/roleDefinitions"
        
    try {
    
        if (!$JSON) {
    
            write-host "No JSON was passed to the function, provide a JSON variable" -f Red
            break
    
        }
    
        Test-JSON -JSON $JSON
        
        $uri = "https://graph.microsoft.com/$graphApiVersion/$($Resource)"
        #Invoke-RestMethod -Uri $uri -Headers $authToken -Method Post -Body $Json -ContentType "application/json"
        Invoke-MgGraphRequest -Uri "$uri" -Method POST -Body $Json -ContentType "application/json"
    }
        
    catch {
    
        $ex = $_.Exception
        $errorResponse = $ex.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($errorResponse)
        $reader.BaseStream.Position = 0
        $reader.DiscardBufferedData()
        $responseBody = $reader.ReadToEnd();
        Write-Host "Response content:`n$responseBody" -f Red
        Write-Error "Request to $Uri failed with HTTP Status $($ex.Response.StatusCode) $($ex.Response.StatusDescription)"
        write-host
        break
    
    }
    
}
    
####################################################

$listOfModules = @("Microsoft.Graph.Authentication", "Microsoft.Graph.Intune")

Write-Host "Call function to prepare PSGallery pre-reqs... `n" -ForegroundColor Yellow
Set-PSGalleryPreReqs

# Call function to install the list of modules
Write-Host "Installing required modules... `n" -ForegroundColor Yellow
Invoke-ModuleInstall

$loginURL = 'https://login.microsoftonline.com'
$authURL = "$loginURL/$TenantID"
Write-Host "Using AppID: $AppID" -ForegroundColor Green
Write-Host "Using TenantID: $TenantID`n" -ForegroundColor Green
Write-Host "Using authURL: $authURL" -ForegroundColor Green
Invoke-GraphAuth -AppID $AppID -TenantID $TenantID
#Update-MSGraphEnvironment -AppId "c54aea31-6150-4e88-bef3-0ed89c67279f" -AuthUrl <string> [-GraphBaseUrl <string>] [-GraphResourceId <string>] -Quiet [-RedirectLink <string>] -SchemaVersion 'beta'
Update-MSGraphEnvironment -AppId $AppID -AuthUrl $authURL -SchemaVersion 'beta' -Quiet

If (-not($ImportPath)) {
    $ImportPath = "$PSScriptRoot\RBAC"
}
# Replacing quotes for Test-Path
$ImportPath = $ImportPath.replace('"', '')
Write-Host "Using Import Path: $ImportPath `n"

####################################################

#Validate import path
if (!(Test-Path "$ImportPath")) {

    Write-Host "$ImportPath Import Path for JSON file doesn't exist..." -ForegroundColor Red
    Write-Host "Script can't continue..." -ForegroundColor Red
    Write-Host
    break
}
elseif (!(Get-ChildItem $ImportPath -filter *.json)) {
    Write-Host "No JSON files detected at path: $ImportPath" -ForegroundColor Red
    Write-Host "Script can't continue..." -ForegroundColor Red
    Write-Host
    break
}

####################################################

Get-ChildItem $ImportPath -filter *.json |
Foreach-object {

    $JSON_Data = Get-Content $_.FullName

    # Creating JSON Object
    $RAW_JSON = @"

    $JSON_Data

"@

    # Converting from JSON to get Intune Role properties
    $JSON_Convert = $JSON_Data | ConvertFrom-Json

    $DisplayName = $JSON_Convert.displayName
                
    write-host
    write-host "RBAC Intune Role '$DisplayName' Found..." -ForegroundColor Cyan
    write-host
    Write-Host "Adding RBAC Intune Role '$DisplayName'" -ForegroundColor Yellow
    New-RBACRole -JSON $RAW_JSON
}
