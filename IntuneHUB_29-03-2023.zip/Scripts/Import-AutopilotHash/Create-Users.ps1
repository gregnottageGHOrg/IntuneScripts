<# #Requires -Module Az.Accounts #>
[CmdLetBinding(SupportsShouldProcess = $true)]
param (
	[Parameter(Mandatory = $true, Position = 1, ValueFromPipelineByPropertyName = $true,
		ValueFromPipeline = $True,
		HelpMessage = 'Please specify an Azure/Intune admin user name'
	)]
	[ValidateNotNullOrEmpty()]
	[string] $UserName,

	[Parameter(Mandatory = $true, Position = 2, ValueFromPipelineByPropertyName = $true,
		ValueFromPipeline = $True,
		HelpMessage = 'Please specify the password for the Azure/Intune admin user name'
	)]
	[ValidateNotNullOrEmpty()]
	[string] $AdminUserPW,

	[Parameter(Position = 3, ValueFromPipelineByPropertyName = $true,
		ValueFromPipeline = $True,
		HelpMessage = 'Please specify a password to be used when creating new users'
	)]
	[ValidateNotNullOrEmpty()]
	[string] $NewUserPW
)

####################################################

Function Set-PSGalleryPreReqs {
	Begin {
		Write-Host "Starting $($MyInvocation.InvocationName) function... `n" -ForegroundColor Green
	}
	Process {
		Write-Host "Preparing PSGallery pre-reqs... `n" -ForegroundColor Magenta

		#Check for NuGet Package Provider installed on machine
		if ((Get-PackageProvider -ListAvailable).name -eq "NuGet") {
			#check if Nuget is installed on the machine
			$nuget = Get-PackageProvider -Name Nuget

			if ($nuget.version -eq ((find-PackageProvider -name nuget).version)) {
				#check for latest version
				Write-Host "NuGet is up to date `n" -ForegroundColor Green
			}
			else {
				try {
					Install-PackageProvider -name nuget -Force -confirm:$False -ErrorAction Stop
					Write-Host "NuGet Package Provider is installed `n" -ForegroundColor Green
				}
				catch {
					Throw
				}
			}
		}
		else {
			try {
				Write-Host "Running command 'Install-PackageProvider -name nuget -Force -confirm:`$false' `n" -ForegroundColor Yellow
				Install-PackageProvider -name nuget -Force -confirm:$false -ErrorAction Stop
				Write-Host "`nNuGet Package Provider is installed `n" -ForegroundColor Green
			}
			catch {
				Throw
			}
		}

		#Register the PSGallery repository and set the installation policy to trusted
		Write-Host "Checking Get-PSRepository for PSGallery... `n" -ForegroundColor Magenta

		$psRepo = Get-PSRepository
		foreach ($repo in $psrepo) {
			Write-Host "`nRepo name: $($repo.name) with installation policy: $($repo.InstallationPolicy)`n"
			If (($($repo.name) -eq "PSGallery") -and ($($repo.InstallationPolicy) -ne "Trusted")) {
				Write-Host "PSGallery currently untrusted, setting it to trusted. `n" -ForegroundColor Yellow
				#<#
				Try {
					Write-Host "Set PSGallery to trusted `n" -ForegroundColor Yellow
					Set-PSRepository -name "PSGallery" -InstallationPolicy Trusted
				}
				Catch {
					Throw
				}
				$found = $True
				Write-Host "PSGallery Repository installation policy set to trusted `n" -ForegroundColor Green
				#>
			}
			ElseIf (($($repo.name) -eq "PSGallery") -and ($($repo.InstallationPolicy) -eq "Trusted")) {
				$found = $True
				Write-Host "PSGallery Repository installation policy already set to trusted `n" -ForegroundColor Green
			}
		}

		If (-Not($found)) {
			Write-Host "PSGallery repo not found `n" -ForegroundColor Yellow
			Try {
				Write-Host "Register PSGallery as trusted `n" -ForegroundColor Yellow
				Register-PSRepository -Default -InstallationPolicy Trusted
			}
			Catch {
				Throw
			}
			Write-Host "Default PS Repository registered and installation policy set to trusted `n" -ForegroundColor Green
		}

		<#
        If ((Get-PSRepository).name -eq "PSGallery") {
            Try {
                Write-Host "Set PSGallery to trusted `n" -ForegroundColor Yellow
                Set-PSRepository -name "PSGallery" -InstallationPolicy Trusted
            }
            Catch {
                Throw
            }
            Write-Host "PSGallery Repository installation policy set to trusted `n" -ForegroundColor Green
        }
        else {
            Try {
                Write-Host "Register PSGallery as trusted `n" -ForegroundColor Yellow
                Register-PSRepository -Default -InstallationPolicy Trusted
            }
            Catch {
                Throw
            }
            Write-Host "default PS Repository registered and installation policy set to trusted `n" -ForegroundColor Green
        }
        #>

		#Update PackageManagement module
		Try {
			Write-Host "Check for PackageManagement module `n" -ForegroundColor Yellow
			#Install-Module -Name PackageManagement -Force -MinimumVersion 1.4.6 -Repository PSGallery -ErrorAction SilentlyContinue
			Update-EveryModule -ExcludedModules $listOfModules
			Import-PSModule -ModuleToLoad "PackageManagement"
			Write-Host "PackageManagement module is installed `n" -ForegroundColor Green
		}
		Catch {
			Throw
		}
	}
	End {
		Write-Host "Ending: $($MyInvocation.Mycommand) `n" -ForegroundColor Green
	}
}

####################################################

Function Import-PSModule {
	<#
            .SYNOPSIS
        Cmdlet for loading modules single or multiple modules



            .DESCRIPTION
                    This function will import modules, load and or install modules from a PowerShell Repository



            .PARAMETER ModuleToLoad
                    Modules to load



    .EXAMPLE
        PS C:\> Import-PSModules -ModuleToLoad Foo



                    Imports the Foo module



    .NOTES
        NOTE: You can not pull up the help information until the object has been imported
    #>

	[cmdletbinding()]
	param(
		[object]$moduleToLoad
	)

	Begin {
		Write-Host "Starting $($MyInvocation.InvocationName) function... `n" -ForegroundColor Green
	}
	Process {
		Write-Host "Check to see if module: $ModuleToLoad is already imported `n" -ForegroundColor Yellow
		if (Get-Module -Name $moduleToLoad) {
			$mod = Get-Module -Name $moduleToLoad | Select-Object Name, Version
			Write-Host "Module already installed: $mod `n" -ForegroundColor Green
		}
		else {
			Write-Host "If module is not imported, but available on disk then import it `n" -ForegroundColor Yellow
			Write-Host "This will check all of the available modules in the module paths `n" -ForegroundColor Yellow
			if (Get-Module -ListAvailable -Name $moduleToLoad) {
				$mod = Get-Module -ListAvailable -Name $moduleToLoad | Select-Object Name, Version
				Write-Host "Module details: $mod `n" -ForegroundColor Green
			}
			else {
				try {
					Write-Host "If module is not imported, not available on disk, but is in online gallery then install and import `n" -ForegroundColor Yellow
					if (Find-Module -Name $moduleToLoad) {
						Write-Host "If the module is found, try to install it `n" -ForegroundColor Yellow
						Write-Host "Using command: Install-Module -Name $moduleToLoad -AcceptLicense -AllowClobber -Force `n" -ForegroundColor Yellow

						If (Test-Administrator) {
							Install-Module -Name $moduleToLoad -AcceptLicense -AllowClobber -Force
						}
						Else {
							Install-Module -Name $moduleToLoad -Scope CurrentUser -AcceptLicense -AllowClobber -Force
						}

						$mod = Get-Module -ListAvailable -Name $moduleToLoad | Select-Object Name, Version
						Write-Host "Licensed module now installed: $mod `n" -ForegroundColor Green
					}
					else {
						Write-Host "Module is not imported, not available and not in online gallery, aborting"
						Throw
					}
				}
				Catch [System.Management.Automation.ParameterBindingException] {
					Write-Host "Module did not install with -AcceptLicense parameter, trying without.`n" -ForegroundColor Yellow
					Write-Host "Using command: Install-Module -Name $moduleToLoad -AllowClobber -Force `n" -ForegroundColor Yellow
					If (Test-Administrator) {
						Install-Module -Name $moduleToLoad -AllowClobber -Force
					}
					Else {
						Install-Module -Name $moduleToLoad -Scope CurrentUser -AllowClobber -Force
					}

					$mod = Get-Module -ListAvailable -Name $moduleToLoad | Select-Object Name, Version
					Write-Host "Module now installed: $mod `n" -ForegroundColor Green
				}
				catch {
					Throw
				}
			}
		}
	}
	End {
		Write-Host "Ending: $($MyInvocation.Mycommand) `n" -ForegroundColor Green
	}
}

####################################################

function Update-EveryModule {
	<#
    .SYNOPSIS
    Updates all modules from the PowerShell gallery.
    .DESCRIPTION
    Updates all local modules that originated from the PowerShell gallery.
    Removes all old versions of the modules.
    .PARAMETER ExcludedModules
    Array of modules to exclude from updating.
    .PARAMETER SkipMajorVersion
    Skip major version updates to account for breaking changes.
    .PARAMETER KeepOldModuleVersions
    Array of modules to keep the old versions of.
    .PARAMETER ExcludedModulesforRemoval
    Array of modules to exclude from removing old versions of.
    The Az module is (not) excluded by default.
    .EXAMPLE
    Update-EveryModule -excludedModulesforRemoval 'Az'
    .NOTES
    Created by Barbara Forbes
    @ba4bes
    .LINK
    https://4bes.nl
    #>
	[cmdletbinding(SupportsShouldProcess = $true)]
	param (
		[parameter()]
		[array]$ExcludedModules = @(),
		[parameter()]
		[switch]$SkipMajorVersion,
		[parameter()]
		[switch]$KeepOldModuleVersions,
		[parameter()]
		[array]$ExcludedModulesforRemoval = @()
		#[array]$ExcludedModulesforRemoval = @("Az")
	)
	# Get all installed modules that have a newer version available
	Write-Verbose "Checking all installed modules for available updates."
	$CurrentModules = Get-InstalledModule | Where-Object { $ExcludedModules -notcontains $_.Name -and $_.repository -eq "PSGallery" }

	# Walk through the Installed modules and check if there is a newer version
	$CurrentModules | ForEach-Object {
		Write-Verbose "Checking $($_.Name)"
		Try {
			$GalleryModule = Find-Module -Name $_.Name -Repository PSGallery -ErrorAction Stop
		}
		Catch {
			Write-Error "Module $($_.Name) not found in gallery $_"
			$GalleryModule = $null
		}
		if ($GalleryModule.Version -gt $_.Version) {
			if ($SkipMajorVersion -and $GalleryModule.Version.Split('.')[0] -gt $_.Version.Split('.')[0]) {
				Write-Warning "Skipping major version update for module $($_.Name). Galleryversion: $($GalleryModule.Version), local version $($_.Version)"
			}
			else {
				Write-Verbose "$($_.Name) will be updated. Galleryversion: $($GalleryModule.Version), local version $($_.Version)"
				try {
					if ($PSCmdlet.ShouldProcess(
                        ("Module {0} will be updated to version {1}" -f $_.Name, $GalleryModule.Version),
							$_.Name,
							"Update-Module"
						)
					) {
						Update-Module $_.Name -ErrorAction Stop -Force
						Write-Verbose "$($_.Name)  has been updated"
					}
				}
				Catch {
					Write-Error "$($_.Name) failed: $_ "
					continue

				}
				if ($KeepOldModuleVersions -ne $true) {
					Write-Verbose "Removing old module $($_.Name)"
					if ($ExcludedModulesforRemoval -contains $_.Name) {
						Write-Verbose "$($allversions.count) versions of this module found [ $($module.name) ]"
						Write-Verbose "Please check this manually as removing the module can cause instabillity."
					}
					else {
						try {
							if ($PSCmdlet.ShouldProcess(
                                ("Old versions will be uninstalled for module {0}" -f $_.Name),
									$_.Name,
									"Uninstall-Module"
								)
							) {
								Get-InstalledModule -Name $_.Name -AllVersions | Where-Object { $_.version -ne $GalleryModule.Version } | Uninstall-Module -Force -ErrorAction Stop
								Write-Verbose "Old versions of $($_.Name) have been removed"
							}
						}
						catch {
							Write-Error "Uninstalling old module $($_.Name) failed: $_"
						}
					}
				}
			}
		}
		elseif ($null -ne $GalleryModule) {
			Write-Verbose "$($_.Name) is up to date"
		}
	}
}

####################################################

Function Invoke-ModuleInstall {
	Begin {
		Write-Host "Starting $($MyInvocation.InvocationName) function... `n" -ForegroundColor Green
	}
	Process {
		Write-Host "Performing module install steps `n" -ForegroundColor Magenta

		foreach ($module in $listOfModules) {
			Write-Host "Importing module: $module `n" -ForegroundColor Yellow
			Import-PSModule -moduleToLoad $module
		}
	}
	End {
		Write-Host "Ending: $($MyInvocation.Mycommand) `n" -ForegroundColor Green
	}
}

####################################################

Function Uninstall-PSModule {
	<#
            .SYNOPSIS
        Cmdlet for unloading modules single or multiple modules

            .DESCRIPTION
                    This function will uninstall modules

            .PARAMETER ModuleToUninstall
                    Modules to load

    .EXAMPLE
        PS C:\> Import-PSModules -ModuleToUninstall Foo

                    Removes the Foo module

    .NOTES
        NOTE: You can not pull up the help information until the object has been imported
    #>

	[cmdletbinding()]
	param(
		[object]$moduleToUninstall
	)

	Begin {
		Write-Host "Starting $($MyInvocation.InvocationName) function... `n" -ForegroundColor Green
	}
	Process {
		Write-Host "Check to see if module: $ModuleToUninstall is installed."
		if (Get-Module -ListAvailable -Name $ModuleToUninstall) {
			Write-Host "Module found, removing"
			Try {
				Get-Module $ModuleToUninstall | Uninstall-Module -AllVersions -Force
			}
			Catch {
				Write-Host "Unable to remove module: $ModuleToUninstall `n" -ForegroundColor Yellow
			}
		}
	}
	End {
		Write-Host "Ending: $($MyInvocation.Mycommand) `n" -ForegroundColor Green
	}
}

####################################################

Function Test-Administrator {
	$user = [Security.Principal.WindowsIdentity]::GetCurrent();
    (New-Object Security.Principal.WindowsPrincipal $user).IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)
}

####################################################

$listOfModules = @("Az.Accounts", "Microsoft.Graph.Identity.DirectoryManagement", "Microsoft.Graph", "Microsoft.Graph.Groups", "Microsoft.Graph.Intune")

Write-Host "Call function to prepare PSGallery pre-reqs... `n" -ForegroundColor Yellow
Set-PSGalleryPreReqs

# Call function to install the list of modules
Write-Host "Installing required modules... `n" -ForegroundColor Yellow
Invoke-ModuleInstall

#Install-Module -Name Az.Accounts -Force
$password = $AdminUserPW | ConvertTo-SecureString -asPlainText -Force
$creds = New-Object System.Management.Automation.PSCredential ($username, $password)

#Connect-AzAccount -AccountId $username | Out-Null
Connect-AzAccount -Credential $creds | Out-Null
Set-Location "$PSScriptRoot"
Try {
	$AADModule = Import-Module ".\AzureADPreview" -Force -ErrorAction Stop -PassThru
	$AzureADLicensingModule = Import-Module ".\AzureADLicensing" -Force -ErrorAction Stop -PassThru
}
Catch {
	Throw
}
Connect-AzureAD -Credential $creds | Out-Null

$tenant = Get-AzureADTenantDetail
$tenantFullName = $(($tenant.VerifiedDomains | Where-Object _Default).Name)
$tenantName = $tenant.DisplayName
$tenantID = $tenant.ObjectId
Write-Host "`nTennant Name: $tenantName with Tenant ID: $tenantID `n" -ForegroundColor Magenta

$m365License = Get-AADLicenseSku | Where-Object { $_.name -match "Microsoft 365 E5" }

$breakGlassUserName = "BreakGlass"
$licGroupName = "M365-E5-Licensing"
$userGroupName = "EUC-Global-Users"
$breakGlassGroupName = "CA-BreakGlassAccounts"
$adminsCAGroupName = "CA-Persona-HiSecCloudAdmins"

<#
# Create Update ring groups
Write-Host "Creating AAD group: EUC-Global-Updates-GAC-Stage-3-Group-A `n" -ForegroundColor Cyan
Try {
	New-AzureADMSGroup -DisplayName "EUC-Global-Updates-GAC-Stage-3-Group-A" -Description "EUC-Global-Updates-GAC-Stage-3-Group-A" -MailEnabled $False -MailNickname "EUC-Global-Updates-GAC-Stage-3-Group-A" -SecurityEnabled $True -IsAssignableToRole $False -Visibility "Public" -GroupTypes "DynamicMembership" -MembershipRule "(device.displayName -match ""[0-3]$"") or (device.displayName -match ""[A-H]$"")" -MembershipRuleProcessingState "On"
}
Catch { Throw }

Write-Host "Creating AAD group: EUC-Global-Updates-GAC-Stage-3-Group-B `n" -ForegroundColor Cyan
Try {
	New-AzureADMSGroup -DisplayName "EUC-Global-Updates-GAC-Stage-3-Group-B" -Description "EUC-Global-Updates-GAC-Stage-3-Group-B" -MailEnabled $False -MailNickname "EUC-Global-Updates-GAC-Stage-3-Group-B" -SecurityEnabled $True -IsAssignableToRole $False -Visibility "Public" -GroupTypes "DynamicMembership" -MembershipRule "(device.displayName -match ""[4-6]$"") or (device.displayName -match ""[I-R]$"")" -MembershipRuleProcessingState "On"
}
Catch { Throw }

Write-Host "Creating AAD group: EUC-Global-Updates-GAC-Stage-3-Group-C `n" -ForegroundColor Cyan
Try {
	New-AzureADMSGroup -DisplayName "EUC-Global-Updates-GAC-Stage-3-Group-C" -Description "EUC-Global-Updates-GAC-Stage-3-Group-C" -MailEnabled $False -MailNickname "EUC-Global-Updates-GAC-Stage-3-Group-C" -SecurityEnabled $True -IsAssignableToRole $False -Visibility "Public" -GroupTypes "DynamicMembership" -MembershipRule "(device.displayName -match ""[7-9]$"") or (device.displayName -match ""[S-Z]$"")" -MembershipRuleProcessingState "On"
}
Catch { Throw }
#>

# Prep password
If (-Not($NewUserPW)) {
	Write-Host "Using admin user password as new user password `n" -ForegroundColor Cyan
	$NewUserPW = $AdminUserPW
}

# Create Licensing group
If (-Not(Get-AzureADGroup -SearchString $licGroupName)) {
	Write-Host "Creating AAD group: $licGroupName `n" -ForegroundColor Cyan
	Try {
		New-AzureADGroup -DisplayName $licGroupName -Description "This group is used to assign M365 E5 licenses." -MailEnabled $false -MailNickName $licGroupName -SecurityEnabled $true -ErrorAction Stop
	}
	Catch { Throw }
}

# Create break-glass group
If (-Not(Get-AzureADGroup -SearchString $breakGlassGroupName)) {
	Write-Host "Creating AAD group: $breakGlassGroupName `n" -ForegroundColor Cyan
	Try {
		New-AzureADGroup -DisplayName $breakGlassGroupName -Description "This group is used to exclude from Conditional Access policies." -MailEnabled $false -MailNickName $breakGlassGroupName -SecurityEnabled $true -ErrorAction Stop
	}
	Catch { Throw }
}

# Create EUC-Global-Users CA targeting group
If (-Not(Get-AzureADGroup -SearchString $userGroupName)) {
	Write-Host "Creating AAD group: $userGroupName `n" -ForegroundColor Cyan
	Try {
		New-AzureADGroup -DisplayName $userGroupName -Description "This group is used for targeting EUC policies, apps and settings." -MailEnabled $false -MailNickName $UserGroupName -SecurityEnabled $true -ErrorAction Stop
	}
	Catch { Throw }
}

# Create CA-Persona-HiSecCloudAdmins CA targeting group
If (-Not(Get-AzureADGroup -SearchString $adminsCAGroupName)) {
	Write-Host "Creating AAD group: $adminsCAGroupName `n" -ForegroundColor Cyan
	Try {
		New-AzureADGroup -DisplayName $adminsCAGroupName -Description "This group is used for targeting Admin CA policies." -MailEnabled $false -MailNickName $adminsCAGroupName -SecurityEnabled $true -ErrorAction Stop
	}
	Catch { Throw }
}

# Create BreakGlass account
$azureADUser = Get-AzureADUser -SearchString $breakGlassUserName
If (-Not($azureADUser)) {
	Write-Host "Prep users `n" -ForegroundColor Green

	# Create user
	$PasswordProfile = New-Object -TypeName Microsoft.Open.AzureAD.Model.PasswordProfile
	$PasswordProfile.Password = $NewUserPW
	$PasswordProfile.ForceChangePasswordNextLogin = $false
	Try {
		Write-Host "Creating user: $breakGlassUserName@$tenantFullName `n" -ForegroundColor Cyan
		New-AzureADUser -DisplayName $breakGlassUserName -PasswordProfile $PasswordProfile -UserPrincipalName "$breakGlassUserName@$tenantFullName" -AccountEnabled $true -MailNickName $breakGlassUserName -UsageLocation "GB" -ErrorAction Stop
	}
	Catch { Throw }

	Write-Host "Pause for 30 seconds to allow new users to appear in the portal properly... `n" -ForegroundColor Yellow
	Start-Sleep -Seconds 30
}

# Read AAD group for licensing
$licensingGroup = Get-AzureADGroup -SearchString $licGroupName
If (-Not($licensingGroup)) { Throw "Error! Group not found: $licGroupName" }

#Apply license to licensing group
$license = Get-AADGroupLicenseAssignment -groupId $licensingGroup.ObjectId
If (-Not($license.licenses)) {
	Write-Host "Applying license to group"
	Try {
		Add-AADGroupLicenseAssignment -groupId $licensingGroup.ObjectId -accountSkuId $m365License.accountSkuId
	}
	Catch { Throw }
}

# Read EUC-Global-Users CA targeting group
$userGroup = Get-AzureADGroup -SearchString $userGroupName
If (-Not($userGroup )) { Throw "Error! Group not found: $userGroupName" }

# Read CA-Persona-HiSecCloudAdmins CA targeting group
$adminGroup = Get-AzureADGroup -SearchString $adminsCAGroupName
If (-Not($userGroup )) { Throw "Error! Group not found: $adminsCAGroupName" }

# Read AAD group for Break Glass
$breakGlassGroup = Get-AzureADGroup -SearchString $breakGlassGroupName
If (-Not($breakGlassGroup)) { Throw "Error! Group not found: $breakGlassGroupName" }

# Read AAD user and add to groups
$azureADAdminUser = Get-AzureADUser -SearchString $username
If (-Not($azureADAdminUser)) { Throw "Error! User not found: $username" }
Try {
	Write-Host "Adding user: $username to group: $licGroupName `n" -ForegroundColor Cyan
	Add-AzureADGroupMember -ObjectId "$($licensingGroup.ObjectId)" -RefObjectId "$($azureADAdminUser.ObjectId)" -ErrorAction Stop
}
Catch { Throw "Error: Adding user: $username to group: $licGroupName `n" }
Try {
	Write-Host "Adding user: $username to group: $adminsCAGroupName `n" -ForegroundColor Cyan
	Add-AzureADGroupMember -ObjectId "$($adminGroup.ObjectId)" -RefObjectId "$($azureADAdminUser.ObjectId)" -ErrorAction Stop
}
Catch { Throw "Error: Adding user: $username to group: $adminsCAGroupName `n" }

# Add BreakGlass account to Licensing group
$azureADUser = Get-AzureADUser -SearchString $breakGlassUserName
If (-Not($azureADUser)) { Throw "Error! User not found: $breakGlassUserName" }
Try {
	Write-Host "Adding user: $breakGlassUserName to group: $licGroupName `n" -ForegroundColor Cyan
	Add-AzureADGroupMember -ObjectId "$($licensingGroup.ObjectId)" -RefObjectId "$($azureADUser.ObjectId)" -ErrorAction Stop
}
Catch { Throw }

# Add BreakGlass account to break-glass group
Try {
	Write-Host "Adding user: $breakGlassUserName to group: $breakGlassGroupName `n" -ForegroundColor Cyan
	Add-AzureADGroupMember -ObjectId "$($breakGlassGroup.ObjectId)" -RefObjectId "$($azureADUser.ObjectId)" -ErrorAction Stop
}
Catch { Throw }

# Get GA role
Try {
	Write-Host "Enumerate GA Role `n" -ForegroundColor Cyan
	$gaRole = Get-AzureADDirectoryRole -Filter "Displayname eq 'Global Administrator'" -ErrorAction Stop
}
Catch { Throw }

# Add BreakGlass account to GA role
Try {
	Write-Host "Adding user: $breakGlassUserName to role: $($gaRole.DisplayName) `n" -ForegroundColor Cyan
	Add-AzureADDirectoryRoleMember -ObjectId "$($gaRole.ObjectId)" -RefObjectId "$($azureADUser.ObjectId)" -ErrorAction Stop
}
Catch { Throw }