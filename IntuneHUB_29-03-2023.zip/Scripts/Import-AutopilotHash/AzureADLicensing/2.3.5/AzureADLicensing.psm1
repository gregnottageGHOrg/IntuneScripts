﻿#Region '.\_PrefixCode.ps1' 0
# Code in here will be prepended to top of the psm1-file.
#EndRegion '.\_PrefixCode.ps1' 2
#Region '.\Private\Get-AuthToken.ps1' 0
function Get-AuthToken {
    [Cmdletbinding()]
    [OutputType([hashtable])]

    param()

    process {

        $context = Get-AzContext

        if ($null -eq $context) {
            $null = Connect-AZAccount -EA stop
            $context = Get-AzContext
        }

        $apiToken = [Microsoft.Azure.Commands.Common.Authentication.AzureSession]::Instance.AuthenticationFactory.Authenticate($context.Account, $context.Environment, $context.Tenant.Id, $null, "Never", $null, "74658136-14ec-4630-ad9b-26e160ff0fc6")

        $header = @{
            'Authorization'          = 'Bearer ' + $apiToken.AccessToken.ToString()
            'Content-Type'           = 'application/json'
            'X-Requested-With'       = 'XMLHttpRequest'
            'x-ms-client-request-id' = [guid]::NewGuid()
            'x-ms-correlation-id'    = [guid]::NewGuid()
        }

        Write-Verbose "Connected to tenant: '$($context.Tenant.Id)' as: '$($context.Account)'"

        return $header
    }
}
#EndRegion '.\Private\Get-AuthToken.ps1' 31
#Region '.\Public\Add-AADGroupLicenseAssignment.ps1' 0
function Add-AADGroupLicenseAssignment {

    [cmdletbinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory, HelpMessage = "ID of the Azure AD group")]
        [guid]$groupId,

        [Parameter(Mandatory, HelpMessage = "License SKU to assign")]
        [String]$accountSkuId,

        [Parameter(HelpMessage = "Excluded features for the specified SKU")]
        [String[]]$disabledServicePlans = @()
    )
    process {

        $licenceAssignmentConfig = @{
            assignments = @(
                @{
                    "objectId"       = "$groupId"
                    "isUser"         = $false
                    "addLicenses"    = @(
                        @{
                            "accountSkuId"         = "$accountSkuId"
                            "disabledServicePlans" = @($disabledServicePlans)
                        }
                    )
                    "removeLicenses" = @()
                    "updateLicenses" = @()
                }
            )
        }

        $requestBody = $licenceAssignmentConfig | ConvertTo-Json -Depth 5
        $baseUrl = "https://main.iam.ad.ext.azure.com/api/"

        if ($PSCmdlet.ShouldProcess($groupId, "Update license `"$accountSkuId`", disabled plans: `"$($disabledServicePlans -join `",`")`"")) {
            try {
                $response = Invoke-WebRequest -Method Post -Uri $($baseUrl + "AccountSkus/assign") -Headers $(Get-AuthToken) -Body $requestBody -ErrorAction Stop -UseBasicParsing
                $responseContent = $response | ConvertFrom-Json
                return $responseContent
            }
            catch {
                # convert the error message if it appears to be JSON
                if ($_.ErrorDetails.Message -like "{`"Classname*") {
                    $local:errmsg = $_.ErrorDetails.Message | ConvertFrom-Json
                    if ($local:errmsg.Clientdata.operationresults.details) {
                        Write-Error $local:errmsg.Clientdata.operationresults.details
                    }
                    else {
                        Write-Error $local:errmsg
                    }
                }
                else {
                    Write-Error $_
                }
            }
        }
    }
}
#EndRegion '.\Public\Add-AADGroupLicenseAssignment.ps1' 60
#Region '.\Public\Get-AADGroupLicenseAssignment.ps1' 0
function Get-AADGroupLicenseAssignment {
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, HelpMessage = "ID of the Azure AD group", ParameterSetName = "Single")]
        [guid]$groupId,

        [Parameter(Mandatory, HelpMessage = "Retrieves all Group Based License Assignments", ParameterSetName = "All")]
        [switch]
        $All
    )
    process {

        $baseUrl = "https://main.iam.ad.ext.azure.com/api/"

        try {

            if ($All.IsPresent) {

                $accountSkus = Get-AADLicenseSku
                $rep = @()

                foreach ($sku in $accountSkus){
                    $request = Invoke-WebRequest -Method Get -Uri $($baseUrl + "AccountSkus/GroupAssignments?accountSkuID=$($sku.accountSkuId)&nextLink=&searchText=&sortOrder=undefined") -Headers $(Get-AuthToken) -UseBasicParsing
                    $requestContent = $request | ConvertFrom-Json

                    $licensedGroups = $requestContent.items | Select-Object objectId, displayName

                    $rep += [PSCustomObject]@{
                        Name = $sku.Name
                        AccountSkuId = $sku.accountSkuId
                        LicensedGroups = $licensedGroups
                    }
                }

                return $rep

            }else {
                $request = Invoke-WebRequest -Method Get -Uri $($baseUrl + "AccountSkus/Group/$groupId") -Headers $(Get-AuthToken) -ErrorAction Stop -UseBasicParsing
                $requestContent = $request | ConvertFrom-Json
                return $requestContent
            }
        }
        catch {
            # convert the error message if it appears to be JSON
            if ($_.ErrorDetails.Message -like "{`"Classname*") {
                $local:errmsg = $_.ErrorDetails.Message | ConvertFrom-Json
                if ($local:errmsg.Clientdata.operationresults.details) {
                    Write-Error $local:errmsg.Clientdata.operationresults.details
                }
                else {
                    Write-Error $local:errmsg
                }
            }
            else {
                Write-Error $_
            }
        }
    }
}
#EndRegion '.\Public\Get-AADGroupLicenseAssignment.ps1' 60
#Region '.\Public\Get-AADLicenseSku.ps1' 0
function Get-AADLicenseSku {
    [cmdletbinding()]
    param()

    process {

        $baseUrl = "https://main.iam.ad.ext.azure.com/api/"

        try {
            $request = Invoke-WebRequest -Method Get -Uri $($baseUrl + "AccountSkus") -Headers $(Get-AuthToken) -UseBasicParsing
            $requestContent = $request | ConvertFrom-Json
            return $requestContent
        }
        catch {
            # convert the error message if it appears to be JSON
            if ($_.ErrorDetails.Message -like "{`"Classname*") {
                $local:errmsg = $_.ErrorDetails.Message | ConvertFrom-Json
                if ($local:errmsg.Clientdata.operationresults.details) {
                    Write-Error $local:errmsg.Clientdata.operationresults.details
                }
                else {
                    Write-Error $local:errmsg
                }
            }
            else {
                Write-Error $_
            }
        }
    }
}
#EndRegion '.\Public\Get-AADLicenseSku.ps1' 31
#Region '.\Public\Remove-AADGroupLicenseAssignment.ps1' 0
function Remove-AADGroupLicenseAssignment {

    [cmdletbinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory, HelpMessage = "ID of the Azure AD group")]
        [guid]$groupId,

        [Parameter(Mandatory, HelpMessage = "License SKU to remove")]
        [String]$accountSkuId
    )
    process {

        $licenceAssignmentConfig = @{
            assignments = @(
                @{
                    "objectId"       = "$groupId"
                    "isUser"         = $false
                    "addLicenses"    = @()
                    "removeLicenses" = @($accountSkuId)
                    "updateLicenses" = @()
                }
            )
        }

        $requestBody = $licenceAssignmentConfig | ConvertTo-Json -Depth 5
        $baseUrl = "https://main.iam.ad.ext.azure.com/api/"

        if ($PSCmdlet.ShouldProcess($groupId, "Remove license `"$accountSkuId`"")) {
            try {

                $response = Invoke-WebRequest -Method Post -Uri $($baseUrl + "AccountSkus/remove") -Headers $(Get-AuthToken) -Body $requestBody -ErrorAction Stop -UseBasicParsing
                $responseContent = $response | ConvertFrom-Json
                return $responseContent

            }
            catch {
                # convert the error message if it appears to be JSON
                if ($_.ErrorDetails.Message -like "{`"Classname*") {
                    $local:errmsg = $_.ErrorDetails.Message | ConvertFrom-Json
                    if ($local:errmsg.Clientdata.operationresults.details) {
                        Write-Error $local:errmsg.Clientdata.operationresults.details
                    }
                    else {
                        Write-Error $local:errmsg
                    }
                }
                else {
                    Write-Error $_
                }
            }
        }
    }
}
#EndRegion '.\Public\Remove-AADGroupLicenseAssignment.ps1' 54
#Region '.\Public\Update-AADGroupLicenseAssignment.ps1' 0
function Update-AADGroupLicenseAssignment {

    [cmdletbinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory, HelpMessage = "ID of the Azure AD group")]
        [guid]$groupId,

        [Parameter(Mandatory, HelpMessage = "License SKU to assign")]
        [String]$accountSkuId,

        [Parameter(HelpMessage = "Excluded features for the specified SKU")]
        [String[]]$disabledServicePlans = @()
    )
    process {

        $licenceAssignmentConfig = @{
            assignments = @(
                @{
                    "objectId"       = "$groupId"
                    "isUser"         = $false
                    "addLicenses"    = @()
                    "removeLicenses" = @()
                    "updateLicenses" = @(
                        @{
                            "accountSkuId"         = "$accountSkuId"
                            "disabledServicePlans" = @($disabledServicePlans)
                        }
                    )
                }
            )
        }



        $requestBody = $licenceAssignmentConfig | ConvertTo-Json -Depth 5
        $baseUrl = "https://main.iam.ad.ext.azure.com/api/"

        if ($PSCmdlet.ShouldProcess($groupId, "Update license `"$accountSkuId`", disabled plans: `"$($disabledServicePlans -join `",`")`"")) {
            try {

                $response = Invoke-WebRequest -Method Post -Uri $($baseUrl + "AccountSkus/update") -Headers $(Get-AuthToken) -Body $requestBody -ErrorAction Stop -UseBasicParsing
                $responseContent = $response | ConvertFrom-Json
                return $responseContent
            }
            catch {
                # convert the error message if it appears to be JSON
                if ($_.ErrorDetails.Message -like "{`"Classname*") {
                    $local:errmsg = $_.ErrorDetails.Message | ConvertFrom-Json
                    if ($local:errmsg.Clientdata.operationresults.details) {
                        Write-Error $local:errmsg.Clientdata.operationresults.details
                    }
                    else {
                        Write-Error $local:errmsg
                    }
                }
                else {
                    Write-Error $_
                }
            }
        }
    }
}
#EndRegion '.\Public\Update-AADGroupLicenseAssignment.ps1' 63
