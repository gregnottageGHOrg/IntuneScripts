#region Initialisation...
<#

.COPYRIGHT
Copyright (c) Microsoft Corporation. All rights reserved. Licensed under the MIT license.
See LICENSE in the project root for license information.

#>
####################################################
####################################################
#Instantiate Vars
####################################################

[CmdLetBinding(SupportsShouldProcess = $true)]
param (
    [Parameter(Mandatory, Position = 1, ValueFromPipelineByPropertyName = $true,
        ValueFromPipeline = $True,
        HelpMessage = 'Please specify Azure App Registration (Service Principle) Application (client) ID'
    )]
    [ValidateNotNullOrEmpty()]
    [string] $AppID,
    
    [Parameter(Position = 2, ValueFromPipelineByPropertyName = $true,
        ValueFromPipeline = $True,
        HelpMessage = 'Please specify Azure Tenant ID'
    )]
    [ValidateNotNullOrEmpty()]
    [string] $TenantID,

    [parameter(Mandatory = $true, ValueFromPipelineByPropertyName = $true,
        ValueFromPipeline = $True,
        HelpMessage = "Enter the Azure AD Admin Group name for Intune Role Members")]
    [ValidateNotNullOrEmpty()]
    [string]$AdminGroup,

    [parameter(Mandatory = $true, ValueFromPipelineByPropertyName = $true,
        ValueFromPipeline = $True,
        HelpMessage = "Enter the Intune RBAC role name")]
    [ValidateNotNullOrEmpty()]
    [string]$RBACRoleName,

    [parameter(ValueFromPipelineByPropertyName = $true,
        ValueFromPipeline = $True,
        HelpMessage = "Enter the Azure AD Scope Group name for Intune Role Scope")]
    [ValidateNotNullOrEmpty()]
    [string]$ScopeGroup = "allDevices",

    [parameter(ValueFromPipelineByPropertyName = $true,
        ValueFromPipeline = $True,
        HelpMessage = "Enter the Intune Scope Tag name")]
    [ValidateNotNullOrEmpty()]
    [string]$ScopeTag
)

$Global:exitCode = 0
$BuildVer = "1.0"
$ProgramFiles = $env:ProgramFiles
$ScriptName = $myInvocation.MyCommand.Name
$ScriptName = $ScriptName.Substring(0, $ScriptName.Length - 4)
$LogName = $ScriptName + "_" + (Get-Date -UFormat "%d-%m-%Y")
$logPath = "$($env:Temp)\$ScriptName"
$logFile = "$logPath\$LogName.log"
Add-Type -AssemblyName Microsoft.VisualBasic
$EventLogName = "Application"
$EventLogSource = $ScriptName

####################################################
####################################################
#Build Functions
####################################################

Function Start-Log {
    param (
        [string]$FilePath,

        [Parameter(HelpMessage = 'Deletes existing file if used with the -DeleteExistingFile switch')]
        [switch]$DeleteExistingFile
    )
		
    #Create Event Log source if it's not already found...
    $ErrorActionPreference = 'SilentlyContinue'
    If (!([system.diagnostics.eventlog]::SourceExists($EventLogSource))) { New-EventLog -LogName $EventLogName -Source $EventLogSource }
    $ErrorActionPreference = 'Continue'

    Try {
        If (!(Test-Path $FilePath)) {
            ## Create the log file
            New-Item $FilePath -Type File -Force | Out-Null
        }
            
        If ($DeleteExistingFile) {
            Remove-Item $FilePath -Force
        }
			
        ## Set the global variable to be used as the FilePath for all subsequent Write-Log
        ## calls in this session
        $global:ScriptLogFilePath = $FilePath
    }
    Catch {
        Write-Error $_.Exception.Message
    }
}

####################################################

Function Write-Log {
    #Write-Log -Message 'warning' -LogLevel 2
    #Write-Log -Message 'Error' -LogLevel 3
    param (
        [Parameter(Mandatory = $true)]
        [string]$Message,
			
        [Parameter()]
        [ValidateSet(1, 2, 3)]
        [int]$LogLevel = 1,

        [Parameter(HelpMessage = 'Outputs message to Event Log,when used with -WriteEventLog')]
        [switch]$WriteEventLog
    )
    Write-Host
    Write-Host $Message
    Write-Host
    $TimeGenerated = "$(Get-Date -Format HH:mm:ss).$((Get-Date).Millisecond)+000"
    $Line = '<![LOG[{0}]LOG]!><time="{1}" date="{2}" component="{3}" context="" type="{4}" thread="" file="">'
    $LineFormat = $Message, $TimeGenerated, (Get-Date -Format MM-dd-yyyy), "$($MyInvocation.ScriptName | Split-Path -Leaf):$($MyInvocation.ScriptLineNumber)", $LogLevel
    $Line = $Line -f $LineFormat
    Add-Content -Value $Line -Path $ScriptLogFilePath
    #If ($WriteEventLog) { Write-EventLog -LogName $EventLogName -Source $EventLogSource -Message $Message  -Id 100 -Category 0 -EntryType Information }
}

####################################################

function Test-Null($objectToCheck) {
    if ($null -eq $objectToCheck) {
        return $true
    }

    if ($objectToCheck -is [String] -and $objectToCheck -eq [String]::Empty) {
        return $true
    }

    if ($objectToCheck -is [DBNull] -or $objectToCheck -is [System.Management.Automation.Language.NullString]) {
        return $true
    }

    return $false
}

####################################################

function Invoke-Authentication {
    #Region Auth
    $body = @{
        Grant_Type    = "client_credentials"
        Scope         = "https://graph.microsoft.com/.default"
        Client_Id     = $AppID
        Client_Secret = $Secret
    }

    $connection = Invoke-RestMethod `
        -Uri https://login.microsoftonline.com/$TenantID/oauth2/v2.0/token `
        -Method POST `
        -Body $body

    $token = $connection.access_token

    Connect-MgGraph -AccessToken $token
    Select-MgProfile -Name "Beta"
    #endRegion Auth
}

####################################################

Function Invoke-FileDownload {
    #[CmdLetBinding(SupportsShouldProcess = $true)]
    param (
        [Parameter(Mandatory = $true, Position = 1, ValueFromPipelineByPropertyName = $true,
            ValueFromPipeline = $True,
            HelpMessage = 'Please provide web-path for file to download'
        )]
        [ValidateNotNullOrEmpty()]
        [string] $Download,

        [Parameter(Mandatory = $true, Position = 2, ValueFromPipelineByPropertyName = $true,
            ValueFromPipeline = $True,
            HelpMessage = 'Please provide output file path'
        )]
        [ValidateNotNullOrEmpty()]
        [string] $OutFile,

        [Parameter(Mandatory = $true, Position = 3, ValueFromPipelineByPropertyName = $true,
            ValueFromPipeline = $True,
            HelpMessage = 'Please provide eTagFile output path'
        )]
        [ValidateNotNullOrEmpty()]
        [string] $ETagFile
    )

    Begin {
        Write-Host "$($MyInvocation.InvocationName) function... `n" -ForegroundColor Green
        Write-Host "Processing download: $Download" -ForegroundColor Magenta
        Write-Host "Using output file: $OutFile" -ForegroundColor Magenta
        Write-Host "Using eTag file: $ETagFile `n" -ForegroundColor Magenta
    }

    Process {
        $webContent = Invoke-WebRequest -method "Head" $Download -UseBasicParsing
        # Get the current eTag of the file on the web:
        $eTag = ($webContent | Select-Object Headers -ExpandProperty Headers)["ETag"]
        # Get the current size of the file on the web:
        $contentLength = ($webContent | Select-Object Headers -ExpandProperty Headers)["Content-Length"]

        If (-Not(Test-Path -Path $OutFile)) {
            Write-Host "Local file not found, so downloading file: $OutFile `n" -ForegroundColor Yellow
            Invoke-WebRequest $Download -UseBasicParsing -OutFile $OutFile
            Start-Sleep -Seconds 2

            Unblock-File -Path $OutFile

            $eTag | Out-File -FilePath $ETagFile -Force
        }
        ElseIf ($(Get-Item -Path $OutFile).Length -ne $contentLength) {
            Write-Host "Local file size different, so downloading file: $OutFile `n" -ForegroundColor Yellow
            Invoke-WebRequest $Download -UseBasicParsing -OutFile $OutFile
            Start-Sleep -Seconds 2

            Unblock-File -Path $OutFile

            $eTag | Out-File -FilePath $ETagFile -Force
        }
        ElseIf (-Not(Test-Path -Path $ETagFile)) {
            Write-Host "eTag file not found, so downloading file: $OutFile `n" -ForegroundColor Yellow
            Invoke-WebRequest $Download -UseBasicParsing -OutFile $OutFile
            $eTag = (Invoke-WebRequest -method "Head" $Download | Select-Object Headers -ExpandProperty Headers)["ETag"]
            $eTag | Out-File -FilePath $ETagFile -Force
        }
        Else {
            Write-Host "eTag of file on the web is: $eTag `n" -ForegroundColor Magenta
        
            $existingETag = Get-Content -Path $ETagFile
            Write-Host "Existing eTag from local file is: $existingETag `n" -ForegroundColor Magenta

            # The If-None-Match header is what does the magic - downloads updated file if web eTag value doesn't match local eTagFile value
            Try {
                Invoke-WebRequest -method "get" $Download -Headers @{"If-None-Match" = $existingETag } -outfile $OutFile
            }
            Catch [System.Net.WebException] {
                Write-Host "File on web matches local file `n" -ForegroundColor Green
            }
            Catch {
                Exit 1
            }
        }
    }
}

####################################################

Function Invoke-GraphAuth {
    <#
    .SYNOPSIS
    Connects to Graph
    .PARAMETER AppID
    Azure App Registration (Service Principle) Application (client) ID
    .PARAMETER TenantID
    Azure Tenant ID
    .EXAMPLE
    Invoke-GraphAuth -AppID "" -TenantID ""

    Connects to interactively Graph using the specified AppID and TenantID GUIDs.
    #>
    [cmdletbinding()]
    param (
        [Parameter(Position = 1, ValueFromPipelineByPropertyName = $true,
            ValueFromPipeline = $True,
            HelpMessage = 'Please specify Azure App Registration (Service Principle) Application (client) ID'
        )]
        [ValidateNotNullOrEmpty()]
        [string] $AppID,
        
        [Parameter(Position = 2, ValueFromPipelineByPropertyName = $true,
            ValueFromPipeline = $True,
            HelpMessage = 'Please specify Azure Tenant ID'
        )]
        [ValidateNotNullOrEmpty()]
        [string] $TenantID
    )

    Begin {
        Write-Host "Starting $($MyInvocation.InvocationName) function... `n" -ForegroundColor Green
    }
    Process {
        Write-Host "Login interactively, using Service Principle `n" -ForegroundColor Magenta
        #$loginURL = 'https://login.microsoftonline.com'
        #$authURL = "$loginURL/$TenantID"
        #Write-Host "LoginURL: $loginURL"
        #Region Auth
        #Set-Location -Path $PSScriptRoot
        $msalDLL = "$PSScriptRoot\Microsoft.Identity.Client.dll"
        If (-Not(Test-Path -Path $msalDLL)) {
            Write-Host "File not found: $msalDLL, downloading... `n" -ForegroundColor Yellow
            $downloadURL = "https://raw.githubusercontent.com/shawntabrizi/Microsoft-Authentication-with-PowerShell-and-MSAL/master/MSAL/Microsoft.Identity.Client.dll"
            
            $eTagFile = "$PSScriptRoot\etag.tag"
            Invoke-FileDownload -Download $downloadURL -OutFile $msalDLL -ETagFile $eTagFile
        }   

        # Load MSAL
        Add-Type -Path $msalDLL

        # Application and Tenant Configuration
        #$login = "https://login.microsoftonline.com/"
        #$login = $loginURL
        #$redirectUri = New-Object system.uri("https://login.microsoftonline.com/common/oauth2/nativeclient")

        # Define the resources and scopes you want to call
        $scopes = New-Object System.Collections.ObjectModel.Collection["string"]
        $scopes.Add("https://graph.microsoft.com/.default")

        # Get an Access Token with MSAL
        #$app = New-Object Microsoft.Identity.Client.PublicClientApplication($AppID, ($login + $TenantID))
        $app = New-Object Microsoft.Identity.Client.PublicClientApplication($AppID, ($authURL))
        $authenticationResult = $app.AcquireTokenAsync($scopes).GetAwaiter().GetResult()

        Connect-MgGraph -AccessToken $authenticationResult.AccessToken
        Select-MgProfile -Name "Beta"
        #endRegion Auth
    }
    End {
        Write-Host "`nEnding: $($MyInvocation.Mycommand) `n" -ForegroundColor Green
    }
}

####################################################

Function Set-PSGalleryPreReqs {
    Begin {
        Write-Host "Starting $($MyInvocation.InvocationName) function... `n" -ForegroundColor Green
    }
    Process {
        Write-Host "Preparing PSGallery pre-reqs... `n" -ForegroundColor Magenta

        #Check for NuGet Package Provider installed on machine
        if ((Get-PackageProvider -ListAvailable).name -eq "NuGet") {
            #check if Nuget is installed on the machine
            $nuget = Get-PackageProvider -Name Nuget

            if ($nuget.version -eq ((find-PackageProvider -name nuget).version)) {
                #check for latest version    
                Write-Host "NuGet is up to date `n" -ForegroundColor Green
            }
            else {
                try {
                    Install-PackageProvider -name nuget -Force -confirm:$False -ErrorAction Stop
                    Write-Host "NuGet Package Provider is installed `n" -ForegroundColor Green    
                }
                catch {
                    Throw
                }    
            }
        }
        else {
            try {
                Write-Host "Running command 'Install-PackageProvider -name nuget -Force -confirm:`$false' `n" -ForegroundColor Yellow
                Install-PackageProvider -name nuget -Force -confirm:$false -ErrorAction Stop
                Write-Host "`nNuGet Package Provider is installed `n" -ForegroundColor Green
            }
            catch {
                Throw        
            }
        }

        #Register the PSGallery repository and set the installation policy to trusted
        Write-Host "Checking Get-PSRepository for PSGallery... `n" -ForegroundColor Magenta

        $psRepo = Get-PSRepository
        foreach ($repo in $psrepo) { 
            Write-Host "`nRepo name: $($repo.name) with installation policy: $($repo.InstallationPolicy)`n"
            If (($($repo.name) -eq "PSGallery") -and ($($repo.InstallationPolicy) -ne "Trusted")) {
                Write-Host "PSGallery currently untrusted, setting it to trusted. `n" -ForegroundColor Yellow
                #<#
                Try {
                    Write-Host "Set PSGallery to trusted `n" -ForegroundColor Yellow
                    Set-PSRepository -name "PSGallery" -InstallationPolicy Trusted
                }
                Catch {
                    Throw
                }
                $found = $True
                Write-Host "PSGallery Repository installation policy set to trusted `n" -ForegroundColor Green
                #>
            }
            ElseIf (($($repo.name) -eq "PSGallery") -and ($($repo.InstallationPolicy) -eq "Trusted")) {
                $found = $True
                Write-Host "PSGallery Repository installation policy already set to trusted `n" -ForegroundColor Green
            }
        }

        If (-Not($found)) {
            Write-Host "PSGallery repo not found `n" -ForegroundColor Yellow 
            Try {
                Write-Host "Register PSGallery as trusted `n" -ForegroundColor Yellow
                Register-PSRepository -Default -InstallationPolicy Trusted
            }
            Catch {
                Throw
            }
            Write-Host "Default PS Repository registered and installation policy set to trusted `n" -ForegroundColor Green
        }
        
        <#
        If ((Get-PSRepository).name -eq "PSGallery") {
            Try {
                Write-Host "Set PSGallery to trusted `n" -ForegroundColor Yellow
                Set-PSRepository -name "PSGallery" -InstallationPolicy Trusted
            }
            Catch {
                Throw
            }
            Write-Host "PSGallery Repository installation policy set to trusted `n" -ForegroundColor Green
        }
        else {
            Try {
                Write-Host "Register PSGallery as trusted `n" -ForegroundColor Yellow
                Register-PSRepository -Default -InstallationPolicy Trusted
            }
            Catch {
                Throw
            }
            Write-Host "default PS Repository registered and installation policy set to trusted `n" -ForegroundColor Green
        }
        #>

        #Update PackageManagement module
        Try {
            Write-Host "Check for PackageManagement module `n" -ForegroundColor Yellow
            #Install-Module -Name PackageManagement -Force -MinimumVersion 1.4.6 -Repository PSGallery -ErrorAction SilentlyContinue
            Update-EveryModule -ExcludedModules $listOfModules
            Import-PSModule -ModuleToLoad "PackageManagement"
            Write-Host "PackageManagement module is installed `n" -ForegroundColor Green
        }
        Catch {
            Throw
        }        
    }
    End {
        Write-Host "Ending: $($MyInvocation.Mycommand) `n" -ForegroundColor Green
    }
}

####################################################

Function Import-PSModule {
    <#
            .SYNOPSIS
        Cmdlet for loading modules single or multiple modules



            .DESCRIPTION
                    This function will import modules, load and or install modules from a PowerShell Repository



            .PARAMETER ModuleToLoad
                    Modules to load



    .EXAMPLE
        PS C:\> Import-PSModules -ModuleToLoad Foo



                    Imports the Foo module



    .NOTES
        NOTE: You can not pull up the help information until the object has been imported
    #>

    [cmdletbinding()]
    param(
        [object]$moduleToLoad
    )

    Begin {
        Write-Host "Starting $($MyInvocation.InvocationName) function... `n" -ForegroundColor Green
    }
    Process {
        Write-Host "Check to see if module: $ModuleToLoad is already imported `n" -ForegroundColor Yellow
        if (Get-Module -Name $moduleToLoad) {
            $mod = Get-Module -Name $moduleToLoad | Select-Object Name, Version
            Write-Host "Module already installed: $mod `n" -ForegroundColor Green
        }
        else {
            Write-Host "If module is not imported, but available on disk then import it `n" -ForegroundColor Yellow
            Write-Host "This will check all of the available modules in the module paths `n" -ForegroundColor Yellow
            if (Get-Module -ListAvailable -Name $moduleToLoad) {
                $mod = Get-Module -ListAvailable -Name $moduleToLoad | Select-Object Name, Version
                Write-Host "Module details: $mod `n" -ForegroundColor Green
            }
            else {
                try {
                    Write-Host "If module is not imported, not available on disk, but is in online gallery then install and import `n" -ForegroundColor Yellow
                    if (Find-Module -Name $moduleToLoad) {
                        Write-Host "If the module is found, try to install it `n" -ForegroundColor Yellow
                        Write-Host "Using command: Install-Module -Name $moduleToLoad -AcceptLicense -AllowClobber -Force `n" -ForegroundColor Yellow
                        
                        If (Test-Administrator) {
                            Install-Module -Name $moduleToLoad -AcceptLicense -AllowClobber -Force
                        }
                        Else {
                            Install-Module -Name $moduleToLoad -Scope CurrentUser -AcceptLicense -AllowClobber -Force
                        }

                        $mod = Get-Module -ListAvailable -Name $moduleToLoad | Select-Object Name, Version
                        Write-Host "Licensed module now installed: $mod `n" -ForegroundColor Green
                    }
                    else {
                        Write-Host "Module is not imported, not available and not in online gallery, aborting"
                        Throw
                    }
                }
                Catch [System.Management.Automation.ParameterBindingException] {
                    Write-Host "Module did not install with -AcceptLicense parameter, trying without.`n" -ForegroundColor Yellow
                    Write-Host "Using command: Install-Module -Name $moduleToLoad -AllowClobber -Force `n" -ForegroundColor Yellow
                    If (Test-Administrator) {
                        Install-Module -Name $moduleToLoad -AllowClobber -Force
                    }
                    Else {
                        Install-Module -Name $moduleToLoad -Scope CurrentUser -AllowClobber -Force
                    }

                    $mod = Get-Module -ListAvailable -Name $moduleToLoad | Select-Object Name, Version
                    Write-Host "Module now installed: $mod `n" -ForegroundColor Green
                }
                catch {
                    Throw
                }
            }
        }
    }
    End {
        Write-Host "Ending: $($MyInvocation.Mycommand) `n" -ForegroundColor Green
    }
}

####################################################

function Update-EveryModule {
    <#
    .SYNOPSIS
    Updates all modules from the PowerShell gallery.
    .DESCRIPTION
    Updates all local modules that originated from the PowerShell gallery.
    Removes all old versions of the modules.
    .PARAMETER ExcludedModules
    Array of modules to exclude from updating.
    .PARAMETER SkipMajorVersion
    Skip major version updates to account for breaking changes.
    .PARAMETER KeepOldModuleVersions
    Array of modules to keep the old versions of.
    .PARAMETER ExcludedModulesforRemoval
    Array of modules to exclude from removing old versions of.
    The Az module is (not) excluded by default.
    .EXAMPLE
    Update-EveryModule -excludedModulesforRemoval 'Az'
    .NOTES
    Created by Barbara Forbes
    @ba4bes
    .LINK
    https://4bes.nl
    #>
    [cmdletbinding(SupportsShouldProcess = $true)]
    param (
        [parameter()]
        [array]$ExcludedModules = @(),
        [parameter()]
        [switch]$SkipMajorVersion,
        [parameter()]
        [switch]$KeepOldModuleVersions,
        [parameter()]
        [array]$ExcludedModulesforRemoval = @()
        #[array]$ExcludedModulesforRemoval = @("Az")
    )
    # Get all installed modules that have a newer version available
    Write-Verbose "Checking all installed modules for available updates."
    $CurrentModules = Get-InstalledModule | Where-Object { $ExcludedModules -notcontains $_.Name -and $_.repository -eq "PSGallery" }

    # Walk through the Installed modules and check if there is a newer version
    $CurrentModules | ForEach-Object {
        Write-Verbose "Checking $($_.Name)"
        Try {
            $GalleryModule = Find-Module -Name $_.Name -Repository PSGallery -ErrorAction Stop
        }
        Catch {
            Write-Error "Module $($_.Name) not found in gallery $_"
            $GalleryModule = $null
        }
        if ($GalleryModule.Version -gt $_.Version) {
            if ($SkipMajorVersion -and $GalleryModule.Version.Split('.')[0] -gt $_.Version.Split('.')[0]) {
                Write-Warning "Skipping major version update for module $($_.Name). Galleryversion: $($GalleryModule.Version), local version $($_.Version)"
            }
            else {
                Write-Verbose "$($_.Name) will be updated. Galleryversion: $($GalleryModule.Version), local version $($_.Version)"
                try {
                    if ($PSCmdlet.ShouldProcess(
                        ("Module {0} will be updated to version {1}" -f $_.Name, $GalleryModule.Version),
                            $_.Name,
                            "Update-Module"
                        )
                    ) {
                        Update-Module $_.Name -ErrorAction Stop -Force
                        Write-Verbose "$($_.Name)  has been updated"
                    }
                }
                Catch {
                    Write-Error "$($_.Name) failed: $_ "
                    continue

                }
                if ($KeepOldModuleVersions -ne $true) {
                    Write-Verbose "Removing old module $($_.Name)"
                    if ($ExcludedModulesforRemoval -contains $_.Name) {
                        Write-Verbose "$($allversions.count) versions of this module found [ $($module.name) ]"
                        Write-Verbose "Please check this manually as removing the module can cause instabillity."
                    }
                    else {
                        try {
                            if ($PSCmdlet.ShouldProcess(
                                ("Old versions will be uninstalled for module {0}" -f $_.Name),
                                    $_.Name,
                                    "Uninstall-Module"
                                )
                            ) {
                                Get-InstalledModule -Name $_.Name -AllVersions | Where-Object { $_.version -ne $GalleryModule.Version } | Uninstall-Module -Force -ErrorAction Stop
                                Write-Verbose "Old versions of $($_.Name) have been removed"
                            }
                        }
                        catch {
                            Write-Error "Uninstalling old module $($_.Name) failed: $_"
                        }
                    }
                }
            }
        }
        elseif ($null -ne $GalleryModule) {
            Write-Verbose "$($_.Name) is up to date"
        }
    }
}

####################################################

Function Invoke-ModuleInstall {
    Begin {
        Write-Host "Starting $($MyInvocation.InvocationName) function... `n" -ForegroundColor Green
    }
    Process {
        Write-Host "Performing module install steps `n" -ForegroundColor Magenta
    
        foreach ($module in $listOfModules) {
            Write-Host "Importing module: $module `n" -ForegroundColor Yellow 
            Import-PSModule -moduleToLoad $module   
        }       
    }
    End {
        Write-Host "Ending: $($MyInvocation.Mycommand) `n" -ForegroundColor Green
    }    
}

####################################################

Function Uninstall-PSModule {
    <#
            .SYNOPSIS
        Cmdlet for unloading modules single or multiple modules

            .DESCRIPTION
                    This function will uninstall modules

            .PARAMETER ModuleToUninstall
                    Modules to load

    .EXAMPLE
        PS C:\> Import-PSModules -ModuleToUninstall Foo

                    Removes the Foo module

    .NOTES
        NOTE: You can not pull up the help information until the object has been imported
    #>

    [cmdletbinding()]
    param(
        [object]$moduleToUninstall
    )

    Begin {
        Write-Host "Starting $($MyInvocation.InvocationName) function... `n" -ForegroundColor Green
    }
    Process {
        Write-Host "Check to see if module: $ModuleToUninstall is installed."
        if (Get-Module -ListAvailable -Name $ModuleToUninstall) {
            Write-Host "Module found, removing"
            Try {
                Get-Module $ModuleToUninstall | Uninstall-Module -AllVersions -Force
            }
            Catch {
                Write-Host "Unable to remove module: $ModuleToUninstall `n" -ForegroundColor Yellow
            }
        }
    }
    End {
        Write-Host "Ending: $($MyInvocation.Mycommand) `n" -ForegroundColor Green
    }
}

####################################################

Function Test-Administrator {  
    $user = [Security.Principal.WindowsIdentity]::GetCurrent();
    (New-Object Security.Principal.WindowsPrincipal $user).IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)  
}

####################################################

Function Test-AuthToken() {


    [cmdletbinding()]
    
    param
    (
        [Parameter(Mandatory = $true,
            HelpMessage = 'Please specify your user principal name for Azure Authentication')]
        $User
    )
    
    # Checking if authToken exists before running authentication
    if ($global:authToken) {
    
        # Setting DateTime to Universal time to work in all timezones
        $DateTime = (Get-Date).ToUniversalTime()
    
        # If the authToken exists checking when it expires
        $TokenExpires = ($authToken.ExpiresOn.datetime - $DateTime).Minutes
    
        if ($TokenExpires -le 0) {
    
            write-host "Authentication Token expired" $TokenExpires "minutes ago" -ForegroundColor Yellow
            write-host
    
            # Defining Azure AD tenant name, this is the name of your Azure Active Directory (do not use the verified domain name)
    
            if ($User -eq $null -or $User -eq "") {
    
                $Global:User = Read-Host -Prompt "Please specify your user principal name for Azure Authentication"
                Write-Host
    
            }
    
            $global:authToken = Get-AuthToken -User $User
    
        }
    }
    
    # Authentication doesn't exist, calling Get-AuthToken function
    
    else {
    
        if ($User -eq $null -or $User -eq "") {
    
            $Global:User = Read-Host -Prompt "Please specify your user principal name for Azure Authentication"
            Write-Host
    
        }
    
        # Getting the authorization token
        $global:authToken = Get-AuthToken -User $User
    
    }
    $NULL = Connect-AzureAD -AccountId $User
}
    
####################################################

function Get-AuthToken {

    <#
    .SYNOPSIS
    This function is used to authenticate with the Graph API REST interface
    .DESCRIPTION
    The function authenticate with the Graph API Interface with the tenant name
    .EXAMPLE
    Get-AuthToken
    Authenticates you with the Graph API interface
    .NOTES
    NAME: Get-AuthToken
    #>
    
    [cmdletbinding()]
    
    param
    (
        [Parameter(Mandatory = $true)]
        $User
    )
    
    $userUpn = New-Object "System.Net.Mail.MailAddress" -ArgumentList $User
    
    $tenant = $userUpn.Host
    
    Write-Host "Checking for AzureAD module..."
    
    $AadModule = Get-Module -Name "AzureADPreview" -ListAvailable
    
    
    if ($AadModule -eq $null) {
        write-host
        write-host "AzureAD Powershell module not installed..." -f Red
        write-host "Install by running 'Install-Module AzureAD' or 'Install-Module AzureADPreview' from an elevated PowerShell prompt" -f Yellow
        write-host "Script can't continue..." -f Red
        write-host
        exit
    }
    
    <#
    if ($AadModule -eq $null) {
        write-host
        write-host "AzureAD Powershell module not installed..." -f Red
        write-host "Attempting module install now (requires Admin rights!)" -f Red
        Install-Module -Name AzureAD -AllowClobber -Scope CurrentUser -Force
        write-host
    }
    #>
    # Getting path to ActiveDirectory Assemblies
    # If the module count is greater than 1 find the latest version
    
    if ($AadModule.count -gt 1) {
    
        $Latest_Version = ($AadModule | select version | Sort-Object)[-1]
    
        $aadModule = $AadModule | ? { $_.version -eq $Latest_Version.version }
    
        # Checking if there are multiple versions of the same module found
    
        if ($AadModule.count -gt 1) {
    
            $aadModule = $AadModule | select -Unique
    
        }
    
        $adal = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.dll"
        $adalforms = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.Platform.dll"
    
    }
    
    else {
    
        $adal = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.dll"
        $adalforms = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.Platform.dll"
    
    }
    
    [System.Reflection.Assembly]::LoadFrom($adal) | Out-Null
    
    [System.Reflection.Assembly]::LoadFrom($adalforms) | Out-Null
    
    $clientId = "d1ddf0e4-d672-4dae-b554-9d5bdfd93547"
    
    $redirectUri = "urn:ietf:wg:oauth:2.0:oob"
    
    $resourceAppIdURI = "https://graph.microsoft.com"
    
    $authority = "https://login.microsoftonline.com/$Tenant"
    
    try {
    
        $authContext = New-Object "Microsoft.IdentityModel.Clients.ActiveDirectory.AuthenticationContext" -ArgumentList $authority
    
        # https://msdn.microsoft.com/en-us/library/azure/microsoft.identitymodel.clients.activedirectory.promptbehavior.aspx
        # Change the prompt behaviour to force credentials each time: Auto, Always, Never, RefreshSession
    
        $platformParameters = New-Object "Microsoft.IdentityModel.Clients.ActiveDirectory.PlatformParameters" -ArgumentList "Auto"
    
        $userId = New-Object "Microsoft.IdentityModel.Clients.ActiveDirectory.UserIdentifier" -ArgumentList ($User, "OptionalDisplayableId")
    
        $authResult = $authContext.AcquireTokenAsync($resourceAppIdURI, $clientId, $redirectUri, $platformParameters, $userId).Result
    
        # If the accesstoken is valid then create the authentication header
    
        if ($authResult.AccessToken) {
    
            # Creating header for Authorization token
    
            $authHeader = @{
                'Content-Type'  = 'application/json'
                'Authorization' = "Bearer " + $authResult.AccessToken
                'ExpiresOn'     = $authResult.ExpiresOn
            }
    
            return $authHeader
    
        }
    
        else {
    
            Write-Host
            Write-Host "Authorization Access Token is null, please re-run authentication..." -ForegroundColor Red
            Write-Host
            break
    
        }
    
    }
    
    catch {
    
        write-host $_.Exception.Message -f Red
        write-host $_.Exception.ItemName -f Red
        write-host
        break
    
    }
    
}
     
####################################################

Function Test-JSON() {

    <#
.SYNOPSIS
This function is used to test if the JSON passed to a REST Post request is valid
.DESCRIPTION
The function tests if the JSON passed to the REST Post is valid
.EXAMPLE
Test-JSON -JSON $JSON
Test if the JSON is valid before calling the Graph REST interface
.NOTES
NAME: Test-JSON
#>

    param (

        $JSON

    )

    try {

        $TestJSON = ConvertFrom-Json $JSON -ErrorAction Stop
        $validJson = $true

    }

    catch {

        $validJson = $false
        $_.Exception

    }

    if (!$validJson) {
    
        Write-Host "Provided JSON isn't in valid JSON format" -f Red
        break

    }

}

####################################################

Function Get-AADGroupName() {

    <#
    .SYNOPSIS
    This function is used to get AAD Groups from the Graph API REST interface
    .DESCRIPTION
    The function connects to the Graph API Interface and gets any Groups registered with AAD
    .EXAMPLE
    Get-AADGroupName
    Returns all users registered with Azure AD
    .NOTES
    NAME: Get-AADGroupName
    #>
    
    [cmdletbinding()]
    
    param
    (
        $GroupName,
        $id,
        [switch]$Members
    )
    
    # Defining Variables
    $graphApiVersion = "v1.0"
    $Group_resource = "groups"
        
    try {
    
        if ($id) {
    
            $uri = "https://graph.microsoft.com/$graphApiVersion/$($Group_resource)?`$filter=id eq '$id'"
            #(Invoke-RestMethod -Uri $uri -Headers $authToken -Method Get).Value

            $response = Invoke-MgGraphRequest -Uri "$uri" -Method GET
            #$response | Format-List *
            Return $response.Value
    
        }
            
        elseif ($GroupName -eq "" -or $GroupName -eq $null) {
            
            $uri = "https://graph.microsoft.com/$graphApiVersion/$($Group_resource)"
            #(Invoke-RestMethod -Uri $uri -Headers $authToken -Method Get).Value

            $response = Invoke-MgGraphRequest -Uri "$uri" -Method GET
            #$response | Format-List *
            Return $response.Value
            
        }
    
        else {
                
            if (!$Members) {
    
                $uri = "https://graph.microsoft.com/$graphApiVersion/$($Group_resource)?`$filter=displayname eq '$GroupName'"
                #(Invoke-RestMethod -Uri $uri -Headers $authToken -Method Get).Value

                $response = Invoke-MgGraphRequest -Uri "$uri" -Method GET
                #$response | Format-List *
                Return $response.Value
                
            }
                
            elseif ($Members) {
                
                $uri = "https://graph.microsoft.com/$graphApiVersion/$($Group_resource)?`$filter=displayname eq '$GroupName'"
                #$Group = (Invoke-RestMethod -Uri $uri -Headers $authToken -Method Get).Value

                $Group = (Invoke-MgGraphRequest -Uri "$uri" -Method GET).Value
                #$response | Format-List *
                
                
                if ($Group) {
    
                    $GID = $Group.id
    
                    $Group.displayName
                    write-host
    
                    $uri = "https://graph.microsoft.com/$graphApiVersion/$($Group_resource)/$GID/Members"
                    #(Invoke-RestMethod -Uri $uri -Headers $authToken -Method Get).Value
                    
                    $response = Invoke-MgGraphRequest -Uri "$uri" -Method GET
                    Return $response.Value
                }
    
            }
            
        }
    
    }
    
    catch {
    
        $ex = $_.Exception
        $errorResponse = $ex.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($errorResponse)
        $reader.BaseStream.Position = 0
        $reader.DiscardBufferedData()
        $responseBody = $reader.ReadToEnd();
        Write-Host "Response content:`n$responseBody" -f Red
        Write-Error "Request to $Uri failed with HTTP Status $($ex.Response.StatusCode) $($ex.Response.StatusDescription)"
        write-host
        break
    
    }
    
}
    
####################################################
    
Function Add-RBACRole() {
    
    <#
    .SYNOPSIS
    This function is used to add an RBAC Role Definitions from the Graph API REST interface
    .DESCRIPTION
    The function connects to the Graph API Interface and adds an RBAC Role Definitions
    .EXAMPLE
    Add-RBACRole -JSON $JSON
    .NOTES
    NAME: Add-RBACRole
    #>
    
    [cmdletbinding()]
    
    param
    (
        $JSON
    )
    
    $graphApiVersion = "Beta"
    $Resource = "deviceManagement/roleDefinitions"
        
    try {
    
        if (!$JSON) {
    
            write-host "No JSON was passed to the function, provide a JSON variable" -f Red
            break
    
        }
    
        Test-JSON -JSON $JSON
        
        $uri = "https://graph.microsoft.com/$graphApiVersion/$($Resource)"
        Invoke-RestMethod -Uri $uri -Headers $authToken -Method Post -Body $Json -ContentType "application/json"
        
    }
        
    catch {
    
        $ex = $_.Exception
        $errorResponse = $ex.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($errorResponse)
        $reader.BaseStream.Position = 0
        $reader.DiscardBufferedData()
        $responseBody = $reader.ReadToEnd();
        Write-Host "Response content:`n$responseBody" -f Red
        Write-Error "Request to $Uri failed with HTTP Status $($ex.Response.StatusCode) $($ex.Response.StatusDescription)"
        write-host
        break
    
    }
    
}
    
####################################################
    
Function Assign-RBACRole() {
    
    <#
    .SYNOPSIS
    This function is used to set an assignment for an RBAC Role using the Graph API REST interface
    .DESCRIPTION
    The function connects to the Graph API Interface and sets and assignment for an RBAC Role
    .EXAMPLE
    Assign-RBACRole -Id $IntuneRoleID -DisplayName "Assignment" -MemberGroupId $MemberGroupId -TargetGroupId $TargetGroupId
    Creates and Assigns and Intune Role assignment to an Intune Role in Intune
    .NOTES
    NAME: Assign-RBACRole
    #>
    
    [cmdletbinding()]
    
    param
    (
        $Id,
        $DisplayName,
        $MemberGroupId,
        $TargetGroupId
    )
    
    $graphApiVersion = "Beta"
    $Resource = "deviceManagement/roleAssignments"
        
    try {
    
        if (!$Id) {
    
            write-host "No Policy Id specified, specify a valid Id" -f Red
            break
    
        }
    
        if (!$DisplayName) {
    
            write-host "No Display Name specified, specify a Display Name" -f Red
            break
    
        }
    
        if (!$MemberGroupId) {
    
            write-host "No Member Group Id specified, specify a valid Id" -f Red
            break
    
        }
    
        <#
        if (!$TargetGroupId) {
    
            write-host "No Target Group Id specified, specify a valid Id" -f Red
            break
    
        }
        #>

        If ($TargetGroupId -eq "allDevices") {
            Write-Host "Using allDevices targeting" -ForegroundColor Cyan
            $JSON = @"
        {
        "id":"",
        "description":"",
        "displayName":"$DisplayName",
        "members":["$MemberGroupId"],
        "scopeMembers": [],
        "scopeType": "allDevices",
        "roleDefinition@odata.bind":"https://graph.microsoft.com/beta/deviceManagement/roleDefinitions('$ID')"
        }
"@
        }
        Else {
            $JSON = @"
        {
        "id":"",
        "description":"",
        "displayName":"$DisplayName",
        "members":["$MemberGroupId"],
        "scopeMembers":["$TargetGroupId"],
        "roleDefinition@odata.bind":"https://graph.microsoft.com/beta/deviceManagement/roleDefinitions('$ID')"
        }
"@
        }

        <#
{
    "@odata.context": "https://graph.microsoft.com/beta/$metadata#deviceManagement/roleAssignments",
    "@odata.count": 1,
    "value": [
        {
            "id": "7ead26cc-20a4-4a57-9571-62e22cab0987",
            "displayName": "Autopilot Hardware Hash Import Assignment",
            "description": "",
            "scopeMembers": [],
            "scopeType": "allDevices",
            "resourceScopes": [],
            "members": [
                "eff99957-db7b-4f95-95e2-af43fac132ee"
            ]
        }
    ]
}
#>
    
        $uri = "https://graph.microsoft.com/$graphApiVersion/$Resource"
        #Invoke-RestMethod -Uri $uri -Headers $authToken -Method Post -Body $JSON -ContentType "application/json"

        Invoke-MgGraphRequest -Uri "$uri" -Method POST -Body $JSON -ContentType "application/json"
        
    }
        
    catch {
    
        Throw
        <#
        $ex = $_.Exception
        $errorResponse = $ex.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($errorResponse)
        $reader.BaseStream.Position = 0
        $reader.DiscardBufferedData()
        $responseBody = $reader.ReadToEnd();
        Write-Host "Response content:`n$responseBody" -f Red
        Write-Error "Request to $Uri failed with HTTP Status $($ex.Response.StatusCode) $($ex.Response.StatusDescription)"
        write-host
        break
        #>
    
    }
    
}
    
####################################################

Function Get-RBACRole() {

    <#
.SYNOPSIS
This function is used to get RBAC Role Definitions from the Graph API REST interface
.DESCRIPTION
The function connects to the Graph API Interface and gets any RBAC Role Definitions
.EXAMPLE
Get-RBACRole
Returns any RBAC Role Definitions configured in Intune
.NOTES
NAME: Get-RBACRole
#>

    $graphApiVersion = "v1.0"
    $Resource = "deviceManagement/roleDefinitions"
    
    try {
    
        $uri = "https://graph.microsoft.com/$graphApiVersion/$($Resource)"
        #(Invoke-RestMethod -Uri $uri -Headers $authToken -Method Get).Value

        $response = Invoke-MgGraphRequest -Uri "$uri" -Method GET
        #$response | Format-List *
        Return $response.Value
    }
    
    catch {

        $ex = $_.Exception
        $errorResponse = $ex.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($errorResponse)
        $reader.BaseStream.Position = 0
        $reader.DiscardBufferedData()
        $responseBody = $reader.ReadToEnd();
        Write-Host "Response content:`n$responseBody" -f Red
        Write-Error "Request to $Uri failed with HTTP Status $($ex.Response.StatusCode) $($ex.Response.StatusDescription)"
        write-host
        break

    }

}

####################################################

Function Get-ScopeTagAssignment() {

    <#
        .SYNOPSIS
        This function is used to get Intune Scope Tag Assignments from the Graph API REST interface
        .DESCRIPTION
        The function connects to the Graph API Interface and gets Intune Scope Tag Assignments
        .EXAMPLE
        Get-ScopeTagAssignment
        Returns any Scope Tag Assignments configured in Intune
        .NOTES
        NAME: Get-ScopeTagAssignment
        #>
        
    [cmdletbinding()]
        
    param
    (
        $Name
    )
        
    $graphApiVersion = "beta"
    $Resource = "deviceManagement/roleAssignments"
        
    try {
        
        if ($Name) {
        
            $uri = "https://graph.microsoft.com/$graphApiVersion/$($Resource)"
                (Invoke-RestMethod -Uri $uri -Headers $authToken -Method Get).Value | Where-Object { ($_.'displayName').contains("$Name") -and $_.isBuiltIn -eq $false }
        
        }
        
        else {
        
            $uri = "https://graph.microsoft.com/$graphApiVersion/$($Resource)"
                (Invoke-RestMethod -Uri $uri -Headers $authToken -Method Get).Value
        
        }
        
    }
        
    catch {
        
        $ex = $_.Exception
        $errorResponse = $ex.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($errorResponse)
        $reader.BaseStream.Position = 0
        $reader.DiscardBufferedData()
        $responseBody = $reader.ReadToEnd();
        Write-Host "Response content:`n$responseBody" -f Red
        Write-Error "Request to $Uri failed with HTTP Status $($ex.Response.StatusCode) $($ex.Response.StatusDescription)"
        write-host
        break
        
    }
        
}
        
####################################################

Function Get-ScopeTag() {

    <#
    .SYNOPSIS
    This function is used to get Intune Scope Tags from the Graph API REST interface
    .DESCRIPTION
    The function connects to the Graph API Interface and gets Intune Scope Tags
    .EXAMPLE
    Get-ScopeTag
    Returns any Scope Tags configured in Intune
    .NOTES
    NAME: Get-ScopeTag
    #>
    
    [cmdletbinding()]
    
    param
    (
        $Name
    )
    
    $graphApiVersion = "beta"
    $Resource = "deviceManagement/roleScopeTags"
    
    try {
    
        if ($Name) {
    
            $uri = "https://graph.microsoft.com/$graphApiVersion/$($Resource)"
            (Invoke-RestMethod -Uri $uri -Headers $authToken -Method Get).Value | Where-Object { ($_.'displayName').contains("$Name") -and $_.isBuiltIn -eq $false }
    
        }
    
        else {
    
            $uri = "https://graph.microsoft.com/$graphApiVersion/$($Resource)"
            (Invoke-RestMethod -Uri $uri -Headers $authToken -Method Get).Value
    
        }
    
    }
    
    catch {
    
        $ex = $_.Exception
        $errorResponse = $ex.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($errorResponse)
        $reader.BaseStream.Position = 0
        $reader.DiscardBufferedData()
        $responseBody = $reader.ReadToEnd();
        Write-Host "Response content:`n$responseBody" -f Red
        Write-Error "Request to $Uri failed with HTTP Status $($ex.Response.StatusCode) $($ex.Response.StatusDescription)"
        write-host
        break
    
    }
    
}
    
####################################################

Function Set-ScopeTagAssignment() {
    
    <#
    .SYNOPSIS
    This function is used to set an Intune Scope Tag for an RBAC Role assignment using the Graph API REST interface
    .DESCRIPTION
    The function connects to the Graph API Interface and sets an Intune Scope Tag for an RBAC Role assignment
    .EXAMPLE
    Set-ScopeTagAssignment -ScopeTagId $ScopeTagId  -AssignmentID $AssignmentID
    Creates and Assigns a Scope Tag for an RBAC Role assignment in Intune
    .NOTES
    NAME: Set-ScopeTagAssignment
    #>
    
    [cmdletbinding()]
    
    param
    (
        $ScopeTagId,
        $AssignmentID
    )
    
    $graphApiVersion = "Beta"
    $Resource = "deviceManagement/roleAssignments"
        
    try {
    
        if (!$ScopeTagId) {
            write-host "No Scope Tag Id specified, specify a valid Id" -f Red
            break
        }    
    
        if (!$AssignmentID) {
            write-host "No Assignment Id specified, specify a valid Id" -f Red
            break
        }

        $JSON = @"
    
        {
        "@odata.id": "https://graph.microsoft.com/beta/deviceManagement/roleScopeTags/$ScopeTagId"
        }
    
"@
    
        #$uri = "https://graph.microsoft.com/$graphApiVersion/$Resource('$AssignmentID')/roleScopeTags"
        $uri = "https://graph.microsoft.com/beta/deviceManagement/roleAssignments/$AssignmentID/roleScopeTags/`$ref"
        Invoke-RestMethod -Uri $uri -Headers $authToken -Method Post -Body $JSON -ContentType "application/json"
        
    }
        
    catch {
    
        $ex = $_.Exception
        $errorResponse = $ex.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($errorResponse)
        $reader.BaseStream.Position = 0
        $reader.DiscardBufferedData()
        $responseBody = $reader.ReadToEnd();
        Write-Host "Response content:`n$responseBody" -f Red
        Write-Error "Request to $Uri failed with HTTP Status $($ex.Response.StatusCode) $($ex.Response.StatusDescription)"
        write-host
        break
    
    }
    
}
    
####################################################

Clear-Host
Start-Log -FilePath $logFile -DeleteExistingFile
Write-Host
Write-Host "Script log file path is [$logFile]" -f Cyan
Write-Host
Write-Log -Message "Starting $ScriptName version $BuildVer" -WriteEventLog

#endregion Initialisation...
##########################################################################################################
##########################################################################################################
#region Main Script work section
##########################################################################################################
##########################################################################################################
#Main Script work section
##########################################################################################################
##########################################################################################################
$listOfModules = @("Microsoft.Graph.Authentication", "Microsoft.Graph.Intune", "Microsoft.Graph.Groups")

Write-Host "Call function to prepare PSGallery pre-reqs... `n" -ForegroundColor Yellow
Set-PSGalleryPreReqs

# Call function to install the list of modules
Write-Host "Installing required modules... `n" -ForegroundColor Yellow
Invoke-ModuleInstall

Write-Log -Message "Authenticate to AzureAD..."
<#
Test-AuthToken -User $Username
#Script specific variables
$tenantName = $(($tenant.VerifiedDomains | Where-Object _Default).Name)
Write-Log -Message "Tennant Name: $tenantName"
#>

$loginURL = 'https://login.microsoftonline.com'
$authURL = "$loginURL/$TenantID"
Write-Host "Using AppID: $AppID" -ForegroundColor Green
Write-Host "Using TenantID: $TenantID`n" -ForegroundColor Green
Write-Host "Using authURL: $authURL" -ForegroundColor Green
Invoke-GraphAuth -AppID $AppID -TenantID $TenantID
#Update-MSGraphEnvironment -AppId "c54aea31-6150-4e88-bef3-0ed89c67279f" -AuthUrl <string> [-GraphBaseUrl <string>] [-GraphResourceId <string>] -Quiet [-RedirectLink <string>] -SchemaVersion 'beta'
Update-MSGraphEnvironment -AppId $AppID -AuthUrl $authURL -SchemaVersion 'beta' -Quiet

Write-Host "MemberAADGroup: $AdminGroup" -ForegroundColor Green
Write-Host "ScopeGroup: $ScopeGroup" -ForegroundColor Green
Write-Host "RBACRoleName: $RBACRoleName" -ForegroundColor Green
If ($ScopeTag) {
    Write-Host "ScopeTag: $ScopeTag" -ForegroundColor Green
}

# Setting Member AAD Group
    
#$AdminGroup = Read-Host -Prompt "Enter the Azure AD Group name for Intune Role Members (Admin Group)"
    
#$MemberGroupId = (Get-AADGroupName -GroupName "$AdminGroup").id
$MemberGroupId = (Get-MgGroup -Filter "displayname eq '$AdminGroup'").Id

if ($MemberGroupId -eq $null -or $MemberGroupId -eq "") {

    Write-Host "AAD Group - '$AdminGroup' doesn't exist, please specify a valid AAD Group..." -ForegroundColor Red
    Write-Host
    exit

}

Write-Host

# Setting Scope AAD Group
#$ScopeGroup = Read-Host -Prompt "Enter the Azure AD Group name for Intune Role Scope (Scope Group)"

If ($ScopeGroup -ne "allDevices") {
    #$TargetGroupId = (Get-AADGroupName -GroupName "$ScopeGroup").id
    $TargetGroupId = (Get-MgGroup -Filter "displayname eq '$ScopeGroup'").Id

    if ($null -eq $TargetGroupId -or $TargetGroupId -eq "") {

        Write-Host "AAD Group - '$ScopeGroup' doesn't exist, please specify a valid AAD Group..." -ForegroundColor Red
        Write-Host
        exit

    }

    Write-Host
}
ElseIf ($ScopeGroup -eq "allDevices") { 
    $TargetGroupId = "allDevices" 
}

####################################################

$role = Get-RBACRole | Where-Object DisplayName -eq $RBACRoleName
if ($role) {
    #$role.RolePermissions.resourceActions.allowedResourceActions
    Write-Host "RBAC Role Id: $($role.Id)" -ForegroundColor Green
}
else {
    Write-Host "RBAC Role not found: $RBACRoleName"
    Break
}

If ($ScopeTag) {
    $scopeTagId = (Get-ScopeTag -Name $ScopeTag).id
    Write-Host "ScopeTagId: $ScopeTagId" -ForegroundColor Green
    #Exit
}

<#
$JSON = @"

{
  "@odata.type": "#microsoft.graph.roleDefinition",
  "displayName": "Graph RBAC Role Assigned",
  "description": "New RBAC Role Description",
  "permissions": [
    {
      "actions": [
        "Microsoft.Intune/MobileApps/Read",
        "Microsoft.Intune/TermsAndConditions/Read",
        "Microsoft.Intune/ManagedApps/Read",
        "Microsoft.Intune/ManagedDevices/Read",
        "Microsoft.Intune/DeviceConfigurations/Read",
        "Microsoft.Intune/TelecomExpenses/Read",
        "Microsoft.Intune/Organization/Read",
        "Microsoft.Intune/RemoteTasks/RebootNow",
        "Microsoft.Intune/RemoteTasks/RemoteLock"
      ]
    }
  ],
  "isBuiltInRoleDefinition": false
}

"@

####################################################

Write-Host "Adding Intune Role from JSON..." -ForegroundColor Yellow
Write-Host "Creating Intune Role via Graph"
$CreateResult = Add-RBACRole -JSON $JSON
write-host "Intune Role created with id" $CreateResult.id

$IntuneRoleID = $CreateResult.id
#>

Write-Host

Write-Host "Creating Intune Role Assignment..." -ForegroundColor Yellow
Write-Host "Creating Intune Role Assignment via Graph"

$AssignmentIntuneRole = Assign-RBACRole -Id $role.Id -DisplayName "$AdminGroup-Assignment" -MemberGroupId $MemberGroupId -TargetGroupId $TargetGroupId
write-host "Intune Role Assigment created with id" $AssignmentIntuneRole.id

If ($ScopeTag) {
    #https://graph.microsoft.com/beta/deviceManagement/roleAssignments/95156905-8669-453e-8b90-37f949195538/roleScopeTags
    Set-ScopeTagAssignment -ScopeTagId $scopeTagId -AssignmentID $AssignmentIntuneRole.id
}

Write-Host

##########################################################################################################
##########################################################################################################
#endregion Main Script work section