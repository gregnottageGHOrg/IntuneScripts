Set-Location -Path "$PSScriptRoot"

<#
# To get extensionAttribute values for a single device
.\Get-AzureAdDeviceExtensionAttribute.ps1 -userName "upnhere" -DeviceName "devicenamehere"

# To get extensionAttribute values for devices in DeviceList.txt
.\Get-AzureAdDeviceExtensionAttribute.ps1 -userName "upnhere" -DeviceName (get-content .\DeviceList.txt)

# To set extensionAttribute values use the following for a single device
.\Set-AzureAdDeviceExtensionAttribute.ps1 -username "upnhere" -ExtensionAttributeNumber "extensionAttribute1" -AttributeValue "AttribHere" -DeviceName "devicenamehere"

# To set extensionAttribute values for multiple devices
.\Set-AzureAdDeviceExtensionAttribute.ps1 -username "upnhere" -ExtensionAttributeNumber "extensionAttribute1" -AttributeValue "AttribHere" -DeviceName (get-content .\DeviceList.txt)

# You can add values using the different extensionAttribute1-15
#>

<#
Connect-AzureAD
get-azureadgroup -SearchString "PAW-Global-Devices" | Get-AzureADGroupMember | select -ExpandProperty displayname | Set-Clipboard
#>

#<#
#$devices = "EUC-14569360118", "EUC-17848781668"
#$devices = "9055-1041-2141-1670-8553-3428-09"
$devices = "!! Put Device Names Here !!"
.\Set-AzureAdDeviceExtensionAttribute.ps1 -username "admin@gocloudfirst.onmicrosoft.com" -ExtensionAttributeNumber "extensionAttribute1" -AttributeValue "EUC" -DeviceName $devices
#>