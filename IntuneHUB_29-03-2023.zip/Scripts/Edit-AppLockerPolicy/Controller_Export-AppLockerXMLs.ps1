### Read Pre-Reqs.txt for setup guidance before running this script!!!

Set-Location -Path "$PSScriptRoot"

#Using Client Secret AppLockerManagement app reg
#Replace 'xxxx' with correct values
.\Export-AppLockerXMLs.ps1 -AppLockerPolicy 'EUC-Global-DCP-Windows-10-AppLocker' -TenantId 'xxxx' -ClientId 'xxxx' -ClientSecret 'xxxx'


#Using Cert
#.\Export-AppLockerXMLs.ps1 -AppLockerPolicy 'xxxx' -TenantId 'xxxx' -ClientId 'xxxx' -CertName "PSAuth"