Set-Location -Path "$PSScriptRoot"

#Replace 'xxxx' with correct values
.\Import-UpdatedAppLockerXMLs.ps1 -ImportPath "$PSScriptRoot\02-02-2023\Audit" -TargetGroup 'EUC-Global-Devices' -PolicyName 'EUC-Global-DCP-Windows-10-AppLocker-Audit' -Update 'No' -TenantId 'xxxx' -ClientId 'xxxx' -ClientSecret 'xxxx'
#.\Import-UpdatedAppLockerXMLs.ps1 -ImportPath "$PSScriptRoot\02-02-2023\ReadyForIntune" -TargetGroup 'EUC-Global-Devices' -PolicyName 'EUC-Global-DCP-Windows-10-AppLocker' -Update 'No' -TenantId 'xxxx' -ClientId 'xxxx' -ClientSecret 'xxxx'


#Using Cert-based auth
#.\Import-UpdatedAppLockerXMLs.ps1 -ImportPath "$PSScriptRoot" -TargetGroup 'EUC-Global-DCP-Windows-10-AppLocker-Testing' -PolicyName 'NCSC - AppLocker' -Update 'No' -TenantId 'xxxx' -ClientId 'xxxx' -CertName "PSAuth"