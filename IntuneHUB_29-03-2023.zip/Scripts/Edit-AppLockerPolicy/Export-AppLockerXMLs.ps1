<#

.COPYRIGHT
Copyright (c) Microsoft Corporation. All rights reserved. Licensed under the MIT license.
See LICENSE in the project root for license information.

#>

[CmdLetBinding()]
param(
    [Parameter(Mandatory = $true, Position = 1, ValueFromPipelineByPropertyName = $true,
        ValueFromPipeline = $True,
        HelpMessage = 'Provide AppLocker policy name'
    )]
    [ValidateNotNullOrEmpty()]
    [string[]] $AppLockerPolicy = @(),

    [Parameter(Mandatory = $true, Position = 2, ValueFromPipelineByPropertyName = $true,
        HelpMessage = 'Provide Azure Tenant ID'
    )]
    [ValidateNotNullOrEmpty()]
    [string] $TenantId,

    [Parameter(Mandatory = $true, Position = 3, ValueFromPipelineByPropertyName = $true,
        HelpMessage = 'Provide Azure App Registration (Service Principle) Client ID'
    )]
    [ValidateNotNullOrEmpty()]
    [string] $ClientId,

    [Parameter(Position = 4, ValueFromPipelineByPropertyName = $true,
        ParameterSetName = 'ClientSecret',
        HelpMessage = 'Provide Azure App Registration (Service Principle) Client Secret'
    )]
    [string] $ClientSecret,

    [Parameter(Position = 5, ValueFromPipelineByPropertyName = $true,
        ParameterSetName = 'CertName',
        HelpMessage = 'Provide Azure App Registration (Service Principle) Certificate name'
    )]
    [string] $CertName
)

##########################################################################################################

Function GetMsGraphToken {
    param(
        [String] $tenantId,
        [String] $clientId,
        [String] $clientSecret,
        [String] $scope = "https://graph.microsoft.com/.default"
    )
    $oauth2tokenendpointv2 = "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token"
    $client_assertion_type = "urn:ietf:params:oauth:client-assertion-type:jwt-bearer"
    $scope = [System.Net.WebUtility]::UrlEncode($scope)
    $encSecret = [System.Net.WebUtility]::UrlEncode($clientSecret)
    $body = "grant_type=client_credentials&scope=$($scope)&client_id=$($clientId)&client_secret=$($encSecret)"
    Try {
        $res = Invoke-WebRequest -Uri $oauth2tokenendpointv2 -Body $body -Method Post -UseBasicParsing
        $authResult = $res.Content | ConvertFrom-Json
        return $authResult.access_token
    }
    Catch {
        $ex = $_.Exception
        Write-Warning "$($env:computername.ToUpper()) : $($_.Exception.message)"        
        $errorResponse = $ex.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($errorResponse)
        $reader.BaseStream.Position = 0
        $reader.DiscardBufferedData()
        $responseBody = $reader.ReadToEnd();
        Write-Host "Response content:`n$responseBody" -f Red
        Write-Error "Request to failed with HTTP Status $($ex.Response.StatusCode) $($ex.Response.StatusDescription)"
        write-host
        Throw
    }
}
Function Test-Module {
    param(
        [String[]] $ModuleNames
    )

    Begin {
        Write-Host "$($MyInvocation.InvocationName) function..."
    }
    Process {
        Foreach ($moduleName in $ModuleNames) {
            Write-Host "Checking for module: $moduleName"

            $module = Get-Module -ListAvailable -Name $moduleName

            If ($module) {
                #getting version of installed module
                $version = (Get-Module -ListAvailable $module) | Sort-Object Version -Descending  | Select-Object Version -First 1
                #converting version to string
                $stringver = $version | Select-Object @{n = 'ModuleVersion'; e = { $_.Version -as [string] } }
                $a = $stringver | Select-Object Moduleversion -ExpandProperty Moduleversion
                #getting latest module version from ps gallery 
                $psgalleryversion = Find-Module -Name $module | Sort-Object Version -Descending | Select-Object Version -First 1
                #converting version to string
                $onlinever = $psgalleryversion | Select-Object @{n = 'OnlineVersion'; e = { $_.Version -as [string] } }
                $b = $onlinever | Select-Object OnlineVersion -ExpandProperty OnlineVersion
 
                If ([version]"$a" -ge [version]"$b") {
                    Write-Host "Module: $module"
                    Write-Host "Installed $a is equal or greater than $b"
                }
                Else {
                    Write-Host "Module: $module"
                    Write-Host "Installed Module:$a is lower version than $b"
                    
                    Try {
                        Install-Module -Name $moduleName -Verbose -Force -ErrorAction Stop
                        Write-Host "Module installed."
                    }
                    Catch { 
                        Throw 
                    }
                }
            }
            Else {
                Write-Host "Module not installed: $moduleName"
                Write-Host "Attempting to install..."

                Try {
                    Install-Module -Name $moduleName -Verbose -Force -ErrorAction Stop
                    Write-Host "Module installed."
                }
                Catch { 
                    Throw 
                }
            }
        }
    }
    
}

##########################################################################################################
#region auth
$modules = @("Microsoft.Graph.Authentication", "Microsoft.Graph.DeviceManagement")
#Check if module is installed and up to date
Test-Module -ModuleNames $modules


If ($CertName) {
    Write-Host "Using certname: $CertName"
    If ($CertName -match "CN=") {
        Write-Host "Matches" -ForegroundColor Green
    }
    Else {
        $CertName = $CertName -replace $CertName, "CN=$CertName"
        Write-Host "Modified Cert Name: $CertName" -ForegroundColor Yellow
    }

    $myCert = Get-ChildItem -Path "cert:\CurrentUser\My" | Where-Object Subject -eq $CertName
    If ($myCert) {
        Write-Host "Found cert, using it to authenticate to Graph..." -ForegroundColor Yellow
        Connect-MgGraph -ClientID $clientId -TenantId $tenantId -CertificateThumbprint $myCert.Thumbprint ## Or -CertificateThumbprint instead of -CertificateName
    }
    Else {
        Throw "Error - cert not found: $CertName"
    }

}
ElseIf ($ClientSecret) {
    Write-Host "Using client secret"
    $token = GetMsGraphToken -tenantId $tenantId -clientId $clientId -clientSecret $clientSecret
    Connect-MgGraph -AccessToken $token
}
Else {
    Throw "Please specify either a valid certificate name or client secret for authentication"
}
Select-MgProfile -Name "beta"
#endregion auth

$url = "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations"
 
$dcp = Invoke-MgGraphRequest `
    -Uri "$url" `
    -Method GET `

$intuneDeviceConfigProfile = $dcp.value | Where-Object { ($_.'@odata.type' -eq '#microsoft.graph.windows10CustomConfiguration') -and ($_.'displayName' -eq $AppLockerPolicy) }
foreach ($setting in $intuneDeviceConfigProfile.omaSettings) {
    Write-Output "Processing entry: `"$($setting.displayName)`" ($($setting.omaUri))"

    try {
    
        # decrypt encrypted settings value
        $requestUrl = "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations/$($intuneDeviceConfigProfile.Id)/getOmaSettingPlainTextValue(secretReferenceValueId='$($setting.secretReferenceValueId)')"
        Write-Host "$requestUrl" -ForegroundColor Green
        $decryptedSetting = Invoke-MgGraphRequest -Uri $requestUrl -Method GET

        # load xml from base 64 encoded string
        [xml]$base64XmlContent = $decryptedSetting.Value
        [System.Xml.XmlWriterSettings] $xmlSettings = New-Object System.Xml.XmlWriterSettings

        # Preserve Windows formating
        $xmlSettings.Indent = $true

        # Keeping UTF-8 without BOM
        $xmlSettings.Encoding = New-Object System.Text.UTF8Encoding($false)

        # Combine export path
        $exportPath = Join-Path -Path $PSScriptRoot -ChildPath "$($setting.displayName).xml"

        # Write xml to disk
        [System.Xml.XmlWriter] $xmlWriter = [System.Xml.XmlWriter]::Create($exportPath, $xmlSettings)
        $base64XmlContent.Save($xmlWriter)

        # Close Handle and flush
        $xmlWriter.Dispose()

        Write-Output "Exported XML to: `"$exportPath`""
    }
    catch {
        Write-Error $_
    }
}