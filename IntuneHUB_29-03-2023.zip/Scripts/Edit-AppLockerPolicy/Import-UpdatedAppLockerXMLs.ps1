﻿
<#

.COPYRIGHT
Copyright (c) Microsoft Corporation. All rights reserved. Licensed under the MIT license.
See LICENSE in the project root for license information.

#>

[CmdLetBinding()]
param(
    [Parameter(Position = 1, ValueFromPipelineByPropertyName = $true,
        HelpMessage = 'Provide AppLocker policy import path'
    )]
    [ValidateNotNullOrEmpty()]
    [string[]] $ImportPath = "$PSScriptRoot",

    [Parameter(Position = 2, ValueFromPipelineByPropertyName = $true,
        HelpMessage = 'Provide AppLocker targeting group'
    )]
    [ValidateNotNullOrEmpty()]
    [string] $TargetGroup = "MIP-WIN10-OBJECT-CONFIG-AppLocker-Testing",

    [Parameter(Position = 3, ValueFromPipelineByPropertyName = $true,
        ValueFromPipeline = $True,
        HelpMessage = 'Provide policy displayname'
    )]
    [ValidateNotNullOrEmpty()]
    [string[]] $PolicyName = "NCSC - AppLocker",

    [Parameter(Position = 4, ValueFromPipelineByPropertyName = $true,
        HelpMessage = 'Overwrite existing policies? Yes/No'
    )]
    [ValidateSet("Yes", "No")]
    [String]$Update = "No",

    [Parameter(Mandatory = $true, Position = 5, ValueFromPipelineByPropertyName = $true,
        HelpMessage = 'Provide Azure Tenant ID'
    )]
    [ValidateNotNullOrEmpty()]
    [string] $TenantId,

    [Parameter(Mandatory = $true, Position = 6, ValueFromPipelineByPropertyName = $true,
        HelpMessage = 'Provide Azure App Registration (Service Principle) Client ID'
    )]
    [ValidateNotNullOrEmpty()]
    [string] $ClientId,

    [Parameter(Position = 7, ValueFromPipelineByPropertyName = $true,
        ParameterSetName = 'ClientSecret',
        HelpMessage = 'Provide Azure App Registration (Service Principle) Client Secret'
    )]
    [string] $ClientSecret,

    [Parameter(Position = 8, ValueFromPipelineByPropertyName = $true,
        ParameterSetName = 'CertName',
        HelpMessage = 'Provide Azure App Registration (Service Principle) Certificate name'
    )]
    [string] $CertName
)

##########################################################################################################
<#
Function GetMsGraphToken {
    param(
        [String] $tenantId,
        [String] $clientId,
        [String] $clientSecret,
        #[String] $CertThumbprint,
        [String] $scope = "https://graph.microsoft.com/.default"
    )
    #Add-Type -AssemblyName System.Web
    $oauth2tokenendpointv2 = "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token"
    $client_assertion_type = "urn:ietf:params:oauth:client-assertion-type:jwt-bearer"
    #$scope = [System.Web.HttpUtility]::UrlEncode($scope)
    $scope = [System.Net.WebUtility]::UrlEncode($scope)
    #$encSecret = [System.Web.HttpUtility]::UrlEncode($clientSecret)
    $encSecret = [System.Net.WebUtility]::UrlEncode($clientSecret)
    #$encCert = [System.Net.WebUtility]::UrlEncode($CertThumbprint)
    $body = "grant_type=client_credentials&scope=$($scope)&client_id=$($clientId)&client_secret=$($encSecret)"
    #$body = "grant_type=client_credentials&scope=$($scope)&client_id=$($clientId)&client_assertion_type=$($client_assertion_type)&client_assertion=$($encCert)"
    Try {
        $res = Invoke-WebRequest -Uri $oauth2tokenendpointv2 -Body $body -Method Post -UseBasicParsing
        $authResult = $res.Content | ConvertFrom-Json
        return $authResult.access_token
    }
    Catch {
        Write-Warning "$($env:computername.ToUpper()) : $($_.Exception.message)"
        $ex = $_.Exception
        $errorResponse = $ex.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($errorResponse)
        $reader.BaseStream.Position = 0
        $reader.DiscardBufferedData()
        $responseBody = $reader.ReadToEnd();
        Write-Host "Response content:`n$responseBody" -f Red
        Write-Error "Request to $DCP_resource failed with HTTP Status $($ex.Response.StatusCode) $($ex.Response.StatusDescription)"
        write-host
        Throw
    }
}
#>

Function GetMsGraphToken {
    param(
        [String] $tenantId,
        [String] $clientId,
        [String] $clientSecret,
        [String] $scope = "https://graph.microsoft.com/.default"
    )
    $oauth2tokenendpointv2 = "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token"
    $client_assertion_type = "urn:ietf:params:oauth:client-assertion-type:jwt-bearer"
    $scope = [System.Net.WebUtility]::UrlEncode($scope)
    $encSecret = [System.Net.WebUtility]::UrlEncode($clientSecret)
    $body = "grant_type=client_credentials&scope=$($scope)&client_id=$($clientId)&client_secret=$($encSecret)"
    Try {
        $res = Invoke-WebRequest -Uri $oauth2tokenendpointv2 -Body $body -Method Post -UseBasicParsing
        $authResult = $res.Content | ConvertFrom-Json
        return $authResult.access_token
    }
    Catch {
        $ex = $_.Exception
        Write-Warning "$($env:computername.ToUpper()) : $($_.Exception.message)"        
        $errorResponse = $ex.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($errorResponse)
        $reader.BaseStream.Position = 0
        $reader.DiscardBufferedData()
        $responseBody = $reader.ReadToEnd();
        Write-Host "Response content:`n$responseBody" -f Red
        Write-Error "Request to failed with HTTP Status $($ex.Response.StatusCode) $($ex.Response.StatusDescription)"
        write-host
        Throw
    }
}

##########################################################################################################

Function Test-Module {
    param(
        [String[]] $ModuleNames
    )

    Begin {
        Write-Host "$($MyInvocation.InvocationName) function..."
    }
    Process {
        Foreach ($moduleName in $ModuleNames) {
            Write-Host "Checking for module: $moduleName"

            $module = Get-Module -ListAvailable -Name $moduleName

            If ($module) {
                #getting version of installed module
                $version = (Get-Module -ListAvailable $module) | Sort-Object Version -Descending  | Select-Object Version -First 1
                #converting version to string
                $stringver = $version | Select-Object @{n = 'ModuleVersion'; e = { $_.Version -as [string] } }
                $a = $stringver | Select-Object Moduleversion -ExpandProperty Moduleversion
                #getting latest module version from ps gallery 
                $psgalleryversion = Find-Module -Name $module | Sort-Object Version -Descending | Select-Object Version -First 1
                #converting version to string
                $onlinever = $psgalleryversion | Select-Object @{n = 'OnlineVersion'; e = { $_.Version -as [string] } }
                $b = $onlinever | Select-Object OnlineVersion -ExpandProperty OnlineVersion
 
                If ([version]"$a" -ge [version]"$b") {
                    Write-Host "Module: $module"
                    Write-Host "Installed $a is equal or greater than $b"
                }
                Else {
                    Write-Host "Module: $module"
                    Write-Host "Installed Module:$a is lower version than $b"
                    
                    Try {
                        Install-Module -Name $moduleName -Verbose -Force -ErrorAction Stop
                        Write-Host "Module installed."
                    }
                    Catch { 
                        Throw 
                    }
                }
            }
            Else {
                Write-Host "Module not installed: $moduleName"
                Write-Host "Attempting to install..."

                Try {
                    Install-Module -Name $moduleName -Verbose -Force -ErrorAction Stop
                    Write-Host "Module installed."
                }
                Catch { 
                    Throw 
                }
            }
        }
    }
    
}

##########################################################################################################

Function Test-JSON() {

    <#
.SYNOPSIS
This function is used to test if the JSON passed to a REST Post request is valid
.DESCRIPTION
The function tests if the JSON passed to the REST Post is valid
.EXAMPLE
Test-JSON -JSON $JSON
Test if the JSON is valid before calling the Graph REST interface
.NOTES
NAME: Test-JSON
#>

    param (

        $JSON

    )

    try {

        $TestJSON = ConvertFrom-Json $JSON -ErrorAction Stop
        $validJson = $true

    }

    catch {

        $validJson = $false
        $_.Exception

    }

    if (!$validJson) {
    
        Write-Host "Provided JSON isn't in valid JSON format" -f Red
        break

    }
    Else { Write-Host "JSON is valid" -ForegroundColor Green }

}

##########################################################################################################

Function Add-DeviceConfigurationPolicy() {

    <#
.SYNOPSIS
This function is used to add an device configuration policy using the Graph API REST interface
.DESCRIPTION
The function connects to the Graph API Interface and adds a device configuration policy
.EXAMPLE
Add-DeviceConfigurationPolicy -JSON $JSON
Adds a device configuration policy in Intune
.NOTES
NAME: Add-DeviceConfigurationPolicy
#>

    [cmdletbinding()]

    param
    (
        $JSON
    )

    $graphApiVersion = "Beta"
    $DCP_resource = "deviceManagement/deviceConfigurations"
    #Write-Verbose "Resource: $DCP_resource"

    try {

        if ($JSON -eq "" -or $null -eq $JSON) {

            write-host "No JSON specified, please specify valid JSON..." -f Red

        }

        else {

            Test-JSON -JSON $JSON
            <#
            $parameters = @{
                Uri         = "https://graph.microsoft.com/$graphApiVersion/$($DCP_resource)"
                Method      = 'POST'
                Headers     = @{ Authorization = "Bearer $($script:Token)" }
                ContentType = "application/json"
                $Body       = $JSON
            }
            Invoke-RestMethod @parameters -ErrorAction Stop
            #$uri = "https://graph.microsoft.com/$graphApiVersion/$($DCP_resource)"
            #Invoke-RestMethod -Uri $uri -Headers $authToken -Method Post -Body $JSON -ContentType "application/json"
            #$hashJSON = $JSON.Replace(":", "=") | ConvertFrom-StringData
            #$hashJSON = @{}

            #(ConvertFrom-Json $json).psobject.properties | Foreach { $hashJSON[$_.Name] = $_.Value }
            #$hashJSON
            #>
            
            #Invoke-GraphRequest -Method POST -Query $DCP_resource -Body $JSON

            $parameters = @{
                Uri         = "https://graph.microsoft.com/$graphApiVersion/$($DCP_resource)"
                Method      = 'POST'
                ContentType = "application/json"
                Body        = $JSON
            }
            Invoke-MgGraphRequest @parameters -ErrorAction Stop

        }

    }
    
    catch {
        Write-Warning "$($env:computername.ToUpper()) : $($_.Exception.message)"
        $ex = $_.Exception
        $errorResponse = $ex.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($errorResponse)
        $reader.BaseStream.Position = 0
        $reader.DiscardBufferedData()
        $responseBody = $reader.ReadToEnd();
        Write-Host "Response content:`n$responseBody" -f Red
        Write-Error "Request to $DCP_resource failed with HTTP Status $($ex.Response.StatusCode) $($ex.Response.StatusDescription)"
        write-host
        Throw
    }

}

##########################################################################################################
Function Update-DeviceConfigurationPolicy() {

    <#
    .SYNOPSIS
    This function is used to add an device configuration policy using the Graph API REST interface
    .DESCRIPTION
    The function connects to the Graph API Interface and updates a device configuration policy
    .EXAMPLE
    Update-DeviceConfigurationPolicy -JSON $JSON -ID $ID
    Adds a device configuration policy in Intune
    .NOTES
    NAME: Update-DeviceConfigurationPolicy
    #>
    
    [cmdletbinding()]
    
    param
    (
        $JSON,
        $ID
    )
    
    $graphApiVersion = "Beta"
    $DCP_resource = "deviceManagement/deviceConfigurations/$ID"
    #Write-Verbose "Resource: $DCP_resource"
    
    try {
    
        if ($JSON -eq "" -or $null -eq $JSON) {
    
            write-host "No JSON specified, please specify valid JSON..." -f Red
    
        }
    
        else {
    
            Test-JSON -JSON $JSON
    
            #$uri = "https://graph.microsoft.com/$graphApiVersion/$($DCP_resource)"
            #Invoke-RestMethod -Uri $uri -Headers $authToken -Method Patch -Body $JSON -ContentType "application/json"

            $parameters = @{
                Uri         = "https://graph.microsoft.com/$graphApiVersion/$($DCP_resource)"
                Method      = 'PATCH'
                ContentType = "application/json"
                Body        = $JSON
            }
            Invoke-MgGraphRequest @parameters -ErrorAction Stop
    
        }
    
    }
        
    catch {
    
        Throw
        $ex = $_.Exception
        $errorResponse = $ex.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($errorResponse)
        $reader.BaseStream.Position = 0
        $reader.DiscardBufferedData()
        $responseBody = $reader.ReadToEnd();
        Write-Host "Response content:`n$responseBody" -f Red
        Write-Error "Request to $Uri failed with HTTP Status $($ex.Response.StatusCode) $($ex.Response.StatusDescription)"
        write-host
        break
    
    }
    
}
    
##########################################################################################################

Function Add-DeviceConfigurationPolicyAssignment() {
    <#
.SYNOPSIS
This function is used to add a device configuration policy assignment using the Graph API REST interface
.DESCRIPTION
The function connects to the Graph API Interface and adds a device configuration policy assignment
.EXAMPLE
Add-DeviceConfigurationPolicyAssignment -ConfigurationPolicyId $ConfigurationPolicyId -TargetGroupId $TargetGroupId
Adds a device configuration policy assignment in Intune
.NOTES
NAME: Add-DeviceConfigurationPolicyAssignment
#>
    [cmdletbinding()]

    param
    (
        $ConfigurationPolicyId,
        $TargetGroupId,
        $Assignment
    )

    $graphApiVersion = "Beta"
    $DCP_resource = "deviceManagement/deviceConfigurations/$ConfigurationPolicyId/assignments"
    
    Try {
        If (!$ConfigurationPolicyId) {
            Throw "No Configuration Policy Id specified, specify a valid Configuration Policy Id"
        }
        If (!$TargetGroupId) {
            Throw "No Target Group Id specified, specify a valid Target Group Id"
        }
        If (!$Assignment) {
            Throw "No Assignment Type specified, specify a valid Assignment Type"
        }

        Write-Host "ConfigurationPolicyId: $ConfigurationPolicyId"
        Write-Host "TargetGroupId: $TargetGroupId"
        Write-Host "Assignment: $Assignment"
    
        #$ConfPolAssign = "$ConfigurationPolicyId" + "_" + "$TargetGroupId"
        <#
        $JSON = @"

        {
    "target": {
    "@odata.type": "#microsoft.graph.$Assignment",
    "groupId": "$TargetGroupId"
                }
        }
"@
#>
        $JSON = @"

    {
    "target": {
    "@odata.type": "$Assignment",
    "groupId": "$TargetGroupId"
            }
    }
"@

        #$uri = "https://graph.microsoft.com/$graphApiVersion/$($DCP_resource)"
        #Invoke-RestMethod -Uri $uri -Headers $authToken -Method Post -Body $JSON -ContentType "application/json"

        $parameters = @{
            Uri         = "https://graph.microsoft.com/$graphApiVersion/$($DCP_resource)"
            Method      = 'POST'
            ContentType = "application/json"
            Body        = $JSON
        }
        $parameters
        Invoke-MgGraphRequest @parameters -ErrorAction Stop
    }
    Catch {
        Throw
        $ex = $_.Exception
        $errorResponse = $ex.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($errorResponse)
        $reader.BaseStream.Position = 0
        $reader.DiscardBufferedData()
        $responseBody = $reader.ReadToEnd();
        Write-Host "Response content:`n$responseBody" -f Red
        Write-Error "Request to $Uri failed with HTTP Status $($ex.Response.StatusCode) $($ex.Response.StatusDescription)"
        write-host
    }
}

##########################################################################################################


Function Get-DeviceConfigurationPolicy() {

    <#
.SYNOPSIS
This function is used to get device configuration policies from the Graph API REST interface
.DESCRIPTION
The function connects to the Graph API Interface and gets any device configuration policies
.EXAMPLE
Get-DeviceConfigurationPolicy
Returns any device configuration policies configured in Intune
.NOTES
NAME: Get-DeviceConfigurationPolicy
#>

    [cmdletbinding()]

    param
    (
        $Name
    )

    Write-Host "Name: $Name"
    $graphApiVersion = "Beta"
    $DCP_resource = "deviceManagement/deviceConfigurations"
    $parameters = @{
        Uri    = "https://graph.microsoft.com/$graphApiVersion/$($DCP_resource)"
        Method = 'GET'
        #ContentType = "application/json"
    }

    try {
        if ($Name) {
            #$uri = "https://graph.microsoft.com/$graphApiVersion/$($DCP_resource)"
            #(Invoke-RestMethod -Uri $uri -Headers $authToken -Method Get).Value | Where-Object { ($_.'displayName').contains("$Name") }
            #Write-Host "Using name: $Name"
            #Exit
            #Invoke-GraphRequest -Query $DCP_resource | Where-Object { ($_.'displayName').contains("$Name") }
            $policy = Invoke-MgGraphRequest @parameters -ErrorAction Stop | Where-Object { ($_.value.displayName) -eq "$Name" }
            $policy = $policy.value | Where-Object { $_.displayName -eq "$Name" }
            #$policy | Out-GridView
            Return $policy
        }
        else {
            Invoke-MgGraphRequest @parameters -ErrorAction Stop
        }
    }

    catch {

        $ex = $_.Exception
        $errorResponse = $ex.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($errorResponse)
        $reader.BaseStream.Position = 0
        $reader.DiscardBufferedData()
        $responseBody = $reader.ReadToEnd();
        Write-Host "Response content:`n$responseBody" -f Red
        Write-Error "Request to $DCP_resource failed with HTTP Status $($ex.Response.StatusCode) $($ex.Response.StatusDescription)"
        write-host
        break

    }

}

##########################################################################################################

Function Test-Group() {
    <#
.SYNOPSIS
This function tests for the presence of the supplied group and creates it if not found
.DESCRIPTION
This function tests for the presence of the supplied group and creates it if not found
.EXAMPLE
Test-Group -GroupName GroupNameHere
This function tests for the presence of the supplied group and creates it if not found
.NOTES
NAME: Test-Group
#>

    [cmdletbinding()]
    param
    (
        [Parameter(Mandatory = $true, 
            HelpMessage = 'Provide AppLocker targeting group'
        )]
        [string[]]$GroupNames

    )
    Begin {
        Write-Host "$($MyInvocation.InvocationName) function..."
    }

    Process {
        Foreach ($groupName in $GroupNames) {
            Write-Host "Checking for group: $groupName"
            $filter = "DisplayName eq `'$groupName`'"
            Write-Host "Using filter: $filter" -ForegroundColor Yellow           

            Try {
                $group = Get-MgGroup -Filter $filter
            }
            Catch {
                $ex = $_.Exception
                Write-Warning "$($env:computername.ToUpper()) : $($_.Exception.message)"
                $errorResponse = $ex.Response.GetResponseStream()
                $reader = New-Object System.IO.StreamReader($errorResponse)
                $reader.BaseStream.Position = 0
                $reader.DiscardBufferedData()
                $responseBody = $reader.ReadToEnd();
                Write-Host "Response content:`n$responseBody" -f Red
                Write-Error "Request to $DCP_resource failed with HTTP Status $($ex.Response.StatusCode) $($ex.Response.StatusDescription)"
                write-host
                Throw
            }

            If ($group) {
                Write-Host "Group found: $groupName"
                Return $group
            }
            Else {
                Write-Host "Group not found: `'$groupName`' - attempting to create..."
                Try {
                    $newGroup = New-MgGroup -DisplayName $groupName -MailEnabled:$False  -MailNickName ($groupName).replace(" ", "-") -SecurityEnabled -Description "AppLocker policy targeting group"
                    Return $newGroup
                }
                Catch {
                    Write-Warning "$($env:computername.ToUpper()) : $($_.Exception.message)"
                    $ex = $_.Exception
                    $errorResponse = $ex.Response.GetResponseStream()
                    $reader = New-Object System.IO.StreamReader($errorResponse)
                    $reader.BaseStream.Position = 0
                    $reader.DiscardBufferedData()
                    $responseBody = $reader.ReadToEnd();
                    Write-Host "Response content:`n$responseBody" -f Red
                    Write-Error "Request to $DCP_resource failed with HTTP Status $($ex.Response.StatusCode) $($ex.Response.StatusDescription)"
                    write-host
                    break
                }
            }
        }
    }
}

##########################################################################################################

Function New-AppLockerJSON() {
    <#
.SYNOPSIS
This function re-compiles AppLocker XML files that were previously exported from Intune, back into a single JSON file
.DESCRIPTION
This function re-compiles AppLocker XML files that were previously exported from Intune, back into a single JSON file
.EXAMPLE
New-AppLockerJSON -AppLockerXMLPath AppLockerJSONNameAndPathHere
This function re-compiles AppLocker XML files that were previously exported from Intune, back into a single JSON file
.NOTES
NAME: New-AppLockerJSON
#>

    [cmdletbinding()]
    param
    (
        [Parameter(Mandatory = $true, 
            HelpMessage = 'Provide path to AppLocker XML files'
        )]
        [string[]]$AppLockerXMLPath
    )
    Begin {
        Write-Host "$($MyInvocation.InvocationName) function..."
    }

    Process {
        # Variables       
        $date = $(get-date -f dd-MM-yyyy-H-mm-ss)
        $DCPolicyName = "NCSC - AppLocker_" + $date
        $DCPolicyDescription = "Created $date"
        $ApplockerJSONFileName = $DCPolicyName + ".json"
        $PolicyBody = New-Object -TypeName PSObject
        $Objects = @()
        $count = 0

        # Quit if the directory path doesn't exist
        $AppLockerXMLPath = $AppLockerXMLPath.replace('"', '') 
        If (!(Test-Path "$AppLockerXMLPath")) {
            Throw "Path '$AppLockerXMLPath' doesn't exist, script can't continue..."
        }

        # Quit if XML files not found
        $applockerFiles = Get-ChildItem -Path $AppLockerXMLPath | Where-Object { $_.Extension -eq ".xml" }
        If (!$applockerFiles) {
            Throw "No XML files found in folder, script can't continue..."
        }

        Add-Member -InputObject $PolicyBody -MemberType 'NoteProperty' -Name '@odata.type' -Value "#microsoft.graph.windows10CustomConfiguration"
        Add-Member -InputObject $PolicyBody -MemberType 'NoteProperty' -Name 'description' -Value "$DCPolicyDescription"
        Add-Member -InputObject $PolicyBody -MemberType 'NoteProperty' -Name 'displayName' -Value "$DCPolicyName"

        # Looping through XML files in specified folder
        ForEach ($file in $applockerFiles) {

            #$FullPath = $file.fullName
            #$FileName = $file.Name

            [xml]$content = Get-Content $file.fullName

            if ($null -ne $content.RuleCollection.Type) {

                $XMLFile = $file.fullName
                $ApplockerType = $content.RuleCollection.Type

                Write-Host "Applocker XML file '$XMLFile' with '$ApplockerType' Applocker Type found..."

                $enc = [System.IO.File]::ReadAllBytes("$XMLFile")
                $base64 = [System.Convert]::ToBase64String($enc)
                $Object = New-Object -TypeName psobject
        
                Add-Member -InputObject $Object -MemberType 'NoteProperty' -Name '@odata.type' -Value "#microsoft.graph.omaSettingStringXml"
                Add-Member -InputObject $Object -MemberType 'Noteproperty' -Name 'displayName' -Value "Applocker $ApplockerType"
        
                # Checking what type of Applocker policy XML to create omaUri value
                If ($content.RuleCollection.Type -eq "DLL") {
                    Add-Member -InputObject $Object -MemberType 'Noteproperty' -Name 'description' -Value "AppLocker configuration for inbox DLLs"
                    Add-Member -InputObject $Object -MemberType 'Noteproperty' -Name 'omaUri' -Value "./Vendor/MSFT/AppLocker/ApplicationLaunchRestrictions/DLLGroup/DLL/Policy"
                }
                ElseIf ($content.RuleCollection.Type -eq "Script") {
                    Add-Member -InputObject $Object -MemberType 'Noteproperty' -Name 'description' -Value "AppLocker Configuration for inbox scripts"
                    Add-Member -InputObject $Object -MemberType 'Noteproperty' -Name 'omaUri' -Value "./Vendor/MSFT/AppLocker/ApplicationLaunchRestrictions/ScriptGroup/Script/Policy"
                }
                ElseIf ($content.RuleCollection.Type -eq "MSI") {
                    Add-Member -InputObject $Object -MemberType 'Noteproperty' -Name 'description' -Value "AppLocker configuration for inbox MSIs"
                    Add-Member -InputObject $Object -MemberType 'Noteproperty' -Name 'omaUri' -Value "./Vendor/MSFT/AppLocker/ApplicationLaunchRestrictions/MSIGroup/MSI/Policy"
                }
                ElseIf ($content.RuleCollection.Type -eq "EXE") {
                    Add-Member -InputObject $Object -MemberType 'Noteproperty' -Name 'description' -Value "AppLocker configuration for inbox executables"
                    Add-Member -InputObject $Object -MemberType 'Noteproperty' -Name 'omaUri' -Value "./Vendor/MSFT/AppLocker/ApplicationLaunchRestrictions/EXEGroup/EXE/Policy"
                }
                ElseIf ($content.RuleCollection.Type -eq "AppX") {
                    Add-Member -InputObject $Object -MemberType 'Noteproperty' -Name 'description' -Value "AppLocker configuration for inbox Microsoft store applications"
                    Add-Member -InputObject $Object -MemberType 'Noteproperty' -Name 'omaUri' -Value "./Vendor/MSFT/AppLocker/ApplicationLaunchRestrictions/StoreAppsGroup/StoreApps/Policy"
                }

                # Adding default values for object
                Add-Member -InputObject $Object -MemberType 'Noteproperty' -Name 'fileName' -Value "$XMLFile"
                Add-Member -InputObject $Object -MemberType 'NoteProperty' -Name 'value' -Value "$base64"

                $Objects += $Object
                $count++
            }
            else {
                Throw "File '$FileName' isn't a valid applocker xml..."
            }
        }
        If ($count -ge 1) {
            Add-Member -InputObject $PolicyBody -MemberType 'NoteProperty' -Name 'omaSettings' -Value $Objects
            $PolicyBody | ConvertTo-Json -Depth 5 | out-file -FilePath $AppLockerXMLPath\$ApplockerJSONFileName

            Write-Host
            Write-Host "Applocker JSON file created '$AppLockerXMLPath\$ApplockerJSONFileName'..." -ForegroundColor Green
            Write-Host

            Return "$AppLockerXMLPath\$ApplockerJSONFileName"
        }
        Else {
            Throw "No Applocker XML files found, can't create JSON file..."
        }
    }
}

##########################################################################################################

Function Import-AppLockerJSON() {
    <#
.SYNOPSIS
This function imports the AppLocker JSON files into Intune
.DESCRIPTION
This function imports the AppLocker JSON files into Intune
.EXAMPLE
Import-AppLockerJSON -JSONFile AppLockerJSONNameAndPathHere
This function imports the AppLocker JSON files into Intune
.NOTES
NAME: Import-AppLockerJSON
#>

    [cmdletbinding()]
    param
    (
        [Parameter(Mandatory = $true, 
            HelpMessage = 'Provide AppLocker JSON file name'
        )]
        [string[]]$JSONFile,

        [Parameter(
            HelpMessage = 'Provide AppLocker targeting group'
        )]
        $TargetGroup,

        [Parameter(
            HelpMessage = 'Provide policy displayname'
        )]
        [ValidateNotNullOrEmpty()]
        [string[]] $PolicyName = "NCSC - AppLocker",

        [Parameter(
            HelpMessage = 'Overwrite existing policies? Yes/No'
        )]
        [ValidateSet("Yes", "No")]
        [String]$Update = "No"
    )
    Begin {
        Write-Host "$($MyInvocation.InvocationName) function..."
    }

    Process {
        Write-Host "Using group: $TargetGroup" -ForegroundColor Magenta
        Write-Host "Update existing policies: $Update" -ForegroundColor Magenta
        $JSON_Data = Get-Content -Path $JSONFile            
        # Excluding entries that are not required - id,createdDateTime,lastModifiedDateTime,version
        $JSON_Convert = $JSON_Data | ConvertFrom-Json | Select-Object -Property * -ExcludeProperty id, createdDateTime, lastModifiedDateTime, version, supportsScopeTags, deviceManagementApplicabilityRuleOsEdition, deviceManagementApplicabilityRuleOsVersion, deviceManagementApplicabilityRuleDeviceMode
        #$JSON_Convert.displayName = $JSON_Convert.displayName.Replace("$($JSON_Convert.displayName)", "NCSC - AppLocker_" + $(get-date -f dd-MM-yyyy-H-mm-ss))
        $JSON_Convert.displayName = $JSON_Convert.displayName.Replace("$($JSON_Convert.displayName)", "$PolicyName`_$(get-date -f dd-MM-yyyy-H-mm-ss)")
        $DisplayName = $JSON_Convert.displayName
        Write-Host "Importing policy: $DisplayName" -ForegroundColor Green
            
        $DuplicateDCP = Get-DeviceConfigurationPolicy -Name $DisplayName 
            
        If ($null -eq $DuplicateDCP) {
            #Existing policy not found
            $JSON_Output = $JSON_Convert | ConvertTo-Json -Depth 5
                        
            write-host
            write-host "Device Configuration Policy '$DisplayName' Found..." -ForegroundColor Yellow
            write-host
            $JSON_Output
            write-host
            Write-Host "Adding Device Configuration Policy '$DisplayName'" -ForegroundColor Yellow
            
            Add-DeviceConfigurationPolicy -JSON $JSON_Output

            $DeviceConfigs = Get-DeviceConfigurationPolicy -name $DisplayName
            Write-Host "Device Config: $($DeviceConfigs.displayName)" -ForegroundColor Cyan
            #$DeviceConfigs.Value | Format-List *
            $DeviceConfigID = $DeviceConfigs.id
            
            Write-Host "Device ConfigID '$DeviceConfigID'" -ForegroundColor Yellow 
            Write-Host
            #<#
            $assignmentGroups = $JSON_Convert.assignments.target
            
            If ($assignmentGroups) {
                foreach ($assignmentGroup in $assignmentGroups) {
                    Write-Host "AAD Group Name:" $assignmentGroup.groupId -ForegroundColor Yellow
                    Write-Host "Assignment Type:" $assignmentGroup."@OData.type" -ForegroundColor Yellow
                   
                    $assignmentGroupId = (Get-AADGroup -GroupName $assignmentGroup.groupid)
                    Write-Host "Include assignment Group ID:" $assignmentGroupId.Id -ForegroundColor Yellow
                    Add-DeviceConfigurationPolicyAssignment -ConfigurationPolicyId $DeviceConfigID -TargetGroupId $assignmentGroupId.id -Assignment $assignmentGroup."@OData.type" 
                }
            }
            #>
            
            Write-Host "Applying target include group id: $($TargetGroup.ID)" -ForegroundColor Yellow
            Add-DeviceConfigurationPolicyAssignment -ConfigurationPolicyId $DeviceConfigID -TargetGroupId $TargetGroup.Id -Assignment "#microsoft.graph.groupAssignmentTarget"
            
            <#
            Return
            # Create exclude Group
            #Regex matches 1 to 4 digits (for the year in the name of the policy)
            $ShortName = $displayName -replace 'PAW-Global-(\d{1,4})-Intune-Configuration-', ''
            $ExcludeGroup = "PAW-" + $ShortName + "-Exclude-Device"
            $ExcludeTargetGroup = Get-AzureADGroup -SearchString $ExcludeGroup
            If ($ExcludeTargetGroup) {
                Write-Host
                Write-Warning "AAD group" $ExcludeGroup "already exists!"
                Write-Host
            }
            Else {
                    
                $MailNickName = $ShortName + "-G"
                         
                try {
                    $ExcludeTargetGroup = New-AzureADGroup -DisplayName $ExcludeGroup -Description $ExcludeGroup"-Group" -MailEnabled $false -SecurityEnabled $true -MailNickName $MailNickName
                    Start-Sleep -seconds 5
                }
                catch {
                    Write-Host
                    Write-Host "Error creating AAD group" $ExcludeGroup -f Red
                    Write-Host
                }
            }         
            Write-Host "Excluded Group ID" $ExcludeTargetGroup.objectid
            Add-DeviceConfigurationPolicyAssignment -ConfigurationPolicyId $DeviceConfigID -TargetGroupId $ExcludeTargetGroup.objectid -Assignment "#microsoft.graph.exclusionGroupAssignmentTarget"
            #>
        }
        Else {                    
            If ($Update -eq "Yes") {
                #$JSON_Convert = $JSON_Data | ConvertFrom-Json | Select-Object -Property * -ExcludeProperty id, createdDateTime, lastModifiedDateTime, version, supportsScopeTags, Assignments
                $JSON_Convert = $JSON_Data | ConvertFrom-Json | Select-Object -Property * -ExcludeProperty id, createdDateTime, lastModifiedDateTime, version, supportsScopeTags, Assignments, deviceManagementApplicabilityRuleOsEdition, deviceManagementApplicabilityRuleOsVersion, deviceManagementApplicabilityRuleDeviceMode
                        
                $JSON_Output = $JSON_Convert | ConvertTo-Json -Depth 5 
                write-host
                write-host "Device Configuration Policy '$DisplayName' Found..." -ForegroundColor Yellow
                write-host
                $JSON_Output
                write-host
                Write-Host "Updating Device Configuration Policy '$DisplayName'" -ForegroundColor Yellow
                        
                $DeviceConfigs = Get-DeviceConfigurationPolicy -name $DisplayName
                $DeviceConfigID = $DeviceConfigs.id
            
                Update-DeviceConfigurationPolicy -JSON $JSON_Output -Id $DeviceConfigID
                write-host "Device Configuration Profile:" $JSON_Convert.displayName "Updated" -ForegroundColor Green
            }            
            ElseIf ($update -eq "No") {
                Write-Warning "Device Configuration Profile:" $JSON_Convert.displayName "has already been created"         
            }            
        }
    }
}

##########################################################################################################
#region auth
#$script:tenantId = ""
#$script:clientId = ""
#$certName = "CN=PSAuth"

$modules = @("Microsoft.Graph.Authentication", "Microsoft.Graph.DeviceManagement", "Microsoft.Graph.Groups")
#Check if module is installed and up to date
Test-Module -ModuleNames $modules


If ($CertName) {
    Write-Host "Using certname: $CertName"
    If ($CertName -match "CN=") {
        Write-Host "Matches" -ForegroundColor Green
    }
    Else {
        $CertName = $CertName -replace $CertName, "CN=$CertName"
        Write-Host "Modified Cert Name: $CertName" -ForegroundColor Yellow
    }

    $myCert = Get-ChildItem -Path "cert:\CurrentUser\My" | Where-Object Subject -eq $CertName
    If ($myCert) {
        Write-Host "Found cert, using it to authenticate to Graph..." -ForegroundColor Yellow
        Connect-MgGraph -ClientID $clientId -TenantId $tenantId -CertificateThumbprint $myCert.Thumbprint ## Or -CertificateThumbprint instead of -CertificateName
    }
    Else {
        Throw "Error - cert not found: $CertName"
    }

}
ElseIf ($ClientSecret) {
    Write-Host "Using client secret"
    $token = GetMsGraphToken -tenantId $tenantId -clientId $clientId -clientSecret $clientSecret

    Try {
        Connect-MgGraph -AccessToken $token -ErrorAction Stop
    }
    Catch {
        $ex = $_.Exception
        Write-Warning "$($env:computername.ToUpper()) : $($_.Exception.message)"
        $errorResponse = $ex.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($errorResponse)
        $reader.BaseStream.Position = 0
        $reader.DiscardBufferedData()
        $responseBody = $reader.ReadToEnd();
        Write-Host "Response content:`n$responseBody" -f Red
        Write-Error "Request to $DCP_resource failed with HTTP Status $($ex.Response.StatusCode) $($ex.Response.StatusDescription)"
        write-host
        Throw
    }
}
Else {
    Throw "Please specify either a valid certificate name or client secret for authentication"
}
Select-MgProfile -Name "beta"
#endregion auth

#Prepare policy targeting group
$group = Test-Group -GroupName $TargetGroup

#Create AppLocker JSON file
$appLockerJSONFile = New-AppLockerJSON -AppLockerXMLPath $ImportPath
Write-Host "AppLocker XML file: $appLockerJSONFile"

#Import the new AppLocker JSON file
Import-AppLockerJSON -JSONFile $appLockerJSONFile -TargetGroup $group -PolicyName $PolicyName -Update $Update