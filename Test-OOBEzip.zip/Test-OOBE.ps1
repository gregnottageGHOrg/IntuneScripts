## Configure Intune Win32 package with the option: App install may force a device restart - which will use the return code below
# https://www.petervanderwoude.nl/post/working-with-the-restart-behavior-of-win32-apps/#:~:text=Enforce%20device%20restart%20behavior
$username = "defaultuser"
$currentuser = (Get-Process -IncludeUserName -Name explorer | Select-Object -ExpandProperty UserName).Split('\')[1]

if ($currentuser -like "$username*") {
    Write-Host "Default user logged in: $currentuser"

    # Running under OOBE/ESP (Autopilot)
    # Do tasks that make sense here

    <#
    #Soft reboot return code
    Exit 3010
    #>

    #Hard reboot return code
    Exit 1641

}
else {
    Write-Host "Default user not logged in"

    # Skip any Autopilot tasks, but do not reboot.
}