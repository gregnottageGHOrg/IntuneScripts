#region Initialisation...
<#

.COPYRIGHT
Copyright (c) Microsoft Corporation. All rights reserved. Licensed under the MIT license.
See LICENSE in the project root for license information.

#>
####################################################
####################################################
#Instantiate Vars
####################################################
[CmdLetBinding()]
param(
    [Parameter()]
    [switch] $install,
    [switch] $unInstall,
    [switch] $userInstall,
    [string] $tagFile,
    [switch] $regTag
)
#$VerbosePreference = "Continue" #Enables Verbose Logging, can be enabled with -verbose on the cmdline too
$script:exitCode = 0

#Restart as 64-bit
if (![System.Environment]::Is64BitProcess) {
    $additionalArgs = ''
    foreach ($Param in $PSBoundParameters.GetEnumerator()) {
        if (-not $MyInvocation.MyCommand.Parameters[$Param.key].SwitchParameter) {
            $additionalArgs += "-$($Param.Key) $($Param.Value) "
        }
        else {
            $additionalArgs += "-$($Param.Key) "
        }
    }

    # start new PowerShell as x64 bit process, wait for it and gather exit code and standard error output
    $sysNativePowerShell = "$($PSHOME.ToLower().Replace("syswow64", "sysnative"))\powershell.exe"

    $pinfo = New-Object System.Diagnostics.ProcessStartInfo
    $pinfo.FileName = $sysNativePowerShell
    $pinfo.Arguments = "-ex bypass -file `"$PSCommandPath`" $additionalArgs"
    $pinfo.RedirectStandardError = $true
    #$pinfo.RedirectStandardOutput = $true
    $pinfo.CreateNoWindow = $true

    #$pinfo.RedirectStandardError = $false
    #$pinfo.RedirectStandardOutput = $false
    #$pinfo.CreateNoWindow = $false

    $pinfo.UseShellExecute = $false
    $p = New-Object System.Diagnostics.Process
    $p.StartInfo = $pinfo
    $p.Start() | Out-Null

    $exitCode = $p.ExitCode

    $stderr = $p.StandardError.ReadToEnd()
    $p.WaitForExit()

    if ($stderr) { Write-Error -Message $stderr }
}
Else {

    $script:BuildVer = "1.1"
    $script:ProgramFiles = $env:ProgramFiles
    $script:ParentFolder = $PSScriptRoot | Split-Path -Parent
    $script:ScriptName = $myInvocation.MyCommand.Name
    $script:ScriptName = $scriptName.Substring(0, $scriptName.Length - 4)
    $script:LogName = $scriptName + "_" + (Get-Date -UFormat "%d-%m-%Y")
    If ( $userInstall ) {
        $script:logPath = "$($env:LOCALAPPDATA)\Microsoft\IntuneApps\$scriptName"
    }
    Else {
        #$script:logPath = "$($env:ProgramData)\Microsoft\IntuneApps\$scriptName"
        $script:logPath = "$($env:ProgramData)\Microsoft\IntuneManagementExtension\Logs"
    }
    $script:logFile = "$logPath\$LogName.log"
    Add-Type -AssemblyName Microsoft.VisualBasic
    $script:EventLogName = "Application"
    $script:EventLogSource = "EventSystem"
    $script:transcriptLog = "$logPath\$LogName" + "_Transcript.log"
    If ($VerbosePreference -eq 'Continue') { Start-Transcript -Path "$transcriptLog" -Append }
    ####################################################
    ####################################################
    #Build Functions
    ####################################################

    Function Start-Log {
        param (
            [string]$FilePath,

            [Parameter(HelpMessage = 'Deletes existing file if used with the -DeleteExistingFile switch')]
            [switch]$DeleteExistingFile
        )

        #Create Event Log source if it's not already found...
        if ([System.Diagnostics.EventLog]::Exists($script:EventLogName) -eq $false) {
            New-EventLog -LogName $EventLogName -Source $EventLogSource
        }
        if ([System.Diagnostics.EventLog]::SourceExists($script:EventLogSource ) -eq $false) {
            [System.Diagnostics.EventLog]::CreateEventSource($script:EventLogSource , $EventLogName)
        }
        #If (!([system.diagnostics.eventlog]::SourceExists($EventLogSource))) { New-EventLog -LogName $EventLogName -Source $EventLogSource }

        Try {
            If (!(Test-Path $FilePath)) {
                ## Create the log file
                New-Item $FilePath -Type File -Force | Out-Null
            }

            If ($DeleteExistingFile) {
                Remove-Item $FilePath -Force
            }

            ## Set the global variable to be used as the FilePath for all subsequent Write-Log
            ## calls in this session
            $script:ScriptLogFilePath = $FilePath
        }
        Catch {
            Write-Error $_.Exception.Message
        }
    }

    ####################################################

    Function Write-Log {
        #Write-Log -Message 'warning' -LogLevel 2
        #Write-Log -Message 'Error' -LogLevel 3
        param (
            [Parameter(Mandatory = $true)]
            [string]$Message,

            [Parameter()]
            [ValidateSet(1, 2, 3)]
            [int]$LogLevel = 1,

            [Parameter(HelpMessage = 'Outputs message to Event Log,when used with -WriteEventLog')]
            [switch]$WriteEventLog
        )
        Write-Host
        Write-Host $Message
        Write-Host
        $TimeGenerated = "$(Get-Date -Format HH:mm:ss).$((Get-Date).Millisecond)+000"
        $Line = '<![LOG[{0}]LOG]!><time="{1}" date="{2}" component="{3}" context="" type="{4}" thread="" file="">'
        $LineFormat = $Message, $TimeGenerated, (Get-Date -Format MM-dd-yyyy), "$($MyInvocation.ScriptName | Split-Path -Leaf):$($MyInvocation.ScriptLineNumber)", $LogLevel
        $Line = $Line -f $LineFormat
        Add-Content -Value $Line -Path $ScriptLogFilePath
        If ($WriteEventLog) { Write-EventLog -LogName $EventLogName -Source $EventLogSource -Message $Message  -Id 100 -Category 0 -EntryType Information }
    }

    ####################################################

    Function New-IntuneTag {
        <#
    .SYNOPSIS
    .DESCRIPTION
    .EXAMPLE
    .PARAMETER
    .INPUTS
    .OUTPUTS
    .NOTES
    .LINK
#>
        Param (
            [string]$TagFilePath = "$($env:ProgramData)\Microsoft\IntuneApps\$scriptName\",
            [string]$tagName
        )

        Begin {
            Write-Log -Message "Starting $($MyInvocation.InvocationName) function..."
        }

        Process {
            # Create a tag file just so Intune knows this was installed
            Write-Log "Creating Intune Tag file path: [$TagFilePath]"

            If (-not (Test-Path $TagFilePath) ) {

                New-Item -Path $TagFilePath -ItemType "directory" -Force | out-null
            }

            # Check if tagName already has .tag at the end
            If ($tagName.Substring(($tagName.Length - 4), 4) -eq ".tag") {
                Write-Log -Message "Using passed in tagName: $tagName"
                $tagFileName = "$TagFilePath\$tagName"
            }
            Else {
                Write-Log -Message "Using default of scriptname: $tagName and appending .tag"
                $tagFileName = "$TagFilePath\$tagName.tag"
            }

            Write-Log "Creating Intune Tag file: [$tagFileName]"

            Set-Content -Path $tagFileName -Value "Installed"

            Write-Log -Message "Created Intune Tag file: [$tagFileName]"

        }
    }

    ####################################################

    Function Remove-IntuneTag {
        <#
    .SYNOPSIS
    .DESCRIPTION
    .EXAMPLE
    .PARAMETER
    .INPUTS
    .OUTPUTS
    .NOTES
    .LINK
#>
        Param (
            [string]$TagFilePath = "$($env:ProgramData)\Microsoft\IntuneApps\$scriptName\",
            [string]$tagName
        )

        Begin {
            Write-Log -Message "Starting $($MyInvocation.InvocationName) function..."
        }

        Process {
            # Remove the tag file so Intune knows this was uninstalled
            # Check if tagName already has .tag at the end
            If ($tagName.Substring(($tagName.Length - 4), 4) -eq ".tag") {
                Write-Log -Message "Using passed in tagName: $tagName"
                $tagFileName = "$TagFilePath\$tagName"
            }
            Else {
                Write-Log -Message "Using default of scriptname: $tagName and appending .tag"
                $tagFileName = "$TagFilePath\$tagName.tag"
            }

            Write-Log "Removing Intune Tag file: [$tagFileName]"

            If (Test-Path $tagFileName) {
                Remove-Item -Path $tagFileName -Force
            }

        }
    }

    ####################################################

    Function New-IntuneRegTag {
        <#
    .SYNOPSIS
    .DESCRIPTION
    .EXAMPLE
    .PARAMETER
    .INPUTS
    .OUTPUTS
    .NOTES
    .LINK
#>
        Param (
            [string]$TagRegPath = "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\IntuneApps\",
            [string]$tagName
        )

        Begin {
            Write-Log -Message "Starting $($MyInvocation.InvocationName) function..."
        }

        Process {
            # Create a registry tag just so Intune knows this was installed
            Write-Log "Creating Intune Tag file path: [$TagRegPath\$tagName]"

            #Get-ItemProperty -Path "HKLM:\SOFTWARE\$TagRegPath" -Name $tagName

            New-Item -Path "Registry::$TagRegPath" -Force

            $returnCode = New-ItemProperty -Path "Registry::$TagRegPath" -Name $tagName -PropertyType String -Value "Installed" -Force
            Write-Log -Message "Return code: $returnCode"
        }
    }

    ####################################################

    Function Remove-IntuneRegTag {
        <#
    .SYNOPSIS
    .DESCRIPTION
    .EXAMPLE
    .PARAMETER
    .INPUTS
    .OUTPUTS
    .NOTES
    .LINK
#>
        Param (
            [string]$TagRegPath = "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\IntuneApps\",
            [string]$tagName
        )

        Begin {
            Write-Log -Message "Starting $($MyInvocation.InvocationName) function..."
        }

        Process {
            # Remove registry tag just so Intune knows this was uninstalled
            Write-Log "Removing Intune Tag file path: [$TagRegPath\$tagName]"

            $returnCode = Remove-ItemProperty -Path "Registry::$TagRegPath" -Name $tagName -Force
            Write-Log -Message "Return code: $returnCode"
        }
    }

    ####################################################

    function IsNull($objectToCheck) {
        if ($objectToCheck -eq $null) {
            return $true
        }

        if ($objectToCheck -is [String] -and $objectToCheck -eq [String]::Empty) {
            return $true
        }

        if ($objectToCheck -is [DBNull] -or $objectToCheck -is [System.Management.Automation.Language.NullString]) {
            return $true
        }

        return $false
    }

    ####################################################

    Function Set-PSGalleryPreReqs {
        Begin {
            Write-Host "Starting $($MyInvocation.InvocationName) function... `n" -ForegroundColor Green
        }
        Process {
            Write-Host "Preparing PSGallery pre-reqs... `n" -ForegroundColor Magenta

            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

            <#
            #Copy and register Nuget DLL
            Write-Log -Message "Create path: $env:ProgramFiles\PackageManagement\ProviderAssemblies\nuget\2.8.5.208"
            Try {
                New-Item -ItemType Directory -Path "$env:ProgramFiles\PackageManagement\ProviderAssemblies\nuget\2.8.5.208" -Force -ErrorAction Stop
            }
            Catch {
                Write-Log -Message "Error: creating path: $env:ProgramFiles\PackageManagement\ProviderAssemblies\nuget\2.8.5.208"
                Throw "Error: creating path: $env:ProgramFiles\PackageManagement\ProviderAssemblies\nuget\2.8.5.208"
            }
            Write-Log -Message "Created path: $env:ProgramFiles\PackageManagement\ProviderAssemblies\nuget\2.8.5.208"

            Write-Log -Message "Copy file: $PSScriptRoot\Microsoft.PackageManagement.NuGetProvider.dll to path: $env:ProgramFiles\PackageManagement\ProviderAssemblies\nuget\2.8.5.208"
            Try {
                Copy-Item -Path "$PSScriptRoot\Microsoft.PackageManagement.NuGetProvider.dll" -Destination "$env:ProgramFiles\PackageManagement\ProviderAssemblies\nuget\2.8.5.208" -Force -ErrorAction Stop
            }
            Catch {
                Write-Log -Message "Error: copying file: $PSScriptRoot\Microsoft.PackageManagement.NuGetProvider.dll to path: $env:ProgramFiles\PackageManagement\ProviderAssemblies\nuget\2.8.5.208"
                Throw "Error: copying file: $PSScriptRoot\Microsoft.PackageManagement.NuGetProvider.dll to path: $env:ProgramFiles\PackageManagement\ProviderAssemblies\nuget\2.8.5.208"
            }
            Write-Log -Message "Copied file: $PSScriptRoot\Microsoft.PackageManagement.NuGetProvider.dll to path: $env:ProgramFiles\PackageManagement\ProviderAssemblies\nuget\2.8.5.208"

            Write-Log -Message "Import Package Provider -Name NuGet"
            Try {
                Import-PackageProvider -Name NuGet -ErrorAction Stop
            }
            Catch {
                Write-Log -Message "Error: importing Package Provider -Name NuGet"
                Throw "Error: importing Package Provider -Name NuGet"
            }
            Write-Log -Message "Imported Package Provider -Name NuGet"
            #>

            #<#
            #Check for NuGet Package Provider installed on machine
            if ((Get-PackageProvider -ListAvailable).name -eq "NuGet") {
                #check if Nuget is installed on the machine
                $nuget = Get-PackageProvider -Name Nuget

                if ($nuget.version -eq ((find-PackageProvider -name nuget).version)) {
                    #check for latest version
                    Write-Host "NuGet is up to date `n" -ForegroundColor Green
                }
                else {
                    try {
                        Install-PackageProvider -name nuget -Force -confirm:$False -ErrorAction Stop
                        Write-Host "NuGet Package Provider is installed `n" -ForegroundColor Green
                    }
                    catch {
                        Throw
                    }
                }
            }
            else {
                try {
                    Write-Host "Running command 'Install-PackageProvider -name nuget -Force -confirm:`$false' `n" -ForegroundColor Yellow
                    Install-PackageProvider -name nuget -Force -confirm:$false -ErrorAction Stop
                    Write-Host "`nNuGet Package Provider is installed `n" -ForegroundColor Green
                }
                catch {
                    Throw
                }
            }
            #>

            #Register the PSGallery repository and set the installation policy to trusted
            Write-Host "Checking Get-PSRepository for PSGallery... `n" -ForegroundColor Magenta

            $psRepo = Get-PSRepository
            foreach ($repo in $psrepo) {
                Write-Host "`nRepo name: $($repo.name) with installation policy: $($repo.InstallationPolicy)`n"
                If (($($repo.name) -eq "PSGallery") -and ($($repo.InstallationPolicy) -ne "Trusted")) {
                    Write-Host "PSGallery currently untrusted, setting it to trusted. `n" -ForegroundColor Yellow
                    #<#
                    Try {
                        Write-Host "Set PSGallery to trusted `n" -ForegroundColor Yellow
                        Set-PSRepository -name "PSGallery" -InstallationPolicy Trusted
                    }
                    Catch {
                        Throw
                    }
                    $found = $True
                    Write-Host "PSGallery Repository installation policy set to trusted `n" -ForegroundColor Green
                    #>
                }
                ElseIf (($($repo.name) -eq "PSGallery") -and ($($repo.InstallationPolicy) -eq "Trusted")) {
                    $found = $True
                    Write-Host "PSGallery Repository installation policy already set to trusted `n" -ForegroundColor Green
                }
            }

            If (-Not($found)) {
                Write-Host "PSGallery repo not found `n" -ForegroundColor Yellow
                Try {
                    Write-Host "Register PSGallery as trusted `n" -ForegroundColor Yellow
                    Register-PSRepository -Default -InstallationPolicy Trusted
                }
                Catch {
                    Throw
                }
                Write-Host "Default PS Repository registered and installation policy set to trusted `n" -ForegroundColor Green
            }

            <#
        If ((Get-PSRepository).name -eq "PSGallery") {
            Try {
                Write-Host "Set PSGallery to trusted `n" -ForegroundColor Yellow
                Set-PSRepository -name "PSGallery" -InstallationPolicy Trusted
            }
            Catch {
                Throw
            }
            Write-Host "PSGallery Repository installation policy set to trusted `n" -ForegroundColor Green
        }
        else {
            Try {
                Write-Host "Register PSGallery as trusted `n" -ForegroundColor Yellow
                Register-PSRepository -Default -InstallationPolicy Trusted
            }
            Catch {
                Throw
            }
            Write-Host "default PS Repository registered and installation policy set to trusted `n" -ForegroundColor Green
        }
        #>

            #Update PowerShellGet module
            Write-Host "`nUpdate PowerShellGet module `n" -ForegroundColor Magenta
            Try {
                Install-Module PowerShellGet -AllowClobber -Force -ErrorAction Stop
                Import-PSModule -ModuleToLoad "PowerShellGet"
                Write-Host "`nPowerShellGet module is installed `n" -ForegroundColor Green
            }
            Catch {
                Write-Log -Message "Error: updating module - PowerShellGet"
                Throw "Error: updating module - PowerShellGet"
            }

            #Update PackageManagement module
            Write-Host "`nCheck for PackageManagement module `n" -ForegroundColor Magenta
            Try {
                #Install-Module -Name PackageManagement -Force -MinimumVersion 1.4.6 -Repository PSGallery -ErrorAction SilentlyContinue
                Install-Module -Name PackageManagement -Force -MinimumVersion 1.4.6 -Repository PSGallery -ErrorAction Stop
                Update-EveryModule -ExcludedModules $listOfModules
                Import-PSModule -ModuleToLoad "PackageManagement"
                Write-Host "`nPackageManagement module is installed `n" -ForegroundColor Green
            }
            Catch {
                Write-Log -Message "Error: updating module - PackageManagement"
                Throw "Error: updating module - PackageManagement"
            }
        }
        End {
            Write-Host "Ending: $($MyInvocation.Mycommand) `n" -ForegroundColor Green
        }
    }

    ####################################################

    Function Import-PSModule {
        <#
            .SYNOPSIS
        Cmdlet for loading modules single or multiple modules



            .DESCRIPTION
                    This function will import modules, load and or install modules from a PowerShell Repository



            .PARAMETER ModuleToLoad
                    Modules to load



    .EXAMPLE
        PS C:\> Import-PSModules -ModuleToLoad Foo



                    Imports the Foo module



    .NOTES
        NOTE: You can not pull up the help information until the object has been imported
    #>

        [cmdletbinding()]
        param(
            [object]$moduleToLoad
        )

        Begin {
            Write-Host "Starting $($MyInvocation.InvocationName) function... `n" -ForegroundColor Green
        }
        Process {
            Write-Host "Check to see if module: $ModuleToLoad is already imported `n" -ForegroundColor Yellow
            if (Get-Module -Name $moduleToLoad) {
                $mod = Get-Module -Name $moduleToLoad | Select-Object Name, Version
                Write-Host "Module already installed: $mod `n" -ForegroundColor Green
            }
            else {
                Write-Host "If module is not imported, but available on disk then import it `n" -ForegroundColor Yellow
                Write-Host "This will check all of the available modules in the module paths `n" -ForegroundColor Yellow
                if (Get-Module -ListAvailable -Name $moduleToLoad) {
                    $mod = Get-Module -ListAvailable -Name $moduleToLoad | Select-Object Name, Version
                    Write-Host "Module details: $mod `n" -ForegroundColor Green
                }
                else {
                    try {
                        Write-Host "If module is not imported, not available on disk, but is in online gallery then install and import `n" -ForegroundColor Yellow
                        if (Find-Module -Name $moduleToLoad) {
                            Write-Host "If the module is found, try to install it `n" -ForegroundColor Yellow
                            Write-Host "Using command: Install-Module -Name $moduleToLoad -AcceptLicense -AllowClobber -Force `n" -ForegroundColor Yellow

                            If (Test-Administrator) {
                                Install-Module -Name $moduleToLoad -AcceptLicense -AllowClobber -Force
                            }
                            Else {
                                Install-Module -Name $moduleToLoad -Scope CurrentUser -AcceptLicense -AllowClobber -Force
                            }

                            $mod = Get-Module -ListAvailable -Name $moduleToLoad | Select-Object Name, Version
                            Write-Host "Licensed module now installed: $mod `n" -ForegroundColor Green
                        }
                        else {
                            Write-Host "Module is not imported, not available and not in online gallery, aborting"
                            Throw
                        }
                    }
                    Catch [System.Management.Automation.ParameterBindingException] {
                        Write-Host "Module did not install with -AcceptLicense parameter, trying without.`n" -ForegroundColor Yellow
                        Write-Host "Using command: Install-Module -Name $moduleToLoad -AllowClobber -Force `n" -ForegroundColor Yellow
                        If (Test-Administrator) {
                            Install-Module -Name $moduleToLoad -AllowClobber -Force
                        }
                        Else {
                            Install-Module -Name $moduleToLoad -Scope CurrentUser -AllowClobber -Force
                        }

                        $mod = Get-Module -ListAvailable -Name $moduleToLoad | Select-Object Name, Version
                        Write-Host "Module now installed: $mod `n" -ForegroundColor Green
                    }
                    catch {
                        Throw
                    }
                }
            }
        }
        End {
            Write-Host "Ending: $($MyInvocation.Mycommand) `n" -ForegroundColor Green
        }
    }

    ####################################################

    function Update-EveryModule {
        <#
    .SYNOPSIS
    Updates all modules from the PowerShell gallery.
    .DESCRIPTION
    Updates all local modules that originated from the PowerShell gallery.
    Removes all old versions of the modules.
    .PARAMETER ExcludedModules
    Array of modules to exclude from updating.
    .PARAMETER SkipMajorVersion
    Skip major version updates to account for breaking changes.
    .PARAMETER KeepOldModuleVersions
    Array of modules to keep the old versions of.
    .PARAMETER ExcludedModulesforRemoval
    Array of modules to exclude from removing old versions of.
    The Az module is (not) excluded by default.
    .EXAMPLE
    Update-EveryModule -excludedModulesforRemoval 'Az'
    .NOTES
    Created by Barbara Forbes
    @ba4bes
    .LINK
    https://4bes.nl
    #>
        [cmdletbinding(SupportsShouldProcess = $true)]
        param (
            [parameter()]
            [array]$ExcludedModules = @(),
            [parameter()]
            [switch]$SkipMajorVersion,
            [parameter()]
            [switch]$KeepOldModuleVersions,
            [parameter()]
            [array]$ExcludedModulesforRemoval = @()
            #[array]$ExcludedModulesforRemoval = @("Az")
        )
        # Get all installed modules that have a newer version available
        Write-Verbose "`nChecking all installed modules for available updates.`n"
        $CurrentModules = Get-InstalledModule | Where-Object { $ExcludedModules -notcontains $_.Name -and $_.repository -eq "PSGallery" }

        # Walk through the Installed modules and check if there is a newer version
        # Get-InstallModule can only return what Install-Module previously installed
        $CurrentModules | ForEach-Object {
            Write-Verbose "`nChecking $($_.Name)`n"
            Try {
                $GalleryModule = Find-Module -Name $_.Name -Repository PSGallery -ErrorAction Stop
            }
            Catch {
                Write-Error "Module $($_.Name) not found in gallery $_"
                $GalleryModule = $null
            }
            if ($GalleryModule.Version -gt $_.Version) {
                if ($SkipMajorVersion -and $GalleryModule.Version.Split('.')[0] -gt $_.Version.Split('.')[0]) {
                    Write-Warning "Skipping major version update for module $($_.Name). Galleryversion: $($GalleryModule.Version), local version $($_.Version)"
                }
                else {
                    Write-Verbose "$($_.Name) will be updated. Galleryversion: $($GalleryModule.Version), local version $($_.Version)"
                    try {
                        if ($PSCmdlet.ShouldProcess(
                        ("Module {0} will be updated to version {1}" -f $_.Name, $GalleryModule.Version),
                                $_.Name,
                                "Update-Module"
                            )
                        ) {
                            Update-Module $_.Name -ErrorAction Stop -Force
                            Write-Verbose "$($_.Name)  has been updated"
                        }
                    }
                    Catch {
                        Write-Error "$($_.Name) failed: $_ "
                        continue

                    }
                    if ($KeepOldModuleVersions -ne $true) {
                        Write-Verbose "Removing old module $($_.Name)"
                        if ($ExcludedModulesforRemoval -contains $_.Name) {
                            Write-Verbose "$($allversions.count) versions of this module found [ $($module.name) ]"
                            Write-Verbose "Please check this manually as removing the module can cause instabillity."
                        }
                        else {
                            try {
                                if ($PSCmdlet.ShouldProcess(
                                ("Old versions will be uninstalled for module {0}" -f $_.Name),
                                        $_.Name,
                                        "Uninstall-Module"
                                    )
                                ) {
                                    Get-InstalledModule -Name $_.Name -AllVersions | Where-Object { $_.version -ne $GalleryModule.Version } | Uninstall-Module -Force -ErrorAction Stop
                                    Write-Verbose "Old versions of $($_.Name) have been removed"
                                }
                            }
                            catch {
                                Write-Error "Uninstalling old module $($_.Name) failed: $_"
                            }
                        }
                    }
                }
            }
            elseif ($null -ne $GalleryModule) {
                Write-Verbose "`n$($_.Name) is up to date`n"
            }
        }
    }

    ####################################################

    Function Invoke-ModuleInstall {
        Begin {
            Write-Host "Starting $($MyInvocation.InvocationName) function... `n" -ForegroundColor Green
        }
        Process {
            Write-Host "Performing module install steps `n" -ForegroundColor Magenta

            foreach ($module in $listOfModules) {
                Write-Host "Importing module: $module `n" -ForegroundColor Yellow
                Import-PSModule -moduleToLoad $module
            }
        }
        End {
            Write-Host "Ending: $($MyInvocation.Mycommand) `n" -ForegroundColor Green
        }
    }

    ####################################################

    Function Uninstall-PSModule {
        <#
            .SYNOPSIS
        Cmdlet for unloading modules single or multiple modules

            .DESCRIPTION
                    This function will uninstall modules

            .PARAMETER ModuleToUninstall
                    Modules to load

    .EXAMPLE
        PS C:\> Import-PSModules -ModuleToUninstall Foo

                    Removes the Foo module

    .NOTES
        NOTE: You can not pull up the help information until the object has been imported
    #>

        [cmdletbinding()]
        param(
            [object]$moduleToUninstall
        )

        Begin {
            Write-Host "Starting $($MyInvocation.InvocationName) function... `n" -ForegroundColor Green
        }
        Process {
            Write-Host "Check to see if module: $ModuleToUninstall is installed."
            if (Get-Module -ListAvailable -Name $ModuleToUninstall) {
                Write-Host "Module found, removing"
                Try {
                    Get-Module $ModuleToUninstall | Uninstall-Module -AllVersions -Force
                }
                Catch {
                    Write-Host "Unable to remove module: $ModuleToUninstall `n" -ForegroundColor Yellow
                }
            }
        }
        End {
            Write-Host "Ending: $($MyInvocation.Mycommand) `n" -ForegroundColor Green
        }
    }

    ####################################################

    Function Test-Administrator {
        $user = [Security.Principal.WindowsIdentity]::GetCurrent();
    (New-Object Security.Principal.WindowsPrincipal $user).IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)
    }

    ####################################################

    Start-Log -FilePath $logFile -DeleteExistingFile
    Write-Host
    Write-Host "Script log file path is [$logFile]" -ForegroundColor Cyan
    Write-Host
    Write-Log -Message "Starting $ScriptName version $BuildVer" -WriteEventLog
    Write-Log -Message "Running from location: $PSScriptRoot" -WriteEventLog
    Write-Log -Message "Script log file path is [$logFile]" -WriteEventLog
    Write-Log -Message "Running in 64-bit mode: $([System.Environment]::Is64BitProcess)"

    #endregion Initialisation...
    ##########################################################################################################
    ##########################################################################################################

    #region Main Script work section
    ##########################################################################################################
    ##########################################################################################################
    #Main Script work section
    ##########################################################################################################
    ##########################################################################################################

    $listOfModules = @('AzureADPreview', 'MSOnline', 'ExchangeOnlineManagement', 'Microsoft.Online.SharePoint.PowerShell', 'SharePointPnPPowershellonline', 'MicrosoftTeams', 'PNP.Powershell', `
            'Microsoft365DSC', 'MicrosoftPowerBIMgmt', 'Microsoft.Azure.ActiveDirectory.PIM.PSModule', 'ORCA', 'Microsoft.PowerApps.PowerShell', 'Microsoft.PowerApps.Administration.PowerShell')

    If ($Install) {
        Write-Log -Message "Performing Install steps..."

        Write-Host "Call function to prepare PSGallery pre-reqs... `n" -ForegroundColor Yellow
        Set-PSGalleryPreReqs

        # Call function to install the list of modules
        Write-Host "Installing required modules... `n" -ForegroundColor Yellow
        Invoke-ModuleInstall

        # Create Scheduled Task To Update Modules
        $ExistingScheduledTask = Get-ScheduledTask -TaskName "UPDATE-PSMODULES" -ErrorAction SilentlyContinue

        if (!$ExistingScheduledTask) {
            Write-Log -Message  "Scheduled task not created, creating now"
            $SchTaskLogonAction = New-ScheduledTaskAction -Execute 'Powershell.exe' -Argument ('-NoProfile -WindowStyle Hidden -command "Update-Module -Force"')
            $SchTaskPrin = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount
            $SchTaskTrig = New-ScheduledTaskTrigger -Daily -DaysInterval 7 -At 1pm
            $SchTaskSett = New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Minutes 10) -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 30)
            Register-ScheduledTask -Action $SchTaskLogonAction -Trigger $SchTaskTrig -Settings $SchTaskSett -Principal $SchTaskPrin -TaskName "UPDATE-PSMODULES" -Description "Updates PowerShell Modules" | Out-Null
        }
        else {
            Write-Log -Message  "Scheduled task: UPDATE-PSMODULES already exists, skipping re-creation."
        }

        #Handle Intune detection method
        If (! ($userInstall) ) {
            Write-Log -Message "Creating detection rule for System install"

            If ( $regTag ) {
                Write-Log -Message "Using RegTag: HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\IntuneApps\$ScriptName"
                New-IntuneRegTag -TagRegPath "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\IntuneApps" -tagName $ScriptName
            }
            Else {
                Write-Log -Message "Using FileTag"

                If ( ! ( IsNull ( $tagFile ) ) ) {
                    Write-Log -Message "Using tagFile name: $tagFile"
                    New-IntuneTag -TagFilePath "$logPath" -tagName $tagFile
                }
                Else {
                    Write-Log -Message "Using default tagFile name: $scriptName"
                    New-IntuneTag -TagFilePath "$logPath" -tagName $scriptName
                }
            }
        }
        ElseIf ( $userInstall ) {
            Write-Log -Message "Creating detection rule for User install"

            If ( $regTag ) {
                Write-Log -Message "Using RegTag: HKEY_CURRENT_USER\SOFTWARE\Microsoft\IntuneApps\$ScriptName"
                New-IntuneRegTag -TagRegPath "HKEY_CURRENT_USER\SOFTWARE\Microsoft\IntuneApps" -tagName $ScriptName
            }
            Else {
                Write-Log -Message "Using FileTag: "

                If ( ! ( IsNull ( $tagFile ) ) ) {
                    Write-Log -Message "Using tagFile name: $tagFile"
                    New-IntuneTag -TagFilePath "$logPath" -tagName $tagFile
                }
                Else {
                    Write-Log -Message "Using default tagFile name: $scriptName"
                    New-IntuneTag -TagFilePath "$logPath" -tagName $scriptName
                }
            }
        }
    }
    ElseIf ( $UnInstall ) {
        Write-Log -Message "Performing Uninstall steps..."

        # Call function to uninstall the list of functions
        Write-Log -Message "Uninstalling modules"
        foreach ($module in $listOfModules) {
            Write-Log -Message "Removing module: $module"
            Uninstall-PSModule -moduleToUninstall $module
        }

        # Remove Scheduled Task
        Unregister-ScheduledTask -TaskName "UPDATE-PSMODULES"

        If ( Get-ScheduledTask -TaskName "UPDATE-PSMODULES" ) {
            Write-Log -Message "Error - Scheduled Task: UPDATE-PSMODULES failed to uninstall"
            If ($VerbosePreference -eq 'Continue') { Stop-Transcript }
            Exit
        }

        #Handle Intune detection method
        If (! ($userInstall) ) {
            Write-Log -Message "Removing detection for System install"

            If ( $regTag ) {
                Write-Log -Message "Removing RegTag: HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\IntuneApps\$ScriptName"
                Remove-IntuneRegTag -TagRegPath "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\IntuneApps" -tagName $ScriptName
            }
            Else {
                Write-Log -Message "Removing FileTag"

                If ( ! ( IsNull ( $tagFile ) ) ) {
                    Write-Log -Message "Removing tagFile name: $tagFile"
                    Remove-IntuneTag -TagFilePath "$logPath" -tagName $tagFile
                }
                Else {
                    Write-Log -Message "Removing default tagFile name: $scriptName"
                    Remove-IntuneTag -TagFilePath "$logPath" -tagName $scriptName
                }
            }
        }
        ElseIf ( $userInstall ) {
            Write-Log -Message "Removing detection for User install"

            If ( $regTag ) {
                Write-Log -Message "Removing RegTag: HKEY_CURRENT_USER\SOFTWARE\Microsoft\IntuneApps\$ScriptName"
                Remove-IntuneRegTag -TagRegPath "HKEY_CURRENT_USER\SOFTWARE\Microsoft\IntuneApps" -tagName $ScriptName
            }
            Else {
                Write-Log -Message "Removing FileTag: "

                If ( ! ( IsNull ( $tagFile ) ) ) {
                    Write-Log -Message "Removing tagFile name: $tagFile"
                    Remove-IntuneTag -TagFilePath "$logPath" -tagName $tagFile
                }
                Else {
                    Write-Log -Message "Removing default tagFile name: $scriptName"
                    Remove-IntuneTag -TagFilePath "$logPath" -tagName $scriptName
                }
            }
        }
    }


    Write-Log "$ScriptName completed." -WriteEventLog
    If ($VerbosePreference -eq 'Continue') { Stop-Transcript }
    exit $exitCode

    ##########################################################################################################
    ##########################################################################################################
    #endregion Main Script work section
}